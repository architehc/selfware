# Changelog

All notable changes to RustVLM-Bench will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2024-01-XX

### Added
- Initial release of RustVLM-Bench framework
- Core benchmark infrastructure with scoring system
- Support for Ollama models (Qwen3.5-VL, CodeLlama, Llama 3.2 Vision)
- Support for OpenAI API models (GPT-4, GPT-3.5)
- Four difficulty levels: Beginner, Intermediate, Advanced, Expert
- Five test categories: Comprehension, Bug Detection, Refactoring, Architecture, Documentation
- 33 initial test cases covering Rust language features
- Parallel test execution for faster benchmarking
- Multiple output formats: JSON, Markdown, HTML
- Leaderboard system for tracking model performance
- CI/CD integration with GitHub Actions
- Comprehensive documentation and examples

### Test Coverage
- **Comprehension**: 16 tests (ownership, lifetimes, traits, async, unsafe)
- **Bug Detection**: 6 tests (ownership bugs, borrow issues, unsafe bugs)
- **Refactoring**: 6 tests (simplification, optimization, idiomatic code)
- **Architecture**: 5 tests (patterns, design, zero-copy)

### Scoring Features
- Difficulty-based multipliers (1.0x to 3.0x)
- Category-based weights
- Multiple validation types (contains, regex, compile, execute)
- Semantic similarity scoring
- Code compilation verification

### CLI Features
- Run benchmarks with filters (difficulty, category, tags)
- Progress tracking with rich console output
- Model health checking
- Leaderboard viewing and export
- Result comparison across models

## [Unreleased]

### Planned
- Additional test cases (target: 100+)
- Vision-specific tests with screenshots/diagrams
- Multi-turn conversation evaluation
- Code generation benchmarks
- Performance regression detection
- Web dashboard for results visualization
- Support for more model providers (Anthropic, Google, etc.)
- Distributed benchmark execution
