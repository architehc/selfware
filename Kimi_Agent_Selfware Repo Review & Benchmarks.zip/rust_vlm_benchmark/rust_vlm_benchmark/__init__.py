"""
RustVLM-Bench: Visual Language Model Benchmark for Rust Code

A comprehensive framework for evaluating visual language models'
understanding of Rust code across multiple difficulty levels
and task categories.
"""

__version__ = "0.1.0"
__author__ = "RustVLM-Bench Team"

from .core.benchmark import BenchmarkRunner
from .core.config import ConfigLoader
from .core.scoring import ScoringEngine
from .core.results import ResultsAggregator

__all__ = [
    "BenchmarkRunner",
    "ConfigLoader", 
    "ScoringEngine",
    "ResultsAggregator",
]
