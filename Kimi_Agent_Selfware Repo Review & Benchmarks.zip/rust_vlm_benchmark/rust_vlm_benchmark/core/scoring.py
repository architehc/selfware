"""
Scoring engine for evaluating model responses.
"""

import re
import json
import subprocess
import tempfile
import os
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from difflib import SequenceMatcher

try:
    from sentence_transformers import SentenceTransformer, util
    HAS_SENTENCE_TRANSFORMERS = True
except ImportError:
    HAS_SENTENCE_TRANSFORMERS = False

from .models import (
    TestCase, ModelResponse, TestResult, CriterionScore,
    ValidationRule, ScoringCriterion, DifficultyLevel
)


class ResponseExtractor:
    """Extract structured content from model responses."""
    
    @staticmethod
    def extract_code_blocks(text: str) -> List[str]:
        """Extract code blocks from markdown-formatted text."""
        # Match ```rust ... ``` or ``` ... ``` blocks
        pattern = r'```(?:rust)?\n(.*?)```'
        matches = re.findall(pattern, text, re.DOTALL)
        return matches
    
    @staticmethod
    def extract_json(text: str) -> Optional[Dict[str, Any]]:
        """Extract JSON from text."""
        # Try to find JSON in code blocks first
        code_blocks = ResponseExtractor.extract_code_blocks(text)
        for block in code_blocks:
            try:
                return json.loads(block)
            except json.JSONDecodeError:
                continue
        
        # Try to find JSON directly in text
        try:
            # Look for JSON-like structures
            match = re.search(r'\{[\s\S]*\}', text)
            if match:
                return json.loads(match.group())
        except json.JSONDecodeError:
            pass
        
        return None
    
    @staticmethod
    def extract_first_code_block(text: str) -> Optional[str]:
        """Extract the first code block."""
        blocks = ResponseExtractor.extract_code_blocks(text)
        return blocks[0] if blocks else None


class Validator:
    """Validate model responses against rules."""
    
    def __init__(self):
        self.extractor = ResponseExtractor()
    
    def validate(
        self,
        response: ModelResponse,
        test_case: TestCase
    ) -> Tuple[bool, List[str]]:
        """
        Validate a response against test case rules.
        
        Returns:
            Tuple of (passed, list of error messages)
        """
        errors = []
        
        for rule in test_case.expected.validation_rules:
            passed, error = self._validate_rule(response, rule)
            if not passed:
                errors.append(error)
        
        return len(errors) == 0, errors
    
    def _validate_rule(
        self,
        response: ModelResponse,
        rule: ValidationRule
    ) -> Tuple[bool, str]:
        """Validate a single rule."""
        if rule.type == "contains":
            return self._validate_contains(response, rule)
        elif rule.type == "regex":
            return self._validate_regex(response, rule)
        elif rule.type == "json_schema":
            return self._validate_json_schema(response, rule)
        elif rule.type == "compile":
            return self._validate_compile(response, rule)
        elif rule.type == "execute":
            return self._validate_execute(response, rule)
        else:
            return False, f"Unknown validation type: {rule.type}"
    
    def _validate_contains(
        self,
        response: ModelResponse,
        rule: ValidationRule
    ) -> Tuple[bool, str]:
        """Check if response contains expected value."""
        text = response.raw_response.lower()
        expected = rule.value.lower() if rule.value else ""
        
        if expected in text:
            return True, ""
        return False, f"Response does not contain expected value: {rule.value}"
    
    def _validate_regex(
        self,
        response: ModelResponse,
        rule: ValidationRule
    ) -> Tuple[bool, str]:
        """Check if response matches regex pattern."""
        pattern = rule.pattern or ""
        if re.search(pattern, response.raw_response):
            return True, ""
        return False, f"Response does not match pattern: {pattern}"
    
    def _validate_json_schema(
        self,
        response: ModelResponse,
        rule: ValidationRule
    ) -> Tuple[bool, str]:
        """Validate JSON against schema."""
        json_data = self.extractor.extract_json(response.raw_response)
        if json_data is None:
            return False, "Could not extract valid JSON from response"
        
        # Store extracted JSON
        response.extracted_json = json_data
        
        # Simple schema validation (could use jsonschema library)
        if rule.schema:
            for key in rule.schema.get("required", []):
                if key not in json_data:
                    return False, f"Missing required field: {key}"
        
        return True, ""
    
    def _validate_compile(
        self,
        response: ModelResponse,
        rule: ValidationRule
    ) -> Tuple[bool, str]:
        """Validate that extracted code compiles."""
        code = self.extractor.extract_first_code_block(response.raw_response)
        if not code:
            return False, "No code block found in response"
        
        response.extracted_code = code
        
        # Write to temp file and compile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.rs', delete=False) as f:
            f.write(code)
            temp_path = f.name
        
        try:
            result = subprocess.run(
                ['rustc', '--edition', '2021', '-o', '/dev/null', temp_path],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                return True, ""
            else:
                return False, f"Compilation failed: {result.stderr}"
        except subprocess.TimeoutExpired:
            return False, "Compilation timed out"
        except FileNotFoundError:
            return False, "rustc not found"
        finally:
            os.unlink(temp_path)
    
    def _validate_execute(
        self,
        response: ModelResponse,
        rule: ValidationRule
    ) -> Tuple[bool, str]:
        """Validate that code executes correctly."""
        code = self.extractor.extract_first_code_block(response.raw_response)
        if not code:
            return False, "No code block found in response"
        
        # Write to temp file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.rs', delete=False) as f:
            f.write(code)
            temp_path = f.name
        
        try:
            # Compile
            binary_path = temp_path.replace('.rs', '')
            compile_result = subprocess.run(
                ['rustc', '--edition', '2021', '-o', binary_path, temp_path],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if compile_result.returncode != 0:
                return False, f"Compilation failed: {compile_result.stderr}"
            
            # Execute
            run_result = subprocess.run(
                [binary_path],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            expected_code = rule.expected_exit_code or 0
            if run_result.returncode == expected_code:
                return True, ""
            else:
                return False, f"Execution failed with exit code {run_result.returncode}"
        except subprocess.TimeoutExpired:
            return False, "Execution timed out"
        except FileNotFoundError:
            return False, "rustc not found"
        finally:
            if os.path.exists(temp_path):
                os.unlink(temp_path)
            if os.path.exists(binary_path):
                os.unlink(binary_path)


class Scorer:
    """Base class for scoring methods."""
    
    def score(
        self,
        response: ModelResponse,
        test_case: TestCase,
        criterion: ScoringCriterion
    ) -> CriterionScore:
        """Score a response for a specific criterion."""
        raise NotImplementedError


class ExactMatchScorer(Scorer):
    """Score based on exact match."""
    
    def score(
        self,
        response: ModelResponse,
        test_case: TestCase,
        criterion: ScoringCriterion
    ) -> CriterionScore:
        reference = test_case.expected.reference_answer or ""
        similarity = SequenceMatcher(
            None,
            response.raw_response.lower(),
            reference.lower()
        ).ratio()
        
        return CriterionScore(
            criterion=criterion.criterion,
            score=similarity,
            weight=criterion.weight,
            weighted_score=similarity * criterion.weight,
            feedback=f"Similarity: {similarity:.2%}"
        )


class SemanticSimilarityScorer(Scorer):
    """Score based on semantic similarity using embeddings."""
    
    def __init__(self, model_name: str = 'all-MiniLM-L6-v2'):
        if not HAS_SENTENCE_TRANSFORMERS:
            raise ImportError(
                "sentence-transformers required. "
                "Install with: pip install sentence-transformers"
            )
        self.model = SentenceTransformer(model_name)
    
    def score(
        self,
        response: ModelResponse,
        test_case: TestCase,
        criterion: ScoringCriterion
    ) -> CriterionScore:
        reference = test_case.expected.reference_answer or ""
        
        if not reference:
            return CriterionScore(
                criterion=criterion.criterion,
                score=0.0,
                weight=criterion.weight,
                weighted_score=0.0,
                feedback="No reference answer provided"
            )
        
        # Compute embeddings
        embeddings = self.model.encode([response.raw_response, reference])
        similarity = util.cos_sim(embeddings[0], embeddings[1]).item()
        
        return CriterionScore(
            criterion=criterion.criterion,
            score=similarity,
            weight=criterion.weight,
            weighted_score=similarity * criterion.weight,
            feedback=f"Semantic similarity: {similarity:.2%}"
        )


class ValidationScorer(Scorer):
    """Score based on validation rules."""
    
    def __init__(self):
        self.validator = Validator()
    
    def score(
        self,
        response: ModelResponse,
        test_case: TestCase,
        criterion: ScoringCriterion
    ) -> CriterionScore:
        passed, errors = self.validator.validate(response, test_case)
        
        score = 1.0 if passed else 0.0
        feedback = "All validations passed" if passed else f"Validation failed: {'; '.join(errors)}"
        
        return CriterionScore(
            criterion=criterion.criterion,
            score=score,
            weight=criterion.weight,
            weighted_score=score * criterion.weight,
            feedback=feedback
        )


class ScoringEngine:
    """Main scoring engine."""
    
    DIFFICULTY_MULTIPLIERS = {
        DifficultyLevel.BEGINNER: 1.0,
        DifficultyLevel.INTERMEDIATE: 1.5,
        DifficultyLevel.ADVANCED: 2.0,
        DifficultyLevel.EXPERT: 3.0,
    }
    
    def __init__(self):
        self.scorers: Dict[str, Scorer] = {
            "exact_match": ExactMatchScorer(),
            "validation": ValidationScorer(),
        }
        
        if HAS_SENTENCE_TRANSFORMERS:
            self.scorers["semantic_similarity"] = SemanticSimilarityScorer()
    
    def score_response(
        self,
        response: ModelResponse,
        test_case: TestCase
    ) -> TestResult:
        """
        Score a model response against a test case.
        
        Returns:
            TestResult with all scoring details
        """
        criterion_scores = []
        
        # Score each criterion
        for criterion in test_case.expected.scoring_criteria:
            scorer = self._get_scorer(criterion)
            score = scorer.score(response, test_case, criterion)
            criterion_scores.append(score)
        
        # Calculate total score
        total_score = sum(cs.weighted_score for cs in criterion_scores)
        
        # Apply difficulty multiplier
        multiplier = self.DIFFICULTY_MULTIPLIERS.get(test_case.difficulty, 1.0)
        weighted_score = total_score * multiplier
        
        # Determine pass/fail
        passed = total_score >= 0.5  # Default threshold
        
        # Build feedback
        feedback_parts = [cs.feedback for cs in criterion_scores]
        feedback = "\n".join(feedback_parts)
        
        return TestResult(
            test_id=test_case.id,
            test_name=test_case.name,
            difficulty=test_case.difficulty,
            category=test_case.category,
            model_name=response.model_name,
            response=response,
            criterion_scores=criterion_scores,
            total_score=total_score,
            weighted_score=weighted_score,
            passed=passed,
            feedback=feedback,
            execution_time_ms=response.response_time_ms,
        )
    
    def _get_scorer(self, criterion: ScoringCriterion) -> Scorer:
        """Get appropriate scorer for a criterion."""
        # Default to validation scorer
        return self.scorers.get("validation", ValidationScorer())
