"""
Configuration loading and validation.
"""

import yaml
import json
from pathlib import Path
from typing import Dict, List, Optional, Any
from pydantic import ValidationError

from .models import BenchmarkConfig, TestCase, ModelInfo, ScoringCriterion


class ConfigLoader:
    """Load and validate benchmark configurations."""
    
    DEFAULT_DIFFICULTY_MULTIPLIERS = {
        "beginner": 1.0,
        "intermediate": 1.5,
        "advanced": 2.0,
        "expert": 3.0,
    }
    
    DEFAULT_CATEGORY_WEIGHTS = {
        "comprehension": 0.25,
        "bug_detection": 0.20,
        "refactoring": 0.20,
        "architecture": 0.20,
        "documentation": 0.15,
    }
    
    def __init__(self, config_dir: Optional[Path] = None):
        self.config_dir = config_dir or Path(__file__).parent.parent / "config"
        self._benchmark_cache: Dict[str, BenchmarkConfig] = {}
        self._model_cache: Dict[str, ModelInfo] = {}
    
    def load_benchmark(self, name: str) -> BenchmarkConfig:
        """Load a benchmark configuration by name."""
        if name in self._benchmark_cache:
            return self._benchmark_cache[name]
        
        config_path = self.config_dir / "benchmarks" / f"{name}.yaml"
        if not config_path.exists():
            raise FileNotFoundError(f"Benchmark config not found: {config_path}")
        
        with open(config_path, 'r') as f:
            data = yaml.safe_load(f)
        
        # Load test cases
        test_cases = []
        for test_file in data.get('test_files', []):
            test_path = self.config_dir.parent / "benchmarks" / test_file
            test_cases.extend(self._load_test_cases(test_path))
        
        # Apply defaults
        difficulty_multipliers = {
            **self.DEFAULT_DIFFICULTY_MULTIPLIERS,
            **data.get('difficulty_multipliers', {})
        }
        
        category_weights = {
            **self.DEFAULT_CATEGORY_WEIGHTS,
            **data.get('category_weights', {})
        }
        
        config = BenchmarkConfig(
            name=data['name'],
            description=data.get('description', ''),
            version=data.get('version', '1.0.0'),
            test_cases=test_cases,
            global_scoring_criteria=data.get('global_scoring_criteria', []),
            difficulty_multipliers=difficulty_multipliers,
            category_weights=category_weights,
        )
        
        self._benchmark_cache[name] = config
        return config
    
    def _load_test_cases(self, path: Path) -> List[TestCase]:
        """Load test cases from a file."""
        with open(path, 'r') as f:
            data = yaml.safe_load(f)
        
        test_cases = []
        for test_data in data.get('tests', []):
            try:
                # Load code snippet if file is specified
                if 'input' in test_data and 'code_file' in test_data['input']:
                    code_path = path.parent / test_data['input']['code_file']
                    if code_path.exists():
                        with open(code_path, 'r') as cf:
                            test_data['input']['code_snippet'] = cf.read()
                
                test_case = TestCase(**test_data)
                test_cases.append(test_case)
            except ValidationError as e:
                print(f"Warning: Skipping invalid test case: {e}")
        
        return test_cases
    
    def load_model_config(self, name: str) -> ModelInfo:
        """Load model configuration."""
        if name in self._model_cache:
            return self._model_cache[name]
        
        config_path = self.config_dir / "models.yaml"
        with open(config_path, 'r') as f:
            data = yaml.safe_load(f)
        
        if name not in data.get('models', {}):
            raise ValueError(f"Model '{name}' not found in configuration")
        
        model_data = data['models'][name]
        model_info = ModelInfo(
            name=name,
            version=model_data.get('version', 'unknown'),
            provider=model_data.get('provider', 'unknown'),
            parameters=model_data.get('parameters', {}),
            capabilities=model_data.get('capabilities', []),
        )
        
        self._model_cache[name] = model_info
        return model_info
    
    def list_benchmarks(self) -> List[str]:
        """List available benchmark configurations."""
        benchmarks_dir = self.config_dir / "benchmarks"
        if not benchmarks_dir.exists():
            return []
        
        return [
            f.stem for f in benchmarks_dir.glob("*.yaml")
            if f.is_file()
        ]
    
    def list_models(self) -> List[str]:
        """List available model configurations."""
        config_path = self.config_dir / "models.yaml"
        if not config_path.exists():
            return []
        
        with open(config_path, 'r') as f:
            data = yaml.safe_load(f)
        
        return list(data.get('models', {}).keys())
    
    def get_scoring_config(self) -> Dict[str, Any]:
        """Load global scoring configuration."""
        config_path = self.config_dir / "scoring.yaml"
        if not config_path.exists():
            return {}
        
        with open(config_path, 'r') as f:
            return yaml.safe_load(f) or {}


class ConfigBuilder:
    """Helper class to build benchmark configurations programmatically."""
    
    def __init__(self):
        self.data = {
            'name': '',
            'description': '',
            'version': '1.0.0',
            'tests': [],
        }
    
    def with_name(self, name: str) -> 'ConfigBuilder':
        self.data['name'] = name
        return self
    
    def with_description(self, description: str) -> 'ConfigBuilder':
        self.data['description'] = description
        return self
    
    def with_version(self, version: str) -> 'ConfigBuilder':
        self.data['version'] = version
        return self
    
    def add_test(self, test_case: TestCase) -> 'ConfigBuilder':
        self.data['tests'].append(test_case.dict())
        return self
    
    def build(self) -> Dict[str, Any]:
        return self.data
    
    def save(self, path: Path) -> None:
        """Save configuration to YAML file."""
        with open(path, 'w') as f:
            yaml.dump(self.data, f, default_flow_style=False, sort_keys=False)
