"""
Main benchmark runner.
"""

import asyncio
import time
from typing import List, Optional, Dict, Any, Callable
from pathlib import Path
from datetime import datetime

from rich.console import Console
from rich.progress import Progress, TaskID
from rich.table import Table

from .models import (
    BenchmarkConfig, TestCase, ModelInfo, ModelResponse,
    TestResult, BenchmarkResult, LeaderboardEntry
)
from .config import ConfigLoader
from .scoring import ScoringEngine
from .results import ResultsAggregator, ReportGenerator, LeaderboardManager
from ..runners.base import ModelRunner


class BenchmarkRunner:
    """
    Main benchmark orchestrator.
    
    Example:
        ```python
        runner = BenchmarkRunner()
        result = await runner.run(
            benchmark_name="rust_code_comprehension",
            model_runner=my_model_runner,
        )
        ```
    """
    
    def __init__(
        self,
        config_dir: Optional[Path] = None,
        output_dir: Optional[Path] = None,
        console: Optional[Console] = None,
    ):
        self.config_loader = ConfigLoader(config_dir)
        self.output_dir = output_dir or Path("results")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.console = console or Console()
        
        self.scoring_engine = ScoringEngine()
        self.results_aggregator = ResultsAggregator()
        self.report_generator = ReportGenerator()
        
        self.leaderboard = LeaderboardManager(
            self.output_dir / "leaderboard.json"
        )
        
        self._progress_callback: Optional[Callable[[str, float], None]] = None
    
    def set_progress_callback(self, callback: Callable[[str, float], None]):
        """Set a callback for progress updates."""
        self._progress_callback = callback
    
    async def run(
        self,
        benchmark_name: str,
        model_runner: ModelRunner,
        filter_difficulty: Optional[List[str]] = None,
        filter_category: Optional[List[str]] = None,
        filter_tags: Optional[List[str]] = None,
        max_tests: Optional[int] = None,
        parallel: bool = True,
        max_parallel: int = 4,
    ) -> BenchmarkResult:
        """
        Run a benchmark.
        
        Args:
            benchmark_name: Name of the benchmark to run
            model_runner: Model runner instance
            filter_difficulty: Only run tests with these difficulty levels
            filter_category: Only run tests in these categories
            filter_tags: Only run tests with these tags
            max_tests: Limit number of tests to run
            parallel: Run tests in parallel
            max_parallel: Maximum parallel tests
            
        Returns:
            BenchmarkResult with all results
        """
        # Load benchmark config
        self.console.print(f"[bold blue]Loading benchmark: {benchmark_name}[/bold blue]")
        config = self.config_loader.load_benchmark(benchmark_name)
        
        # Filter test cases
        test_cases = self._filter_tests(
            config.test_cases,
            filter_difficulty,
            filter_category,
            filter_tags,
            max_tests,
        )
        
        self.console.print(
            f"[green]Running {len(test_cases)} tests from {benchmark_name}[/green]"
        )
        
        # Run tests
        start_time = datetime.utcnow()
        
        if parallel and max_parallel > 1:
            test_results = await self._run_parallel(
                test_cases, model_runner, max_parallel
            )
        else:
            test_results = await self._run_sequential(test_cases, model_runner)
        
        end_time = datetime.utcnow()
        
        # Aggregate results
        result = self.results_aggregator.aggregate(
            test_results,
            benchmark_name,
            model_runner.get_model_info(),
        )
        
        # Save results
        self._save_results(result)
        
        # Update leaderboard
        self._update_leaderboard(result)
        
        return result
    
    def _filter_tests(
        self,
        test_cases: List[TestCase],
        filter_difficulty: Optional[List[str]] = None,
        filter_category: Optional[List[str]] = None,
        filter_tags: Optional[List[str]] = None,
        max_tests: Optional[int] = None,
    ) -> List[TestCase]:
        """Filter test cases based on criteria."""
        filtered = [tc for tc in test_cases if tc.enabled]
        
        if filter_difficulty:
            filtered = [tc for tc in filtered if tc.difficulty.value in filter_difficulty]
        
        if filter_category:
            filtered = [tc for tc in filtered if tc.category.value in filter_category]
        
        if filter_tags:
            filtered = [
                tc for tc in filtered
                if any(tag in tc.tags for tag in filter_tags)
            ]
        
        if max_tests:
            filtered = filtered[:max_tests]
        
        return filtered
    
    async def _run_sequential(
        self,
        test_cases: List[TestCase],
        model_runner: ModelRunner,
    ) -> List[TestResult]:
        """Run tests sequentially."""
        results = []
        
        with Progress(console=self.console) as progress:
            task = progress.add_task("[cyan]Running tests...", total=len(test_cases))
            
            for test_case in test_cases:
                progress.update(task, description=f"[cyan]Running: {test_case.name}[/cyan]")
                
                result = await self._run_single_test(test_case, model_runner)
                results.append(result)
                
                progress.advance(task)
                
                if self._progress_callback:
                    self._progress_callback(
                        test_case.name,
                        len(results) / len(test_cases)
                    )
        
        return results
    
    async def _run_parallel(
        self,
        test_cases: List[TestCase],
        model_runner: ModelRunner,
        max_parallel: int,
    ) -> List[TestResult]:
        """Run tests in parallel with semaphore."""
        semaphore = asyncio.Semaphore(max_parallel)
        results = []
        
        async def run_with_semaphore(test_case: TestCase) -> TestResult:
            async with semaphore:
                return await self._run_single_test(test_case, model_runner)
        
        with Progress(console=self.console) as progress:
            task = progress.add_task("[cyan]Running tests...", total=len(test_cases))
            
            # Create tasks
            tasks = [run_with_semaphore(tc) for tc in test_cases]
            
            # Run and collect results
            for i, coro in enumerate(asyncio.as_completed(tasks)):
                result = await coro
                results.append(result)
                
                progress.update(task, advance=1)
                
                if self._progress_callback:
                    self._progress_callback(
                        result.test_name,
                        len(results) / len(test_cases)
                    )
        
        return results
    
    async def _run_single_test(
        self,
        test_case: TestCase,
        model_runner: ModelRunner,
    ) -> TestResult:
        """Run a single test case."""
        # Build prompt
        prompt = self._build_prompt(test_case)
        
        # Get images
        images = []
        if test_case.input.image_file:
            images.append(test_case.input.image_file)
        
        # Generate response
        try:
            response = await model_runner.generate_with_metrics(
                test_id=test_case.id,
                prompt=prompt,
                images=images if images else None,
                system_prompt=test_case.input.system_prompt,
                temperature=0.7,
                max_tokens=4096,
            )
        except Exception as e:
            # Create error response
            response = ModelResponse(
                test_id=test_case.id,
                model_name=model_runner.get_model_info().name,
                raw_response=f"ERROR: {str(e)}",
                response_time_ms=0,
            )
        
        # Score response
        result = self.scoring_engine.score_response(response, test_case)
        
        return result
    
    def _build_prompt(self, test_case: TestCase) -> str:
        """Build the prompt for a test case."""
        parts = []
        
        # Add code if available
        if test_case.input.code_snippet:
            parts.append("Here is the Rust code:")
            parts.append("```rust")
            parts.append(test_case.input.code_snippet)
            parts.append("```")
            parts.append("")
        
        # Add the main prompt
        parts.append(test_case.input.prompt)
        
        # Add context if available
        if test_case.input.context:
            parts.append("")
            parts.append("Context:")
            parts.append(test_case.input.context)
        
        return "\n".join(parts)
    
    def _save_results(self, result: BenchmarkResult):
        """Save results to files."""
        timestamp = result.end_time.strftime("%Y%m%d_%H%M%S")
        model_name = result.model_info.name.replace("/", "_")
        
        base_path = self.output_dir / f"{result.benchmark_name}_{model_name}_{timestamp}"
        
        # Save JSON
        json_path = base_path.with_suffix(".json")
        with open(json_path, 'w') as f:
            f.write(self.report_generator.generate_json(result))
        
        # Save Markdown
        md_path = base_path.with_suffix(".md")
        with open(md_path, 'w') as f:
            f.write(self.report_generator.generate_markdown(result))
        
        # Save HTML
        html_path = base_path.with_suffix(".html")
        with open(html_path, 'w') as f:
            f.write(self.report_generator.generate_html(result))
        
        self.console.print(f"[green]Results saved to:[/green]")
        self.console.print(f"  - {json_path}")
        self.console.print(f"  - {md_path}")
        self.console.print(f"  - {html_path}")
    
    def _update_leaderboard(self, result: BenchmarkResult):
        """Update the leaderboard with new results."""
        entry = LeaderboardEntry(
            model_name=result.model_info.name,
            model_version=result.model_info.version,
            overall_score=result.overall_score,
            weighted_score=result.weighted_overall_score,
            category_scores={
                cs.category.value: cs.average_score
                for cs in result.category_scores
            },
            difficulty_scores={
                ds.difficulty.value: ds.average_score
                for ds in result.difficulty_scores
            },
            date=result.end_time,
            run_id=f"{result.benchmark_name}_{result.end_time.timestamp()}",
        )
        
        self.leaderboard.add_entry(entry)
        
        self.console.print(f"[green]Leaderboard updated[/green]")
    
    def print_summary(self, result: BenchmarkResult):
        """Print a summary of results to console."""
        self.console.print()
        self.console.print("[bold]=" * 60)
        self.console.print(f"[bold green]Benchmark Complete: {result.benchmark_name}[/bold green]")
        self.console.print("[bold]=" * 60)
        self.console.print()
        
        # Summary table
        summary_table = Table(title="Summary")
        summary_table.add_column("Metric", style="cyan")
        summary_table.add_column("Value", style="green")
        
        summary_table.add_row("Model", f"{result.model_info.name} ({result.model_info.version})")
        summary_table.add_row("Overall Score", f"{result.overall_score:.2%}")
        summary_table.add_row("Weighted Score", f"{result.weighted_overall_score:.2%}")
        summary_table.add_row("Tests Passed", f"{result.tests_passed}/{result.total_tests}")
        summary_table.add_row("Success Rate", f"{result.tests_passed/result.total_tests:.1%}")
        
        self.console.print(summary_table)
        self.console.print()
        
        # Category scores
        cat_table = Table(title="Category Scores")
        cat_table.add_column("Category", style="cyan")
        cat_table.add_column("Tests", style="white")
        cat_table.add_column("Avg Score", style="green")
        cat_table.add_column("Weighted", style="yellow")
        
        for cat in sorted(result.category_scores, key=lambda x: x.average_score, reverse=True):
            cat_table.add_row(
                cat.category.value,
                str(cat.test_count),
                f"{cat.average_score:.2%}",
                f"{cat.weighted_average:.2%}",
            )
        
        self.console.print(cat_table)
        self.console.print()
        
        # Difficulty scores
        diff_table = Table(title="Difficulty Scores")
        diff_table.add_column("Difficulty", style="cyan")
        diff_table.add_column("Tests", style="white")
        diff_table.add_column("Avg Score", style="green")
        diff_table.add_column("Weighted", style="yellow")
        
        from .models import DifficultyLevel
        difficulty_order = [
            DifficultyLevel.BEGINNER,
            DifficultyLevel.INTERMEDIATE,
            DifficultyLevel.ADVANCED,
            DifficultyLevel.EXPERT,
        ]
        
        diff_map = {d.difficulty: d for d in result.difficulty_scores}
        for diff in difficulty_order:
            if diff in diff_map:
                d = diff_map[diff]
                diff_table.add_row(
                    diff.value,
                    str(d.test_count),
                    f"{d.average_score:.2%}",
                    f"{d.weighted_average:.2%}",
                )
        
        self.console.print(diff_table)
        self.console.print()
