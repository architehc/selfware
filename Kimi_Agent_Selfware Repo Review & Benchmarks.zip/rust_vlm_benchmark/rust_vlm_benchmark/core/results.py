"""
Results aggregation and reporting.
"""

import json
from typing import Dict, List, Any
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from .models import (
    TestResult, BenchmarkResult, CategoryScore, DifficultyScore,
    Category, DifficultyLevel, LeaderboardEntry
)


class ResultsAggregator:
    """Aggregate results from multiple test runs."""
    
    def aggregate(self, test_results: List[TestResult], benchmark_name: str, model_info: Any) -> BenchmarkResult:
        """
        Aggregate test results into a benchmark result.
        
        Args:
            test_results: List of individual test results
            benchmark_name: Name of the benchmark
            model_info: Information about the model tested
            
        Returns:
            Aggregated BenchmarkResult
        """
        if not test_results:
            raise ValueError("No test results to aggregate")
        
        # Calculate overall statistics
        total_tests = len(test_results)
        tests_passed = sum(1 for r in test_results if r.passed)
        tests_failed = total_tests - tests_passed
        
        overall_score = sum(r.total_score for r in test_results) / total_tests
        weighted_overall = sum(r.weighted_score for r in test_results) / total_tests
        
        # Aggregate by category
        category_scores = self._aggregate_by_category(test_results)
        
        # Aggregate by difficulty
        difficulty_scores = self._aggregate_by_difficulty(test_results)
        
        return BenchmarkResult(
            benchmark_name=benchmark_name,
            model_info=model_info,
            start_time=min(r.timestamp for r in test_results),
            end_time=max(r.timestamp for r in test_results),
            total_tests=total_tests,
            tests_passed=tests_passed,
            tests_failed=tests_failed,
            overall_score=overall_score,
            weighted_overall_score=weighted_overall,
            category_scores=category_scores,
            difficulty_scores=difficulty_scores,
            test_results=test_results,
        )
    
    def _aggregate_by_category(self, test_results: List[TestResult]) -> List[CategoryScore]:
        """Aggregate results by category."""
        by_category = defaultdict(list)
        
        for result in test_results:
            by_category[result.category].append(result)
        
        category_scores = []
        for category, results in by_category.items():
            test_count = len(results)
            avg_score = sum(r.total_score for r in results) / test_count
            weighted_avg = sum(r.weighted_score for r in results) / test_count
            passed = sum(1 for r in results if r.passed)
            failed = test_count - passed
            
            category_scores.append(CategoryScore(
                category=category,
                test_count=test_count,
                average_score=avg_score,
                weighted_average=weighted_avg,
                tests_passed=passed,
                tests_failed=failed,
            ))
        
        return category_scores
    
    def _aggregate_by_difficulty(self, test_results: List[TestResult]) -> List[DifficultyScore]:
        """Aggregate results by difficulty level."""
        by_difficulty = defaultdict(list)
        
        for result in test_results:
            by_difficulty[result.difficulty].append(result)
        
        difficulty_scores = []
        for difficulty, results in by_difficulty.items():
            test_count = len(results)
            avg_score = sum(r.total_score for r in results) / test_count
            weighted_avg = sum(r.weighted_score for r in results) / test_count
            passed = sum(1 for r in results if r.passed)
            failed = test_count - passed
            
            difficulty_scores.append(DifficultyScore(
                difficulty=difficulty,
                test_count=test_count,
                average_score=avg_score,
                weighted_average=weighted_avg,
                tests_passed=passed,
                tests_failed=failed,
            ))
        
        return difficulty_scores
    
    def compare_results(
        self,
        result1: BenchmarkResult,
        result2: BenchmarkResult
    ) -> Dict[str, Any]:
        """Compare two benchmark results."""
        comparison = {
            "model1": result1.model_info.name,
            "model2": result2.model_info.name,
            "overall_diff": result1.overall_score - result2.overall_score,
            "weighted_diff": result1.weighted_overall_score - result2.weighted_overall_score,
            "category_comparison": {},
            "difficulty_comparison": {},
        }
        
        # Compare categories
        cat1 = {c.category: c for c in result1.category_scores}
        cat2 = {c.category: c for c in result2.category_scores}
        
        for category in set(cat1.keys()) | set(cat2.keys()):
            s1 = cat1.get(category)
            s2 = cat2.get(category)
            
            if s1 and s2:
                comparison["category_comparison"][category.value] = {
                    "model1_score": s1.average_score,
                    "model2_score": s2.average_score,
                    "diff": s1.average_score - s2.average_score,
                }
        
        # Compare difficulties
        diff1 = {d.difficulty: d for d in result1.difficulty_scores}
        diff2 = {d.difficulty: d for d in result2.difficulty_scores}
        
        for difficulty in set(diff1.keys()) | set(diff2.keys()):
            s1 = diff1.get(difficulty)
            s2 = diff2.get(difficulty)
            
            if s1 and s2:
                comparison["difficulty_comparison"][difficulty.value] = {
                    "model1_score": s1.average_score,
                    "model2_score": s2.average_score,
                    "diff": s1.average_score - s2.average_score,
                }
        
        return comparison


class ReportGenerator:
    """Generate reports from benchmark results."""
    
    def generate_markdown(self, result: BenchmarkResult) -> str:
        """Generate a Markdown report."""
        lines = [
            f"# Benchmark Results: {result.benchmark_name}",
            "",
            f"**Model:** {result.model_info.name} ({result.model_info.version})",
            f"**Date:** {result.end_time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"**Duration:** {(result.end_time - result.start_time).total_seconds():.1f}s",
            "",
            "## Summary",
            "",
            f"- **Overall Score:** {result.overall_score:.2%}",
            f"- **Weighted Score:** {result.weighted_overall_score:.2%}",
            f"- **Tests Passed:** {result.tests_passed}/{result.total_tests}",
            f"- **Success Rate:** {result.tests_passed/result.total_tests:.1%}",
            "",
            "## Category Scores",
            "",
            "| Category | Tests | Avg Score | Weighted | Passed | Failed |",
            "|----------|-------|-----------|----------|--------|--------|",
        ]
        
        for cat in sorted(result.category_scores, key=lambda x: x.average_score, reverse=True):
            lines.append(
                f"| {cat.category.value} | {cat.test_count} | "
                f"{cat.average_score:.2%} | {cat.weighted_average:.2%} | "
                f"{cat.tests_passed} | {cat.tests_failed} |"
            )
        
        lines.extend([
            "",
            "## Difficulty Scores",
            "",
            "| Difficulty | Tests | Avg Score | Weighted | Passed | Failed |",
            "|------------|-------|-----------|----------|--------|--------|",
        ])
        
        difficulty_order = [
            DifficultyLevel.BEGINNER,
            DifficultyLevel.INTERMEDIATE,
            DifficultyLevel.ADVANCED,
            DifficultyLevel.EXPERT,
        ]
        
        diff_map = {d.difficulty: d for d in result.difficulty_scores}
        for diff in difficulty_order:
            if diff in diff_map:
                d = diff_map[diff]
                lines.append(
                    f"| {diff.value} | {d.test_count} | "
                    f"{d.average_score:.2%} | {d.weighted_average:.2%} | "
                    f"{d.tests_passed} | {d.tests_failed} |"
                )
        
        lines.extend([
            "",
            "## Detailed Results",
            "",
        ])
        
        for test in result.test_results:
            status = "✅" if test.passed else "❌"
            lines.extend([
                f"### {status} {test.test_name}",
                "",
                f"- **ID:** {test.test_id}",
                f"- **Category:** {test.category.value}",
                f"- **Difficulty:** {test.difficulty.value}",
                f"- **Score:** {test.total_score:.2%}",
                f"- **Weighted:** {test.weighted_score:.2%}",
                f"- **Time:** {test.execution_time_ms}ms",
                "",
                "**Feedback:**",
                "",
                f"{test.feedback}",
                "",
                "---",
                "",
            ])
        
        return "\n".join(lines)
    
    def generate_json(self, result: BenchmarkResult) -> str:
        """Generate a JSON report."""
        return json.dumps(result.dict(), indent=2, default=str)
    
    def generate_html(self, result: BenchmarkResult) -> str:
        """Generate an HTML report."""
        # Simple HTML template
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Benchmark Results - {result.benchmark_name}</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        h1, h2, h3 {{ color: #333; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
        th {{ background-color: #4CAF50; color: white; }}
        tr:nth-child(even) {{ background-color: #f2f2f2; }}
        .pass {{ color: green; }}
        .fail {{ color: red; }}
        .summary {{ background: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .test-result {{ margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }}
        .feedback {{ background: #f5f5f5; padding: 10px; border-radius: 3px; margin-top: 10px; }}
    </style>
</head>
<body>
    <h1>Benchmark Results: {result.benchmark_name}</h1>
    
    <div class="summary">
        <h2>Summary</h2>
        <p><strong>Model:</strong> {result.model_info.name} ({result.model_info.version})</p>
        <p><strong>Date:</strong> {result.end_time.strftime('%Y-%m-%d %H:%M:%S')}</p>
        <p><strong>Overall Score:</strong> {result.overall_score:.2%}</p>
        <p><strong>Weighted Score:</strong> {result.weighted_overall_score:.2%}</p>
        <p><strong>Tests Passed:</strong> {result.tests_passed}/{result.total_tests}</p>
    </div>
    
    <h2>Category Scores</h2>
    <table>
        <tr>
            <th>Category</th>
            <th>Tests</th>
            <th>Average Score</th>
            <th>Weighted</th>
            <th>Passed</th>
            <th>Failed</th>
        </tr>
"""
        
        for cat in sorted(result.category_scores, key=lambda x: x.average_score, reverse=True):
            html += f"""
        <tr>
            <td>{cat.category.value}</td>
            <td>{cat.test_count}</td>
            <td>{cat.average_score:.2%}</td>
            <td>{cat.weighted_average:.2%}</td>
            <td>{cat.tests_passed}</td>
            <td>{cat.tests_failed}</td>
        </tr>
"""
        
        html += """
    </table>
    
    <h2>Detailed Results</h2>
"""
        
        for test in result.test_results:
            status_class = "pass" if test.passed else "fail"
            status_text = "PASS" if test.passed else "FAIL"
            html += f"""
    <div class="test-result">
        <h3><span class="{status_class}">{status_text}</span> {test.test_name}</h3>
        <p><strong>ID:</strong> {test.test_id}</p>
        <p><strong>Category:</strong> {test.category.value}</p>
        <p><strong>Difficulty:</strong> {test.difficulty.value}</p>
        <p><strong>Score:</strong> {test.total_score:.2%}</p>
        <div class="feedback">
            <strong>Feedback:</strong><br>
            {test.feedback.replace(chr(10), '<br>')}
        </div>
    </div>
"""
        
        html += """
</body>
</html>
"""
        return html


class LeaderboardManager:
    """Manage benchmark leaderboard."""
    
    def __init__(self, leaderboard_path: Path):
        self.leaderboard_path = leaderboard_path
        self.entries: List[LeaderboardEntry] = []
        self._load()
    
    def _load(self):
        """Load leaderboard from file."""
        if self.leaderboard_path.exists():
            with open(self.leaderboard_path, 'r') as f:
                data = json.load(f)
                self.entries = [LeaderboardEntry(**entry) for entry in data]
    
    def save(self):
        """Save leaderboard to file."""
        self.leaderboard_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.leaderboard_path, 'w') as f:
            json.dump([entry.dict() for entry in self.entries], f, indent=2, default=str)
    
    def add_entry(self, entry: LeaderboardEntry):
        """Add a new entry to the leaderboard."""
        self.entries.append(entry)
        self._sort_entries()
        self.save()
    
    def _sort_entries(self):
        """Sort entries by weighted score (descending)."""
        self.entries.sort(key=lambda x: x.weighted_score, reverse=True)
    
    def get_top(self, n: int = 10) -> List[LeaderboardEntry]:
        """Get top N entries."""
        return self.entries[:n]
    
    def get_ranking(self, model_name: str) -> Optional[int]:
        """Get ranking for a specific model."""
        for i, entry in enumerate(self.entries):
            if entry.model_name == model_name:
                return i + 1
        return None
    
    def generate_markdown(self) -> str:
        """Generate leaderboard as Markdown."""
        lines = [
            "# Benchmark Leaderboard",
            "",
            "| Rank | Model | Version | Overall | Weighted | Date |",
            "|------|-------|---------|---------|----------|------|",
        ]
        
        for i, entry in enumerate(self.entries[:20], 1):
            lines.append(
                f"| {i} | {entry.model_name} | {entry.model_version} | "
                f"{entry.overall_score:.2%} | {entry.weighted_score:.2%} | "
                f"{entry.date.strftime('%Y-%m-%d')} |"
            )
        
        return "\n".join(lines)
