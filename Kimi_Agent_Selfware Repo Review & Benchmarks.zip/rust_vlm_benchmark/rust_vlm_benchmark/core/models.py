"""
Data models for the benchmark framework.
"""

from enum import Enum
from typing import Dict, List, Optional, Any, Union
from pydantic import BaseModel, Field
from datetime import datetime


class DifficultyLevel(str, Enum):
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
    EXPERT = "expert"


class Category(str, Enum):
    COMPREHENSION = "comprehension"
    BUG_DETECTION = "bug_detection"
    REFACTORING = "refactoring"
    ARCHITECTURE = "architecture"
    DOCUMENTATION = "documentation"
    OPTIMIZATION = "optimization"


class OutputFormat(str, Enum):
    JSON = "json"
    CODE = "code"
    TEXT = "text"
    MARKDOWN = "markdown"


class ValidationRule(BaseModel):
    """Rule for validating model responses."""
    type: str = Field(..., description="Type of validation: contains, regex, json_schema, compile, execute")
    field: Optional[str] = Field(None, description="Field to validate (for JSON output)")
    value: Optional[str] = Field(None, description="Expected value (for contains)")
    pattern: Optional[str] = Field(None, description="Regex pattern (for regex)")
    schema: Optional[Dict[str, Any]] = Field(None, description="JSON schema (for json_schema)")
    command: Optional[str] = Field(None, description="Command to run (for compile/execute)")
    expected_exit_code: Optional[int] = Field(0, description="Expected exit code")


class ScoringCriterion(BaseModel):
    """Individual scoring criterion."""
    criterion: str = Field(..., description="Name of the criterion")
    weight: float = Field(..., ge=0.0, le=1.0, description="Weight of this criterion")
    description: str = Field("", description="Description of what this criterion measures")
    validation_rules: List[ValidationRule] = Field(default_factory=list)


class TestInput(BaseModel):
    """Input for a test case."""
    code_file: Optional[str] = Field(None, description="Path to Rust code file")
    code_snippet: Optional[str] = Field(None, description="Inline code snippet")
    image_file: Optional[str] = Field(None, description="Path to image (screenshot/diagram)")
    prompt: str = Field(..., description="Question or task for the model")
    context: Optional[str] = Field(None, description="Additional context")
    system_prompt: Optional[str] = Field(None, description="System prompt override")


class TestExpected(BaseModel):
    """Expected output and validation rules."""
    output_format: OutputFormat = Field(default=OutputFormat.TEXT)
    validation_rules: List[ValidationRule] = Field(default_factory=list)
    scoring_criteria: List[ScoringCriterion] = Field(default_factory=list)
    reference_answer: Optional[str] = Field(None, description="Reference answer for comparison")


class TestCase(BaseModel):
    """Complete test case definition."""
    id: str = Field(..., description="Unique test identifier")
    name: str = Field(..., description="Human-readable test name")
    difficulty: DifficultyLevel
    category: Category
    tags: List[str] = Field(default_factory=list)
    input: TestInput
    expected: TestExpected
    timeout_seconds: int = Field(default=60, description="Timeout for model response")
    enabled: bool = Field(default=True, description="Whether test is enabled")


class ModelInfo(BaseModel):
    """Information about a model."""
    name: str
    version: str
    provider: str
    parameters: Dict[str, Any] = Field(default_factory=dict)
    capabilities: List[str] = Field(default_factory=list)


class ModelResponse(BaseModel):
    """Raw response from a model."""
    test_id: str
    model_name: str
    raw_response: str
    extracted_output: Optional[str] = None
    extracted_code: Optional[str] = None
    extracted_json: Optional[Dict[str, Any]] = None
    response_time_ms: int
    tokens_used: Optional[int] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class CriterionScore(BaseModel):
    """Score for a single criterion."""
    criterion: str
    score: float  # 0.0 to 1.0
    weight: float
    weighted_score: float
    feedback: str


class TestResult(BaseModel):
    """Result of running a single test."""
    test_id: str
    test_name: str
    difficulty: DifficultyLevel
    category: Category
    model_name: str
    response: ModelResponse
    criterion_scores: List[CriterionScore]
    total_score: float  # 0.0 to 1.0
    weighted_score: float  # Score × difficulty multiplier
    passed: bool
    feedback: str
    execution_time_ms: int
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class CategoryScore(BaseModel):
    """Aggregated score for a category."""
    category: Category
    test_count: int
    average_score: float
    weighted_average: float
    tests_passed: int
    tests_failed: int


class DifficultyScore(BaseModel):
    """Aggregated score for a difficulty level."""
    difficulty: DifficultyLevel
    test_count: int
    average_score: float
    weighted_average: float
    tests_passed: int
    tests_failed: int


class BenchmarkResult(BaseModel):
    """Complete benchmark results."""
    benchmark_name: str
    model_info: ModelInfo
    start_time: datetime
    end_time: datetime
    total_tests: int
    tests_passed: int
    tests_failed: int
    overall_score: float
    weighted_overall_score: float
    category_scores: List[CategoryScore]
    difficulty_scores: List[DifficultyScore]
    test_results: List[TestResult]
    metadata: Dict[str, Any] = Field(default_factory=dict)


class BenchmarkConfig(BaseModel):
    """Configuration for a benchmark run."""
    name: str
    description: str
    version: str
    test_cases: List[TestCase]
    global_scoring_criteria: List[ScoringCriterion] = Field(default_factory=list)
    difficulty_multipliers: Dict[DifficultyLevel, float] = Field(
        default_factory=lambda: {
            DifficultyLevel.BEGINNER: 1.0,
            DifficultyLevel.INTERMEDIATE: 1.5,
            DifficultyLevel.ADVANCED: 2.0,
            DifficultyLevel.EXPERT: 3.0,
        }
    )
    category_weights: Dict[Category, float] = Field(default_factory=dict)


class LeaderboardEntry(BaseModel):
    """Entry in the leaderboard."""
    model_name: str
    model_version: str
    overall_score: float
    weighted_score: float
    category_scores: Dict[str, float]
    difficulty_scores: Dict[str, float]
    date: datetime
    run_id: str
