"""
Command-line interface for the benchmark framework.
"""

import asyncio
import click
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.table import Table

from .core.config import ConfigLoader
from .core.benchmark import BenchmarkRunner
from .core.results import LeaderboardManager, ReportGenerator
from .runners.ollama import OllamaRunner
from .runners.openai_runner import OpenAIRunner
from .core.models import ModelInfo


console = Console()


@click.group()
@click.option('--config-dir', type=click.Path(), help='Configuration directory')
@click.option('--output-dir', type=click.Path(), help='Output directory for results')
@click.pass_context
def cli(ctx, config_dir: Optional[str], output_dir: Optional[str]):
    """RustVLM-Bench: Visual Language Model Benchmark for Rust Code"""
    ctx.ensure_object(dict)
    ctx.obj['config_dir'] = Path(config_dir) if config_dir else None
    ctx.obj['output_dir'] = Path(output_dir) if output_dir else Path("results")


@cli.command()
@click.argument('benchmark')
@click.option('--model', '-m', required=True, help='Model name')
@click.option('--host', default='localhost', help='Model host (for local models)')
@click.option('--port', default=11434, type=int, help='Model port (for local models)')
@click.option('--api-key', help='API key (for cloud models)')
@click.option('--runner', default='ollama', type=click.Choice(['ollama', 'openai']), help='Runner type')
@click.option('--difficulty', multiple=True, help='Filter by difficulty level')
@click.option('--category', multiple=True, help='Filter by category')
@click.option('--max-tests', type=int, help='Maximum number of tests to run')
@click.option('--parallel/--no-parallel', default=True, help='Run tests in parallel')
@click.option('--max-parallel', default=4, type=int, help='Maximum parallel tests')
@click.option('--fail-below', type=float, help='Exit with error if score below threshold')
@click.pass_context
def run(
    ctx,
    benchmark: str,
    model: str,
    host: str,
    port: int,
    api_key: Optional[str],
    runner: str,
    difficulty: tuple,
    category: tuple,
    max_tests: Optional[int],
    parallel: bool,
    max_parallel: int,
    fail_below: Optional[float],
):
    """Run a benchmark against a model."""
    config_dir = ctx.obj.get('config_dir')
    output_dir = ctx.obj.get('output_dir')
    
    # Create model runner
    model_info = ModelInfo(
        name=model,
        version="latest",
        provider=runner,
    )
    
    if runner == 'ollama':
        model_runner = OllamaRunner(
            model_info=model_info,
            host=host,
            port=port,
        )
    elif runner == 'openai':
        model_runner = OpenAIRunner(
            model_info=model_info,
            api_key=api_key,
        )
    else:
        console.print(f"[red]Unknown runner: {runner}[/red]")
        return
    
    # Check if model is available
    if not model_runner.is_available():
        console.print(f"[red]Model '{model}' is not available[/red]")
        health = model_runner.health_check()
        console.print(health)
        return
    
    # Create benchmark runner
    benchmark_runner = BenchmarkRunner(
        config_dir=config_dir,
        output_dir=output_dir,
        console=console,
    )
    
    # Run benchmark
    async def run_benchmark():
        result = await benchmark_runner.run(
            benchmark_name=benchmark,
            model_runner=model_runner,
            filter_difficulty=list(difficulty) if difficulty else None,
            filter_category=list(category) if category else None,
            max_tests=max_tests,
            parallel=parallel,
            max_parallel=max_parallel,
        )
        
        benchmark_runner.print_summary(result)
        
        if fail_below is not None:
            if result.overall_score < fail_below:
                console.print(f"[red]Score {result.overall_score:.2%} below threshold {fail_below:.2%}[/red]")
                raise click.ClickException(f"Benchmark failed: score below threshold")
    
    asyncio.run(run_benchmark())


@cli.command()
@click.option('--output', '-o', type=click.Choice(['markdown', 'json', 'html']), default='markdown')
@click.pass_context
def leaderboard(ctx, output: str):
    """Show the benchmark leaderboard."""
    output_dir = ctx.obj.get('output_dir')
    lb = LeaderboardManager(output_dir / "leaderboard.json")
    
    if output == 'markdown':
        console.print(lb.generate_markdown())
    elif output == 'json':
        import json
        entries = [entry.dict() for entry in lb.get_top(20)]
        console.print(json.dumps(entries, indent=2, default=str))
    elif output == 'html':
        # Simple HTML leaderboard
        html = "<h1>Leaderboard</h1><table>"
        html += "<tr><th>Rank</th><th>Model</th><th>Score</th></tr>"
        for i, entry in enumerate(lb.get_top(20), 1):
            html += f"<tr><td>{i}</td><td>{entry.model_name}</td><td>{entry.overall_score:.2%}</td></tr>"
        html += "</table>"
        console.print(html)


@cli.command()
@click.argument('results_file', type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Choice(['markdown', 'json', 'html']), default='markdown')
def report(results_file: str, output: str):
    """Generate a report from a results file."""
    import json
    
    with open(results_file, 'r') as f:
        data = json.load(f)
    
    from .core.models import BenchmarkResult
    result = BenchmarkResult(**data)
    
    generator = ReportGenerator()
    
    if output == 'markdown':
        console.print(generator.generate_markdown(result))
    elif output == 'json':
        console.print(generator.generate_json(result))
    elif output == 'html':
        console.print(generator.generate_html(result))


@cli.command()
@click.pass_context
def list_benchmarks(ctx):
    """List available benchmarks."""
    config_dir = ctx.obj.get('config_dir')
    loader = ConfigLoader(config_dir)
    
    benchmarks = loader.list_benchmarks()
    
    table = Table(title="Available Benchmarks")
    table.add_column("Name", style="cyan")
    
    for name in benchmarks:
        table.add_row(name)
    
    console.print(table)


@cli.command()
@click.pass_context
def list_models(ctx):
    """List configured models."""
    config_dir = ctx.obj.get('config_dir')
    loader = ConfigLoader(config_dir)
    
    models = loader.list_models()
    
    table = Table(title="Configured Models")
    table.add_column("Name", style="cyan")
    
    for name in models:
        table.add_row(name)
    
    console.print(table)


@cli.command()
@click.option('--model', '-m', required=True, help='Model name')
@click.option('--host', default='localhost', help='Model host')
@click.option('--port', default=11434, type=int, help='Model port')
def check(model: str, host: str, port: int):
    """Check if a model is available."""
    model_info = ModelInfo(name=model, version="latest", provider="ollama")
    runner = OllamaRunner(model_info=model_info, host=host, port=port)
    
    health = runner.health_check()
    
    table = Table(title=f"Health Check: {model}")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")
    
    for key, value in health.items():
        table.add_row(key, str(value))
    
    console.print(table)


@cli.command()
@click.option('--benchmark', required=True, help='Benchmark name')
@click.option('--output', '-o', type=click.Path(), help='Output file')
@click.pass_context
def export_config(ctx, benchmark: str, output: Optional[str]):
    """Export a benchmark configuration."""
    config_dir = ctx.obj.get('config_dir')
    loader = ConfigLoader(config_dir)
    
    config = loader.load_benchmark(benchmark)
    
    import yaml
    
    data = {
        'name': config.name,
        'description': config.description,
        'version': config.version,
        'test_count': len(config.test_cases),
        'difficulty_multipliers': config.difficulty_multipliers,
        'category_weights': config.category_weights,
    }
    
    if output:
        with open(output, 'w') as f:
            yaml.dump(data, f, default_flow_style=False)
        console.print(f"[green]Configuration exported to {output}[/green]")
    else:
        console.print(yaml.dump(data, default_flow_style=False))


def main():
    """Entry point for the CLI."""
    cli()


if __name__ == '__main__':
    main()
