"""
Ollama model runner for local models like Qwen3.5.
"""

import base64
import aiohttp
import json
from typing import List, Optional, Dict, Any
from pathlib import Path

from .base import ModelRunner, ModelRunnerFactory
from ..core.models import ModelInfo


class OllamaRunner(ModelRunner):
    """
    Runner for Ollama-hosted models.
    
    Supports vision models like Qwen3.5-VL through Ollama's API.
    
    Example:
        ```python
        model_info = ModelInfo(
            name="qwen3.5-vl",
            version="latest",
            provider="ollama"
        )
        runner = OllamaRunner(model_info, host="localhost", port=11434)
        response = await runner.generate(
            prompt="Explain this Rust code",
            images=["code_screenshot.png"]
        )
        ```
    """
    
    def __init__(
        self,
        model_info: ModelInfo,
        host: str = "localhost",
        port: int = 11434,
        timeout: int = 120,
        **kwargs
    ):
        super().__init__(model_info, **kwargs)
        self.host = host
        self.port = port
        self.timeout = timeout
        self.base_url = f"http://{host}:{port}"
    
    def _get_api_url(self, endpoint: str) -> str:
        """Build API URL."""
        return f"{self.base_url}/api/{endpoint}"
    
    async def generate(
        self,
        prompt: str,
        images: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        """
        Generate response using Ollama API.
        
        Args:
            prompt: The main prompt
            images: List of image file paths (for vision models)
            system_prompt: System prompt
            temperature: Sampling temperature (0.0 to 1.0)
            max_tokens: Maximum tokens to generate
            
        Returns:
            Generated response text
        """
        # Build messages
        messages = []
        
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })
        
        # Build user message
        user_message = {
            "role": "user",
            "content": prompt
        }
        
        # Add images if provided
        if images:
            user_message["images"] = []
            for image_path in images:
                with open(image_path, 'rb') as f:
                    image_data = base64.b64encode(f.read()).decode('utf-8')
                    user_message["images"].append(image_data)
        
        messages.append(user_message)
        
        # Build request payload
        payload = {
            "model": self.model_info.name,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": temperature,
            }
        }
        
        if max_tokens:
            payload["options"]["num_predict"] = max_tokens
        
        # Make request
        async with aiohttp.ClientSession() as session:
            async with session.post(
                self._get_api_url("chat"),
                json=payload,
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Ollama API error: {response.status} - {error_text}")
                
                result = await response.json()
                return result.get("message", {}).get("content", "")
    
    def is_available(self) -> bool:
        """Check if Ollama is running and model is available."""
        import requests
        try:
            response = requests.get(
                f"{self.base_url}/api/tags",
                timeout=5
            )
            if response.status_code != 200:
                return False
            
            # Check if model exists
            models = response.json().get("models", [])
            model_names = [m.get("name", "").split(":")[0] for m in models]
            return self.model_info.name in model_names
        except Exception:
            return False
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """List available models in Ollama."""
        async with aiohttp.ClientSession() as session:
            async with session.get(self._get_api_url("tags")) as response:
                if response.status == 200:
                    result = await response.json()
                    return result.get("models", [])
                return []
    
    async def pull_model(self) -> bool:
        """Pull the model if not available."""
        async with aiohttp.ClientSession() as session:
            async with session.post(
                self._get_api_url("pull"),
                json={"name": self.model_info.name, "stream": False}
            ) as response:
                return response.status == 200
    
    def health_check(self) -> Dict[str, Any]:
        """Perform health check."""
        import requests
        health = {
            "available": False,
            "model_name": self.model_info.name,
            "model_version": self.model_info.version,
            "host": self.host,
            "port": self.port,
        }
        
        try:
            response = requests.get(
                f"{self.base_url}/api/tags",
                timeout=5
            )
            health["ollama_running"] = response.status == 200
            
            if response.status == 200:
                models = response.json().get("models", [])
                model_names = [m.get("name", "").split(":")[0] for m in models]
                health["model_available"] = self.model_info.name in model_names
                health["available"] = health["model_available"]
                health["available_models"] = model_names
        except Exception as e:
            health["error"] = str(e)
            health["ollama_running"] = False
        
        return health


# Register the runner
ModelRunnerFactory.register("ollama", OllamaRunner)
