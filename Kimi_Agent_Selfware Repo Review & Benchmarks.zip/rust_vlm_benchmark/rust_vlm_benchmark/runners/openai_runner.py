"""
OpenAI API model runner.
"""

import base64
from typing import List, Optional, Dict, Any
from pathlib import Path

try:
    import openai
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

from .base import ModelRunner, ModelRunnerFactory
from ..core.models import ModelInfo


class OpenAIRunner(ModelRunner):
    """
    Runner for OpenAI API models (GPT-4, GPT-4V, etc.).
    
    Example:
        ```python
        model_info = ModelInfo(
            name="gpt-4-vision-preview",
            version="2024-01",
            provider="openai"
        )
        runner = OpenAIRunner(model_info, api_key="sk-...")
        response = await runner.generate(
            prompt="Explain this Rust code",
            images=["code_screenshot.png"]
        )
        ```
    """
    
    def __init__(
        self,
        model_info: ModelInfo,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 120,
        **kwargs
    ):
        if not HAS_OPENAI:
            raise ImportError("openai package required. Install with: pip install openai")
        
        super().__init__(model_info, **kwargs)
        
        self.client = openai.AsyncOpenAI(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
        )
    
    async def generate(
        self,
        prompt: str,
        images: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        """Generate response using OpenAI API."""
        messages = []
        
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })
        
        # Build content
        content = []
        
        # Add text
        content.append({
            "type": "text",
            "text": prompt
        })
        
        # Add images
        if images:
            for image_path in images:
                with open(image_path, 'rb') as f:
                    image_data = base64.b64encode(f.read()).decode('utf-8')
                    content.append({
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/png;base64,{image_data}"
                        }
                    })
        
        messages.append({
            "role": "user",
            "content": content if len(content) > 1 else prompt
        })
        
        # Make request
        params = {
            "model": self.model_info.name,
            "messages": messages,
            "temperature": temperature,
        }
        
        if max_tokens:
            params["max_tokens"] = max_tokens
        
        response = await self.client.chat.completions.create(**params)
        return response.choices[0].message.content
    
    def is_available(self) -> bool:
        """Check if API key is configured."""
        return self.client.api_key is not None
    
    def health_check(self) -> Dict[str, Any]:
        """Perform health check."""
        health = {
            "available": self.is_available(),
            "model_name": self.model_info.name,
            "model_version": self.model_info.version,
            "api_configured": self.client.api_key is not None,
        }
        return health


# Register the runner
ModelRunnerFactory.register("openai", OpenAIRunner)
