"""
Base model runner interface.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
import time

from ..core.models import ModelInfo, ModelResponse


class ModelRunner(ABC):
    """Abstract base class for model runners."""
    
    def __init__(self, model_info: ModelInfo, **kwargs):
        self.model_info = model_info
        self.config = kwargs
    
    @abstractmethod
    async def generate(
        self,
        prompt: str,
        images: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        """
        Generate a response from the model.
        
        Args:
            prompt: The main prompt/question
            images: Optional list of image file paths
            system_prompt: Optional system prompt
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            
        Returns:
            The model's response as a string
        """
        pass
    
    def get_model_info(self) -> ModelInfo:
        """Return model metadata."""
        return self.model_info
    
    async def generate_with_metrics(
        self,
        test_id: str,
        prompt: str,
        images: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> ModelResponse:
        """
        Generate response with timing and metrics.
        
        Args:
            test_id: Identifier for the test case
            prompt: The main prompt/question
            images: Optional list of image file paths
            system_prompt: Optional system prompt
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            
        Returns:
            ModelResponse with timing and metadata
        """
        start_time = time.time()
        
        try:
            response = await self.generate(
                prompt=prompt,
                images=images,
                system_prompt=system_prompt,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            
            response_time_ms = int((time.time() - start_time) * 1000)
            
            return ModelResponse(
                test_id=test_id,
                model_name=self.model_info.name,
                raw_response=response,
                response_time_ms=response_time_ms,
                tokens_used=None,  # Override in subclasses if available
            )
        except Exception as e:
            response_time_ms = int((time.time() - start_time) * 1000)
            return ModelResponse(
                test_id=test_id,
                model_name=self.model_info.name,
                raw_response=f"ERROR: {str(e)}",
                response_time_ms=response_time_ms,
            )
    
    @abstractmethod
    def is_available(self) -> bool:
        """Check if the model is available and ready."""
        pass
    
    def health_check(self) -> Dict[str, Any]:
        """Perform a health check on the model."""
        return {
            "available": self.is_available(),
            "model_name": self.model_info.name,
            "model_version": self.model_info.version,
        }


class ModelRunnerFactory:
    """Factory for creating model runners."""
    
    _runners: Dict[str, type] = {}
    
    @classmethod
    def register(cls, name: str, runner_class: type):
        """Register a model runner class."""
        if not issubclass(runner_class, ModelRunner):
            raise ValueError("Runner must inherit from ModelRunner")
        cls._runners[name] = runner_class
    
    @classmethod
    def create(cls, name: str, model_info: ModelInfo, **kwargs) -> ModelRunner:
        """Create a model runner instance."""
        if name not in cls._runners:
            raise ValueError(f"Unknown runner: {name}. Available: {list(cls._runners.keys())}")
        return cls._runners[name](model_info, **kwargs)
    
    @classmethod
    def list_runners(cls) -> List[str]:
        """List available runner types."""
        return list(cls._runners.keys())
