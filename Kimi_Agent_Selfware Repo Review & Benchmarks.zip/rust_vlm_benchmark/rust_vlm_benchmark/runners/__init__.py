"""
Model runners for different backends.
"""

from .base import ModelRunner, ModelRunnerFactory
from .ollama import OllamaRunner

try:
    from .openai_runner import OpenAIRunner
except ImportError:
    OpenAIRunner = None  # openai not installed

__all__ = [
    "ModelRunner",
    "ModelRunnerFactory",
    "OllamaRunner",
    "OpenAIRunner",
]
