#!/usr/bin/env python3
"""
Advanced example runner for RustVLM-Bench.

This script demonstrates:
- Parallel test execution
- Custom progress callbacks
- Multiple model comparison
- Detailed result analysis
"""

import asyncio
import sys
import json
from pathlib import Path
from typing import List
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))

from rust_vlm_benchmark.core.benchmark import BenchmarkRunner
from rust_vlm_benchmark.core.models import ModelInfo, BenchmarkResult
from rust_vlm_benchmark.core.results import ResultsAggregator, ReportGenerator
from rust_vlm_benchmark.runners.ollama import OllamaRunner


class ProgressTracker:
    """Track and display progress."""
    
    def __init__(self, total_tests: int):
        self.total_tests = total_tests
        self.completed = 0
        self.current_test = ""
    
    def update(self, test_name: str, progress: float):
        """Update progress."""
        self.completed = int(progress * self.total_tests)
        self.current_test = test_name
        
        # Print progress bar
        bar_width = 40
        filled = int(progress * bar_width)
        bar = "█" * filled + "░" * (bar_width - filled)
        
        print(f"\r[{bar}] {progress*100:.1f}% | {self.completed}/{self.total_tests} | {test_name[:30]}", end="", flush=True)
    
    def finish(self):
        """Finish progress display."""
        print()  # New line


async def run_benchmark_for_model(
    model_name: str,
    benchmark_name: str,
    difficulty: List[str] = None,
    max_tests: int = None,
) -> BenchmarkResult:
    """Run benchmark for a single model."""
    
    print(f"\n{'='*60}")
    print(f"Running {benchmark_name} with {model_name}")
    print(f"{'='*60}\n")
    
    # Create model runner
    model_info = ModelInfo(
        name=model_name,
        version="latest",
        provider="ollama",
    )
    
    model_runner = OllamaRunner(
        model_info=model_info,
        host="localhost",
        port=11434,
    )
    
    # Check availability
    if not model_runner.is_available():
        print(f"WARNING: Model {model_name} not available, skipping...")
        return None
    
    # Create benchmark runner
    benchmark_runner = BenchmarkRunner()
    
    # Set up progress tracking
    total_tests = max_tests or 10  # Estimate
    tracker = ProgressTracker(total_tests)
    benchmark_runner.set_progress_callback(tracker.update)
    
    # Run benchmark
    result = await benchmark_runner.run(
        benchmark_name=benchmark_name,
        model_runner=model_runner,
        filter_difficulty=difficulty,
        max_tests=max_tests,
        parallel=True,
        max_parallel=2,
    )
    
    tracker.finish()
    
    return result


async def compare_models(
    models: List[str],
    benchmark_name: str,
    difficulty: List[str] = None,
    max_tests: int = None,
):
    """Compare multiple models on the same benchmark."""
    
    print("\n" + "=" * 60)
    print("MODEL COMPARISON")
    print("=" * 60)
    print(f"Benchmark: {benchmark_name}")
    print(f"Models: {', '.join(models)}")
    print()
    
    results = {}
    
    for model in models:
        result = await run_benchmark_for_model(
            model_name=model,
            benchmark_name=benchmark_name,
            difficulty=difficulty,
            max_tests=max_tests,
        )
        
        if result:
            results[model] = result
    
    if len(results) < 2:
        print("Need at least 2 models for comparison")
        return
    
    # Print comparison table
    print("\n" + "=" * 60)
    print("COMPARISON RESULTS")
    print("=" * 60)
    print()
    
    # Overall scores
    print("Overall Scores:")
    print(f"{'Model':<30} {'Score':>10} {'Weighted':>10} {'Passed':>10}")
    print("-" * 60)
    
    sorted_models = sorted(
        results.items(),
        key=lambda x: x[1].overall_score,
        reverse=True
    )
    
    for model, result in sorted_models:
        print(f"{model:<30} {result.overall_score:>9.2%} {result.weighted_overall_score:>9.2%} {result.tests_passed:>3}/{result.total_tests}")
    
    print()
    
    # Category comparison
    print("Category Scores:")
    print(f"{'Category':<20}", end="")
    for model in results.keys():
        print(f"{model[:15]:>16}", end="")
    print()
    print("-" * 60)
    
    # Get all categories
    all_categories = set()
    for result in results.values():
        for cat in result.category_scores:
            all_categories.add(cat.category.value)
    
    for category in sorted(all_categories):
        print(f"{category:<20}", end="")
        for model in results.keys():
            result = results[model]
            cat_score = next(
                (cs.average_score for cs in result.category_scores if cs.category.value == category),
                0.0
            )
            print(f"{cat_score:>15.2%}", end="")
        print()
    
    print()
    
    # Difficulty comparison
    print("Difficulty Scores:")
    print(f"{'Difficulty':<20}", end="")
    for model in results.keys():
        print(f"{model[:15]:>16}", end="")
    print()
    print("-" * 60)
    
    all_difficulties = ["beginner", "intermediate", "advanced", "expert"]
    
    for difficulty in all_difficulties:
        print(f"{difficulty:<20}", end="")
        for model in results.keys():
            result = results[model]
            diff_score = next(
                (ds.average_score for ds in result.difficulty_scores if ds.difficulty.value == difficulty),
                None
            )
            if diff_score is not None:
                print(f"{diff_score:>15.2%}", end="")
            else:
                print(f"{'N/A':>15}", end="")
        print()
    
    print()
    
    # Save comparison results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    comparison_file = Path("results") / f"comparison_{timestamp}.json"
    comparison_file.parent.mkdir(parents=True, exist_ok=True)
    
    comparison_data = {
        "benchmark": benchmark_name,
        "timestamp": timestamp,
        "models": {
            model: {
                "overall_score": result.overall_score,
                "weighted_score": result.weighted_overall_score,
                "tests_passed": result.tests_passed,
                "total_tests": result.total_tests,
                "category_scores": {
                    cs.category.value: cs.average_score
                    for cs in result.category_scores
                },
                "difficulty_scores": {
                    ds.difficulty.value: ds.average_score
                    for ds in result.difficulty_scores
                },
            }
            for model, result in results.items()
        },
    }
    
    with open(comparison_file, 'w') as f:
        json.dump(comparison_data, f, indent=2)
    
    print(f"Comparison saved to: {comparison_file}")
    print()


async def main():
    """Main entry point."""
    
    # Models to compare
    models = [
        "qwen3.5-vl",
        # "llama3.2-vision",  # Uncomment if available
        # "codellama",        # Uncomment if available
    ]
    
    # Run comparison
    await compare_models(
        models=models,
        benchmark_name="rust_code_comprehension",
        difficulty=["beginner", "intermediate"],
        max_tests=5,  # Limit for quick testing
    )
    
    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
