#!/usr/bin/env python3
"""
Simple example runner for RustVLM-Bench.

This script demonstrates how to use the benchmark framework programmatically.
"""

import asyncio
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from rust_vlm_benchmark.core.benchmark import BenchmarkRunner
from rust_vlm_benchmark.core.models import ModelInfo
from rust_vlm_benchmark.runners.ollama import OllamaRunner


async def main():
    """Run a simple benchmark example."""
    
    # Configuration
    MODEL_NAME = "qwen3.5-vl"
    HOST = "localhost"
    PORT = 11434
    BENCHMARK = "rust_code_comprehension"
    
    print("=" * 60)
    print("RustVLM-Bench Simple Runner")
    print("=" * 60)
    print()
    
    # Create model info
    model_info = ModelInfo(
        name=MODEL_NAME,
        version="latest",
        provider="ollama",
    )
    
    # Create model runner
    print(f"Connecting to Ollama at {HOST}:{PORT}...")
    model_runner = OllamaRunner(
        model_info=model_info,
        host=HOST,
        port=PORT,
    )
    
    # Check if model is available
    if not model_runner.is_available():
        print(f"ERROR: Model '{MODEL_NAME}' is not available!")
        print()
        print("Health check:")
        health = model_runner.health_check()
        for key, value in health.items():
            print(f"  {key}: {value}")
        print()
        print("Make sure Ollama is running and the model is pulled:")
        print(f"  ollama pull {MODEL_NAME}")
        return 1
    
    print(f"✓ Model '{MODEL_NAME}' is ready")
    print()
    
    # Create benchmark runner
    benchmark_runner = BenchmarkRunner()
    
    # Run benchmark
    print(f"Running benchmark: {BENCHMARK}")
    print("-" * 60)
    
    try:
        result = await benchmark_runner.run(
            benchmark_name=BENCHMARK,
            model_runner=model_runner,
            filter_difficulty=["beginner"],  # Only run beginner tests
            max_tests=3,  # Limit to 3 tests for quick demo
            parallel=False,  # Run sequentially for clearer output
        )
        
        # Print summary
        print()
        print("=" * 60)
        print("BENCHMARK COMPLETE")
        print("=" * 60)
        print()
        print(f"Overall Score: {result.overall_score:.2%}")
        print(f"Weighted Score: {result.weighted_overall_score:.2%}")
        print(f"Tests Passed: {result.tests_passed}/{result.total_tests}")
        print()
        
        # Print category scores
        print("Category Scores:")
        for cat in sorted(result.category_scores, key=lambda x: x.average_score, reverse=True):
            print(f"  {cat.category.value:20s} {cat.average_score:.2%}")
        print()
        
        # Print difficulty scores
        print("Difficulty Scores:")
        for diff in result.difficulty_scores:
            print(f"  {diff.difficulty.value:20s} {diff.average_score:.2%}")
        print()
        
        # Print individual test results
        print("Test Results:")
        for test in result.test_results:
            status = "✓ PASS" if test.passed else "✗ FAIL"
            print(f"  {status} {test.test_name} ({test.total_score:.2%})")
        print()
        
        print("Results saved to results/ directory")
        print()
        
        return 0 if result.tests_passed == result.total_tests else 1
        
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
