"""
Setup script for RustVLM-Bench
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="rust-vlm-benchmark",
    version="0.1.0",
    author="RustVLM-Bench Team",
    description="Visual Language Model Benchmark for Rust Code",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/rust-vlm-benchmark",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Testing",
    ],
    python_requires=">=3.9",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
        ],
        "scoring": [
            "sentence-transformers>=2.2.0",
        ],
        "all": [
            "openai>=1.0.0",
            "anthropic>=0.8.0",
            "sentence-transformers>=2.2.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "rust-vlm-benchmark=rust_vlm_benchmark.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "rust_vlm_benchmark": ["config/**/*"],
    },
)
