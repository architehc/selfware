# RustVLM-Bench: Visual Language Model Benchmark for Rust Code

A comprehensive benchmark framework for evaluating visual language models' understanding of Rust code.

## Overview

RustVLM-Bench tests models on:
- Code comprehension and analysis
- Bug detection and fixing
- Code refactoring suggestions
- Architecture understanding
- Documentation generation
- Performance optimization

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run benchmarks against local Qwen3.5
python -m rust_vlm_benchmark run --model qwen3.5 --host localhost:11434

# Generate report
python -m rust_vlm_benchmark report --results results/
```

## Framework Structure

```
rust_vlm_benchmark/
├── core/               # Core framework components
├── benchmarks/         # Benchmark definitions
├── runners/           # Model runners (Qwen, GPT, Claude, etc.)
├── scoring/           # Scoring algorithms
├── reporting/         # Report generation
└── config/            # Configuration files
```

## Architecture

See [ARCHITECTURE.md](docs/ARCHITECTURE.md) for detailed framework design.

## Adding New Benchmarks

See [CONTRIBUTING.md](docs/CONTRIBUTING.md) for benchmark development guide.

## License

MIT License
