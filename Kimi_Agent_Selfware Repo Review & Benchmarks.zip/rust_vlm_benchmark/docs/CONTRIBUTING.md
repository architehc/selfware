# Contributing to RustVLM-Bench

Thank you for your interest in contributing! This guide will help you add new benchmarks and improve the framework.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Adding New Test Cases](#adding-new-test-cases)
3. [Creating New Benchmark Suites](#creating-new-benchmark-suites)
4. [Adding Custom Scoring](#adding-custom-scoring)
5. [Code Style](#code-style)

## Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/yourusername/rust-vlm-benchmark.git`
3. Install in development mode:
   ```bash
   pip install -e ".[dev]"
   ```
4. Create a new branch: `git checkout -b feature/my-new-benchmark`

## Adding New Test Cases

Test cases are defined in YAML files under `config/benchmarks/`.

### Test Case Structure

```yaml
- id: "unique_test_id"           # Unique identifier
  name: "Human-readable name"     # Display name
  difficulty: beginner            # beginner|intermediate|advanced|expert
  category: comprehension         # comprehension|bug_detection|refactoring|architecture|documentation
  tags: ["ownership", "borrowing"] # Searchable tags
  input:
    code_snippet: |               # Rust code to analyze (optional)
      fn example() {}
    code_file: path/to/file.rs    # Or reference a file (optional)
    image_file: path/to/img.png   # Screenshot/diagram (optional)
    prompt: "Question to ask"     # Main prompt (required)
    context: "Additional info"    # Extra context (optional)
    system_prompt: "Override"     # Custom system prompt (optional)
  expected:
    output_format: json           # json|code|text|markdown
    validation_rules:             # Validation rules
      - type: contains
        value: "expected text"
    scoring_criteria:             # Scoring criteria
      - criterion: "correctness"
        weight: 0.6
    reference_answer: "Expected"  # Reference for comparison
  timeout_seconds: 30             # Timeout for model response
  enabled: true                   # Enable/disable test
```

### Example: Adding a New Comprehension Test

1. Create or edit a YAML file in `config/benchmarks/`

```yaml
# config/benchmarks/my_new_tests.yaml

tests:
  - id: "my_test_001"
    name: "Understanding Result Types"
    difficulty: beginner
    category: comprehension
    tags: ["result", "error-handling"]
    input:
      code_snippet: |
        fn divide(a: f64, b: f64) -> Result<f64, String> {
            if b == 0.0 {
                Err(String::from("Cannot divide by zero"))
            } else {
                Ok(a / b)
            }
        }
      prompt: |
        Explain how the Result type works in this function.
        What would be returned for divide(10.0, 2.0)?
        What would be returned for divide(10.0, 0.0)?
        
        Answer in JSON format:
        {
          "result_explanation": "...",
          "example_1": "...",
          "example_2": "..."
        }
    expected:
      output_format: json
      validation_rules:
        - type: json_schema
          schema:
            required: ["result_explanation", "example_1", "example_2"]
        - type: contains
          value: "Ok(5"
        - type: contains
          value: "Err"
      scoring_criteria:
        - criterion: "correctness"
          weight: 0.7
        - criterion: "completeness"
          weight: 0.3
      reference_answer: |
        divide(10.0, 2.0) returns Ok(5.0)
        divide(10.0, 0.0) returns Err("Cannot divide by zero")
    timeout_seconds: 30
```

2. Register the test file in the benchmark config:

```yaml
# config/benchmarks/rust_code_comprehension.yaml

test_files:
  - comprehension_beginner.yaml
  - comprehension_intermediate.yaml
  - my_new_tests.yaml  # Add your file here
```

3. Test your new test case:

```bash
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5-vl \
  --max-tests 1
```

### Validation Rule Types

| Type | Description | Parameters |
|------|-------------|------------|
| `contains` | Check if response contains text | `value` |
| `regex` | Match regex pattern | `pattern` |
| `json_schema` | Validate JSON structure | `schema` |
| `compile` | Compile extracted code | - |
| `execute` | Run extracted code | `expected_exit_code` |

### Difficulty Guidelines

| Level | Characteristics | Examples |
|-------|-----------------|----------|
| **Beginner** | Basic syntax, single concepts | Variables, functions, simple types |
| **Intermediate** | Multiple concepts, standard patterns | Lifetimes, traits, error handling |
| **Advanced** | Complex patterns, unsafe, async | Pin, unsafe code, complex generics |
| **Expert** | Architecture, optimization, edge cases | Custom allocators, zero-cost abstractions |

## Creating New Benchmark Suites

To create an entirely new benchmark category:

1. Create a new benchmark config:

```yaml
# config/benchmarks/rust_async_benchmark.yaml

name: "rust_async_benchmark"
description: "Tests async/await understanding in Rust"
version: "1.0.0"

test_files:
  - async_beginner.yaml
  - async_advanced.yaml

difficulty_multipliers:
  beginner: 1.0
  intermediate: 1.5
  advanced: 2.0
  expert: 3.0

category_weights:
  comprehension: 0.4
  bug_detection: 0.3
  refactoring: 0.3
```

2. Create test files in the same directory

3. Run the new benchmark:

```bash
python -m rust_vlm_benchmark run rust_async_benchmark --model qwen3.5-vl
```

## Adding Custom Scoring

To add a custom scoring method:

1. Create a new scorer class:

```python
# rust_vlm_benchmark/scoring/custom.py

from .core.scoring import Scorer
from .core.models import ModelResponse, TestCase, ScoringCriterion, CriterionScore

class MyCustomScorer(Scorer):
    def score(
        self,
        response: ModelResponse,
        test_case: TestCase,
        criterion: ScoringCriterion
    ) -> CriterionScore:
        # Your scoring logic here
        score = self._calculate_score(response, test_case)
        
        return CriterionScore(
            criterion=criterion.criterion,
            score=score,
            weight=criterion.weight,
            weighted_score=score * criterion.weight,
            feedback="Custom scoring feedback"
        )
    
    def _calculate_score(self, response, test_case) -> float:
        # Implement your logic
        return 0.5
```

2. Register in the scoring engine:

```python
# In rust_vlm_benchmark/core/scoring.py

from .scoring.custom import MyCustomScorer

class ScoringEngine:
    def __init__(self):
        self.scorers = {
            # ... existing scorers
            "my_custom": MyCustomScorer(),
        }
```

3. Use in test configuration:

```yaml
scoring_criteria:
  - criterion: "my_custom_score"
    weight: 0.5
```

## Code Style

We use:
- **Black** for code formatting
- **isort** for import sorting
- **mypy** for type checking
- **flake8** for linting

Run before committing:

```bash
# Format code
black rust_vlm_benchmark/

# Sort imports
isort rust_vlm_benchmark/

# Type check
mypy rust_vlm_benchmark/ --ignore-missing-imports

# Lint
flake8 rust_vlm_benchmark/

# Run tests
pytest tests/ -v
```

## Submitting Changes

1. Ensure tests pass: `pytest tests/`
2. Update documentation if needed
3. Add your changes to `CHANGELOG.md`
4. Submit a pull request with:
   - Clear description of changes
   - Example test cases (if applicable)
   - Updated documentation

## Questions?

- Open an issue for bugs or feature requests
- Start a discussion for questions
- Check existing benchmarks for examples

Thank you for contributing!
