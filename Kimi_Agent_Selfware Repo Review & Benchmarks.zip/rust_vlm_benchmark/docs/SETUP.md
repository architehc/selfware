# Setup Guide for RustVLM-Bench

This guide walks you through setting up the benchmark framework and running evaluations against Qwen3.5 on localhost.

## Prerequisites

- Python 3.9+
- Rust toolchain (for code compilation tests)
- Ollama (for local model hosting)

## Step 1: Install Rust

If you don't have Rust installed:

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env
```

Verify installation:
```bash
rustc --version
cargo --version
```

## Step 2: Install Ollama

### macOS
```bash
brew install ollama
```

### Linux
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

### Windows
Download from [ollama.com](https://ollama.com)

## Step 3: Pull Qwen3.5 Model

Start Ollama and pull the vision model:

```bash
# Start Ollama service
ollama serve

# In another terminal, pull the model
ollama pull qwen3.5-vl

# Verify model is available
ollama list
```

## Step 4: Install Benchmark Framework

```bash
# Clone or navigate to the benchmark directory
cd rust_vlm_benchmark

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Install the package in development mode
pip install -e .
```

## Step 5: Verify Setup

### Test Ollama Connection

```bash
python -m rust_vlm_benchmark check --model qwen3.5-vl
```

Expected output:
```
┌─────────────────────────────────────┐
│ Health Check: qwen3.5-vl            │
├──────────────────┬──────────────────┤
│ Property         │ Value            │
├──────────────────┼──────────────────┤
│ available        │ True             │
│ model_name       │ qwen3.5-vl       │
│ model_version    │ latest           │
│ host             │ localhost        │
│ port             │ 11434            │
│ ollama_running   │ True             │
│ model_available  │ True             │
└──────────────────┴──────────────────┘
```

### List Available Benchmarks

```bash
python -m rust_vlm_benchmark list-benchmarks
```

## Step 6: Run Your First Benchmark

### Quick Test (5 tests)

```bash
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5-vl \
  --max-tests 5
```

### Run All Beginner Tests

```bash
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5-vl \
  --difficulty beginner
```

### Run Specific Category

```bash
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5-vl \
  --category bug_detection
```

### Full Benchmark Run

```bash
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5-vl \
  --parallel \
  --max-parallel 2
```

## Step 7: View Results

Results are saved in the `results/` directory:

```bash
# List result files
ls -la results/

# View markdown report
cat results/rust_code_comprehension_qwen3.5-vl_*.md

# View leaderboard
python -m rust_vlm_benchmark leaderboard
```

## Configuration Options

### Custom Output Directory

```bash
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5-vl \
  --output-dir /path/to/results
```

### Custom Config Directory

```bash
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5-vl \
  --config-dir /path/to/config
```

### CI/CD Mode (Fail Below Threshold)

```bash
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5-vl \
  --fail-below 0.7
```

## Advanced: Using Different Models

### Using OpenAI Models

```bash
export OPENAI_API_KEY="sk-..."

python -m rust_vlm_benchmark run rust_code_comprehension \
  --model gpt-4-vision-preview \
  --runner openai
```

### Using Local Models on Different Port

```bash
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5-vl \
  --host localhost \
  --port 11435
```

## Troubleshooting

### Ollama Not Running

```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Start Ollama
ollama serve
```

### Model Not Found

```bash
# List available models
ollama list

# Pull the model
ollama pull qwen3.5-vl
```

### Python Import Errors

```bash
# Reinstall in development mode
pip install -e .

# Or run as module
python -m rust_vlm_benchmark --help
```

### Timeout Issues

If tests timeout, increase the timeout in the test configuration or run with fewer parallel tests:

```bash
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5-vl \
  --max-parallel 1
```

## Performance Tips

1. **Use Parallel Execution**: Enable `--parallel` for faster runs
2. **Filter Tests**: Use `--difficulty`, `--category`, or `--max-tests` to limit scope
3. **SSD Storage**: Results and temp files benefit from fast storage
4. **Adequate RAM**: Vision models need significant memory

## Next Steps

- [Add Custom Benchmarks](CONTRIBUTING.md)
- [View Architecture Documentation](ARCHITECTURE.md)
- [Compare Multiple Models](COMPARISON.md)
