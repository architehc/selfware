# RustVLM-Bench Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    Benchmark Framework                           │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │   Config    │  │  Test Cases │  │    Expected Outputs     │  │
│  │   Loader    │  │   Loader    │  │       Validator         │  │
│  └──────┬──────┘  └──────┬──────┘  └───────────┬─────────────┘  │
│         └─────────────────┼─────────────────────┘                │
│                           ▼                                      │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              Benchmark Orchestrator                       │   │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌────────────────┐  │   │
│  │  │ Beginner│ │Intermediate│ │Advanced│ │    Expert      │  │   │
│  │  │  Tier   │ │   Tier    │ │  Tier  │ │    Tier        │  │   │
│  │  └─────────┘ └─────────┘ └─────────┘ └────────────────┘  │   │
│  └─────────────────────────┬────────────────────────────────┘   │
│                            ▼                                     │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                 Model Runner Interface                    │   │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌────────────────┐  │   │
│  │  │ Qwen3.5 │ │  GPT-4  │ │ Claude  │ │    Custom      │  │   │
│  │  │  Local  │ │  API    │ │  API    │ │    Runner      │  │   │
│  │  └─────────┘ └─────────┘ └─────────┘ └────────────────┘  │   │
│  └─────────────────────────┬────────────────────────────────┘   │
│                            ▼                                     │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              Response Processing Pipeline                 │   │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌────────────────┐  │   │
│  │  │ Extract │ │ Validate│ │  Score  │ │   Normalize    │  │   │
│  │  │  Code   │ │  JSON   │ │ Response│ │    Score       │  │   │
│  │  └─────────┘ └─────────┘ └─────────┘ └────────────────┘  │   │
│  └─────────────────────────┬────────────────────────────────┘   │
│                            ▼                                     │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              Results Aggregation & Reporting              │   │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌────────────────┐  │   │
│  │  │ Per-Test│ │ Category│ │ Overall │ │   Leaderboard  │  │   │
│  │  │ Results │ │ Scores  │ │  Score  │ │    Update      │  │   │
│  │  └─────────┘ └─────────┘ └─────────┘ └────────────────┘  │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## Component Details

### 1. Configuration System

**Purpose**: Load and validate benchmark configurations

**Key Files**:
- `config/benchmarks.yaml` - Benchmark definitions
- `config/scoring.yaml` - Scoring weights and criteria
- `config/models.yaml` - Model configurations

**Responsibilities**:
- Load YAML/JSON configurations
- Validate schema
- Merge user overrides
- Provide configuration objects

### 2. Test Case Loader

**Purpose**: Load and prepare test cases for execution

**Test Case Format**:
```yaml
test_case:
  id: "unique-id"
  name: "Test Name"
  difficulty: "beginner|intermediate|advanced|expert"
  category: "comprehension|bug_detection|refactoring|architecture"
  input:
    code_file: "path/to/code.rs"
    image_file: "path/to/image.png"  # Optional: screenshot/ diagram
    prompt: "Question or task description"
  expected:
    output_format: "json|code|text"
    validation_rules:
      - type: "contains"
        field: "answer"
        value: "expected_value"
      - type: "regex"
        field: "code"
        pattern: "fn main\\(\\)"
    scoring_criteria:
      - criterion: "correctness"
        weight: 0.5
      - criterion: "explanation"
        weight: 0.3
      - criterion: "code_quality"
        weight: 0.2
```

### 3. Model Runner Interface

**Purpose**: Abstract interface for different model backends

**Interface Definition**:
```python
class ModelRunner(ABC):
    @abstractmethod
    async def generate(self, prompt: str, images: List[str] = None) -> str:
        """Generate response from model"""
        pass
    
    @abstractmethod
    def get_model_info(self) -> ModelInfo:
        """Return model metadata"""
        pass
```

**Implementations**:
- `OllamaRunner` - Local Ollama models (Qwen3.5, etc.)
- `OpenAIRunner` - OpenAI API models
- `AnthropicRunner` - Anthropic API models
- `CustomRunner` - Custom model endpoints

### 4. Response Processor

**Purpose**: Parse and validate model responses

**Pipeline**:
1. **Extract** - Pull code blocks, JSON, or text from response
2. **Validate** - Check format compliance
3. **Normalize** - Convert to standard format
4. **Score** - Apply scoring criteria

### 5. Scoring Engine

**Purpose**: Evaluate model responses against expected outputs

**Scoring Methods**:
- **Exact Match** - String comparison
- **Semantic Similarity** - Embedding-based comparison
- **Code Compilation** - Compile and test generated code
- **LLM-as-Judge** - Use LLM to evaluate quality
- **Custom Rules** - Domain-specific validators

**Scoring Formula**:
```
Score = Σ(criterion_score × criterion_weight) × difficulty_multiplier

difficulty_multiplier:
  beginner: 1.0
  intermediate: 1.5
  advanced: 2.0
  expert: 3.0
```

### 6. Results Aggregator

**Purpose**: Collect and aggregate results across all benchmarks

**Aggregation Levels**:
- Per-test results
- Per-category scores
- Per-difficulty scores
- Overall score

### 7. Report Generator

**Purpose**: Generate human-readable and machine-readable reports

**Output Formats**:
- Markdown report
- JSON results
- HTML dashboard
- CSV for spreadsheet analysis

## Data Flow

```
1. Load Configurations
   ↓
2. Initialize Model Runner
   ↓
3. For each benchmark:
   a. Load test cases
   b. For each test case:
      i. Prepare input (code + prompt)
      ii. Send to model
      iii. Receive response
      iv. Process and score response
      v. Store result
   c. Aggregate category results
   ↓
4. Generate final report
   ↓
5. Output results
```

## Scoring System

### Difficulty Levels

| Level | Multiplier | Description |
|-------|------------|-------------|
| Beginner | 1.0 | Basic syntax, simple patterns |
| Intermediate | 1.5 | Common idioms, standard library |
| Advanced | 2.0 | Complex generics, unsafe, async |
| Expert | 3.0 | Advanced patterns, optimization, architecture |

### Scoring Categories

| Category | Weight | Description |
|----------|--------|-------------|
| Comprehension | 25% | Understanding code behavior |
| Bug Detection | 20% | Finding and explaining bugs |
| Refactoring | 20% | Improving code structure |
| Architecture | 20% | Understanding system design |
| Documentation | 15% | Generating useful documentation |

### Scoring Criteria per Test

Each test can define custom criteria with weights:

```yaml
scoring_criteria:
  - criterion: "correctness"
    weight: 0.5
    description: "Answer is technically correct"
  - criterion: "completeness"
    weight: 0.3
    description: "All aspects of question addressed"
  - criterion: "clarity"
    weight: 0.2
    description: "Explanation is clear and well-structured"
```

## Extensibility

### Adding New Benchmarks

1. Create test case YAML file
2. Add code samples to `data/code/`
3. Register in `config/benchmarks.yaml`
4. Add validation rules if needed

### Adding New Model Runners

1. Implement `ModelRunner` interface
2. Add configuration to `config/models.yaml`
3. Register in runner factory

### Adding New Scoring Methods

1. Implement `Scorer` interface
2. Add to scoring registry
3. Reference in test configuration

## CI/CD Integration

The framework supports CI/CD through:
- Command-line interface
- JSON output format
- Exit codes for pass/fail
- JUnit XML output
- GitHub Actions integration

Example workflow:
```yaml
- name: Run Benchmarks
  run: |
    python -m rust_vlm_benchmark run \
      --model qwen3.5 \
      --host localhost:11434 \
      --output-format json \
      --fail-below 0.7
```
