# Selfware Repository - Core Source Files Analysis

## Overview

**Selfware** is a sophisticated agent framework for autonomous coding tasks, built on the philosophy: "software you own, software that knows you, software that lasts." It's written in Rust and provides a comprehensive AI-powered workshop environment.

---

## File-by-File Analysis

### 1. `src/lib.rs` - Library Root

**Purpose**: Main library entry point that exports modules and provides global coordination.

**Key Components**:
- **Module Organization**: 
  - Core modules (public API): `agent`, `api`, `cli`, `config`, `errors`, `input`, `safety`, `tools`, `ui`
  - Domain modules: `analysis`, `cognitive`, `devops`, `observability`, `orchestration`, `resource`, `session`, `supervision`, `testing`
  - Feature-gated: `evolution` (self-improvement), `kv_store` (tokens feature), `self_healing` (resilience feature)

- **Global Shutdown Coordination**:
  ```rust
  static SHUTDOWN_FLAG: AtomicBool = AtomicBool::new(false);
  pub fn request_shutdown() { ... }
  pub fn is_shutdown_requested() -> bool { ... }
  ```

- **Backward-Compatible Re-exports**: Provides convenient access to submodule functionality

**Dependencies**: Re-exports from all submodules for unified API access

---

### 2. `src/main.rs` - Application Entry Point

**Purpose**: Minimal application bootstrap with graceful shutdown handling.

**Key Components**:
- **Graceful Shutdown**: 10-second grace period before force exit
- **Signal Handling**: Handles both Ctrl+C (SIGINT) and SIGTERM
- **Simple Flow**:
  1. Spawn shutdown signal handler
  2. Run CLI main function
  3. Shutdown tracing
  4. Return appropriate exit code

**Key Code**:
```rust
const SHUTDOWN_GRACE_SECS: u64 = 10;

#[tokio::main]
async fn main() -> ExitCode {
    tokio::spawn(async {
        shutdown_signal().await;
        selfware::request_shutdown();
        // ... grace period handling
    });
    
    let result = selfware::cli::run().await;
    selfware::shutdown_tracing();
    // ... exit code handling
}
```

**Dependencies**: `selfware` crate (lib), `tokio`

---

### 3. `src/cli.rs` - Command Line Interface

**Purpose**: Comprehensive CLI handling with multiple execution modes and interactive features.

**Key Components**:
- **Cli Struct** (using `clap`):
  ```rust
  struct Cli {
      command: Option<Commands>,
      prompt: Option<String>,    // Headless mode (-p)
      config: Option<String>,    // Config file path
      workdir: Option<String>,   // Working directory
      quiet: bool,               // Minimal output
      mode: ExecutionMode,       // normal, auto-edit, yolo, daemon
  }
  ```

- **Execution Modes**: `normal` (ask), `auto-edit`, `yolo`, `daemon`
- **Constants**:
  - `DEFAULT_MULTI_CHAT_CONCURRENCY: usize = 4`
  - `JOURNAL_DESC_MAX_CHARS: usize = 50`
  - `COMMIT_HASH_PREFIX_CHARS: usize = 8`
  - `MAX_JOURNAL_ERRORS_DISPLAY: usize = 3`
  - `DEFAULT_WORKFLOW_NAME: &str = "default"`

**Dependencies**: `anyhow`, `clap`, `tracing`, `crate::agent`, `crate::config`, `crate::ui`

---

### 4. `src/errors.rs` - Error Handling

**Purpose**: Centralized error type hierarchy for programmatic recovery and unified error handling.

**Key Structs/Enums**:

| Error Type | Purpose |
|------------|---------|
| `SelfwareError` | Central error enum wrapping all error types |
| `AgentError` | Agent-specific errors (confirmation, iteration limit, timeout, etc.) |
| `ApiError` | API errors (timeout, rate limit, auth, HTTP status, etc.) |
| `ToolError` | Tool execution errors |
| `SafetyError` | Safety violations (blocked paths, commands, secrets) |
| `SessionError` | Session/checkpoint errors |
| `ResourceError` | Resource exhaustion errors (memory, GPU, disk, quota) |

**Exit Codes**:
```rust
pub const EXIT_SUCCESS: u8 = 0;
pub const EXIT_ERROR: u8 = 1;
pub const EXIT_CONFIG_ERROR: u8 = 2;
pub const EXIT_API_ERROR: u8 = 4;
pub const EXIT_SAFETY_ERROR: u8 = 5;
pub const EXIT_CONFIRMATION_REQUIRED: u8 = 6;
```

**Key Functions**:
- `is_confirmation_error(e: &anyhow::Error) -> bool`
- `get_exit_code(e: &anyhow::Error) -> u8`

**Dependencies**: `thiserror`, `std::path::PathBuf`

---

### 5. `src/memory.rs` - Agent Memory Management

**Purpose**: Tracks token usage and manages agent's conversation context with eviction strategies.

**Key Structs**:
```rust
pub struct AgentMemory {
    context_window: usize,
    entries: VecDeque<MemoryEntry>,
}

pub struct MemoryEntry {
    pub timestamp: String,
    pub role: String,
    pub content: String,
    pub token_estimate: usize,
}
```

**Constants**:
- `MAX_MEMORY_ENTRIES: usize = 10_000`
- `MAX_MEMORY_TOKENS: usize = 500_000`

**Key Methods**:
- `AgentMemory::new(config: &Config) -> Result<Self>`
- `add_message(&mut self, msg: &Message) -> Result<()>`
- `get_context(&self) -> Vec<Message>`
- `trim_to_budget(&mut self) -> Result<()>`
- `summarize_oldest(&mut self, count: usize) -> Result<()>`
- `stats(&self) -> MemoryStats`

**Dependencies**: `crate::api::types::Message`, `crate::config::Config`, `crate::token_count`, `chrono`, `std::collections::VecDeque`

---

### 6. `src/store.rs` - Key-Value Store

**Purpose**: Simple key-value store with support for tags and metadata.

**Key Struct**:
```rust
#[derive(Debug, Clone)]
pub struct KvStore {
    entries: HashMap<String, Entry>,
}
```

**Key Methods**:
- `new() -> Self`
- `from_map(entries: HashMap<String, Entry>) -> Self`
- `insert(&mut self, entry: Entry) -> Option<Entry>`
- `get(&self, key: &str) -> Option<&Entry>`
- `remove(&mut self, key: &str) -> Option<Entry>`
- `contains_key(&self, key: &str) -> bool`
- `len(&self) -> usize`
- `is_empty(&self) -> bool`
- `iter(&self) -> impl Iterator<Item = &Entry>`
- `keys(&self) -> impl Iterator<Item = &String>`
- `clear(&mut self)`

**Dependencies**: `crate::entry::Entry`, `std::collections::HashMap`

---

### 7. `src/token_count.rs` - Token Counting Utilities

**Purpose**: Shared token counting with multiple fallback strategies and caching.

**Architecture**:
1. Try Qwen tokenizer from HuggingFace Hub
2. Fall back to OpenAI tiktoken (cl100k)
3. Fall back to heuristic estimation

**Key Components**:
```rust
enum TokenizerState {
    Qwen(Box<Tokenizer>),
    Tiktoken(CoreBPE),
    Heuristic,
}

static TOKENIZER: Lazy<TokenizerState> = Lazy::new(TokenizerState::new);
static TOKEN_CACHE: Lazy<RwLock<HashMap<u64, usize>>> = ...;
```

**Constants**:
- `MAX_CACHE_ENTRIES: usize = 1_000`

**Key Functions**:
- `estimate_content_tokens(content: &str) -> usize`
- `estimate_tokens_with_overhead(content: &str, message_overhead: usize) -> usize`
- `hash_content(content: &str) -> u64`
- `heuristic_estimate(content: &str) -> usize`

**Dependencies**: `once_cell::sync::Lazy`, `tiktoken_rs`, `tokenizers`, `tracing`

---

### 8. `src/tokens.rs` - Token Usage Tracking & Cost Optimization

**Purpose**: Comprehensive token management including tracking, context pruning, model selection, budget management, and cost optimization.

**Architecture Diagram** (from code):
```
┌─────────────────────────────────────────────────────────────┐
│                    Token Optimizer                          │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐   │
│  │ Token         │  │ Context       │  │ Model         │   │
│  │ Tracker       │  │ Pruner        │  │ Selector      │   │
│  └───────────────┘  └───────────────┘  └───────────────┘   │
│           │                  │                  │           │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐   │
│  │ Budget        │  │ Batch         │  │ Cost          │   │
│  │ Manager       │  │ Optimizer     │  │ Analyzer      │   │
│  └───────────────┘  └───────────────┘  └───────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Key Structs**:
```rust
pub struct TokenTracker {
    prompt_tokens: AtomicUsize,
    completion_tokens: AtomicUsize,
    api_calls: AtomicUsize,
    step_usage: RwLock<Vec<StepUsage>>,
    start_time: RwLock<Option<Instant>>,
    drift: RwLock<DriftStats>,
}

pub struct DriftStats { ... }
pub struct StepUsage { ... }
pub struct TokenSummary { ... }
```

**Key Methods**:
- `record_usage(&self, prompt: usize, completion: usize)`
- `record_step(&self, step: usize, prompt: usize, completion: usize, tool_name: Option<String>)`
- `estimate_cost(&self) -> f64`
- `record_drift(&self, estimated: usize, actual: usize)`
- `summary(&self) -> TokenSummary`

**Dependencies**: `serde`, `std::collections`, `std::sync::atomic`, `std::sync::RwLock`, `std::time`

---

### 9. `src/tool_parser.rs` - Tool Call Parser

**Purpose**: Robust tool call parser supporting multiple formats with XML and JSON fallback.

**Supported Formats**:
1. Native function calling (tool_calls in response)
2. XML-style `<tool>...</tool>` blocks
3. JSON code blocks with tool schema
4. Markdown code blocks with tool invocations
5. Qwen3-style tool_call format
6. OpenAI function calling format

**Key Structs**:
```rust
pub struct ParsedToolCall {
    pub tool_name: String,
    pub arguments: serde_json::Value,
    pub raw_text: String,
    pub parse_method: ParseMethod,
}

pub enum ParseMethod {
    Native, Xml, Json, Markdown,
}

pub struct ParseResult {
    pub tool_calls: Vec<ParsedToolCall>,
    pub text_content: String,
    pub parse_errors: Vec<String>,
}
```

**Regex Patterns** (cached via `OnceLock`):
- `XML_TOOL_REGEX`
- `XML_TOOL_ALT_REGEX`
- `XML_TOOL_FUNCTION_REGEX`
- `QWEN3_TOOL_CALL_REGEX`
- `BARE_FUNCTION_REGEX`
- `OPENAI_FUNCTION_REGEX`
- `JSON_BLOCK_REGEX`

**Constants**:
- `MAX_TOOL_PARSER_INPUT_SIZE: usize = 10 * 1024 * 1024` (10 MB limit)

**Key Functions**:
- `parse_tool_calls(content: &str) -> ParseResult`
- `try_parse_xml(content: &str) -> Option<Vec<(Result<ParsedToolCall>, String)>>`
- `try_parse_json_blocks(content: &str) -> Option<Vec<(Result<ParsedToolCall>, String)>>`
- `decode_xml_entities(s: &str) -> String`

**Dependencies**: `anyhow`, `regex`, `serde`, `std::sync::OnceLock`

---

### 10. `src/self_healing.rs` - Self-Healing System

**Purpose**: Auto-recovery capabilities including error pattern learning, automatic recovery actions, state checkpointing, and proactive health monitoring.

**Architecture Diagram** (from code):
```
┌─────────────────────────────────────────────────────────────┐
│                    Self-Healing Engine                       │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐   │
│  │ Error         │  │ Recovery      │  │ State         │   │
│  │ Learner       │  │ Executor      │  │ Manager       │   │
│  └───────────────┘  └───────────────┘  └───────────────┘   │
│           │                  │                  │           │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐   │
│  │ Pattern       │  │ Recovery      │  │ Health        │   │
│  │ Detector      │  │ Strategies    │  │ Predictor     │   │
│  └───────────────┘  └───────────────┘  └───────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Key Structs**:
```rust
pub struct SelfHealingConfig {
    pub enabled: bool,
    pub max_healing_attempts: u32,
    pub pattern_window_secs: u64,
    pub pattern_threshold: u32,
    pub enable_checkpointing: bool,
    pub checkpoint_interval_secs: u64,
    pub max_checkpoints: usize,
    pub proactive_monitoring: bool,
}

pub struct ErrorOccurrence { ... }
pub struct ErrorPattern { ... }
pub struct ErrorLearner { ... }
pub struct LearnerStats { ... }
```

**Default Configuration**:
```rust
Self {
    enabled: true,
    max_healing_attempts: 3,
    pattern_window_secs: 300, // 5 minutes
    pattern_threshold: 3,
    enable_checkpointing: true,
    checkpoint_interval_secs: 60,
    max_checkpoints: 10,
    proactive_monitoring: true,
}
```

**Submodules**:
- `executor` - Recovery execution logic

**Public Exports**:
- `ExecutorSummary`
- `RecoveryExecution`
- `RecoveryExecutor`

**Dependencies**: `parking_lot::RwLock`, `serde`, `std::collections`, `std::sync::atomic`, `std::time`

---

## Module Dependencies Summary

```
lib.rs (exports all modules)
├── main.rs (uses cli::run, shutdown_tracing)
├── cli.rs (uses agent, config, ui, workflows)
├── errors.rs (standalone, used by all)
├── memory.rs (uses api::types, config, token_count)
├── store.rs (uses entry::Entry)
├── token_count.rs (uses tiktoken_rs, tokenizers)
├── tokens.rs (uses token_count, serde)
├── tool_parser.rs (uses regex, serde)
└── self_healing.rs (uses executor submodule)
```

---

## Key Design Patterns

1. **Feature Gating**: Modules like `evolution`, `kv_store`, `self_healing` are conditionally compiled
2. **Lazy Initialization**: Using `Lazy` and `OnceLock` for expensive resources (tokenizers, regex)
3. **Caching**: Token counting uses content-hash based caching
4. **Graceful Degradation**: Multiple fallback strategies (tokenizer → tiktoken → heuristic)
5. **Error Hierarchy**: Structured error types with `thiserror` for ergonomic error handling
6. **Atomic Operations**: Thread-safe counters using `AtomicUsize`
7. **RwLock Pattern**: Read-heavy data structures use `RwLock` for concurrency
8. **Global State**: Minimal global state (SHUTDOWN_FLAG) for coordination

---

## Statistics

| File | Lines | Purpose |
|------|-------|---------|
| lib.rs | ~147 | Module exports, global coordination |
| main.rs | ~50 | Application entry point |
| cli.rs | ~1562 | Command-line interface |
| errors.rs | ~541 | Error types and handling |
| memory.rs | ~729 | Agent memory management |
| store.rs | ~148 | Key-value store |
| token_count.rs | ~164 | Token counting utilities |
| tokens.rs | ~2940 | Token tracking & optimization |
| tool_parser.rs | ~1344 | Tool call parsing |
| self_healing.rs | ~1000+ | Auto-recovery system |

---

## Notable Features

- **54 Built-in Tools**: File, git, cargo, search operations
- **Multi-layer Safety**: Path protection, command filtering, secret detection
- **Checkpoint System**: Persistence for long-running tasks
- **PDVR Cycle**: Plan-Do-Verify-Reflect cognitive cycle
- **Garden View**: Visualize codebase as a living garden
- **Local-First**: Runs on local hardware
- **Vision & Multimodal Support**: Image processing capabilities
- **Model Registry**: Support for multiple LLM providers
