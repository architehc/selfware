# Visual Model Benchmark Implementation Guide
## For localhost Qwen3.5 Testing on Rust Projects

---

## Quick Start (5 Minutes)

### Step 1: Install Dependencies

```bash
# Install Ollama for local model serving
curl -fsSL https://ollama.com/install.sh | sh

# Pull Qwen3.5 model (choose size based on your GPU)
ollama pull qwen3.5:7b        # 7B parameters, ~4GB VRAM
ollama pull qwen3.5:14b       # 14B parameters, ~8GB VRAM
ollama pull qwen3.5:32b       # 32B parameters, ~20GB VRAM

# Install Python dependencies
pip install requests tqdm colorama
```

### Step 2: Start Ollama Server

```bash
# Start Ollama in background
ollama serve &

# Verify it's running
curl http://localhost:11434/api/tags
```

### Step 3: Run Your First Benchmark

```bash
cd /mnt/okcomputer/output

# Run beginner benchmarks
python run_beginner_benchmarks.py --model qwen3.5:7b

# Or run specific benchmark
python benchmark_runner.py \
  --benchmark trait_hierarchy_analysis \
  --model qwen3.5:14b \
  --output results.json
```

---

## Repository Structure

```
/mnt/okcomputer/output/
├── COMPREHENSIVE_BENCHMARK_PROPOSALS.md  # Full documentation
├── IMPLEMENTATION_GUIDE.md               # This file
├── BENCHMARK_SUMMARY.md                  # Quick reference
│
├── rust_vlm_benchmark/                   # Python framework
│   ├── core/                             # Scoring engine
│   │   ├── models.py                     # Data models
│   │   ├── scoring.py                    # Scoring algorithms
│   │   ├── results.py                    # Results aggregation
│   │   └── benchmark.py                  # Main runner
│   ├── runners/
│   │   ├── ollama.py                     # Ollama integration
│   │   └── openai_runner.py              # OpenAI API support
│   └── cli.py                            # Command-line interface
│
├── benchmarks/                           # Rust code samples
│   ├── generic_constraints/              # GAT examples
│   ├── unsafe_bugs/                      # Unsafe code bugs
│   ├── architectural_improvements/       # Refactoring examples
│   ├── complex_patterns/                 # Design patterns
│   └── macros/                           # Macro examples
│
├── beginner_benchmarks.json              # Beginner benchmark defs
├── benchmark_prompts.json                # All prompts
├── run_beginner_benchmarks.py            # Simple runner
├── benchmark_runner.py                   # Full runner
└── evaluate_benchmarks.py                # Evaluation script
```

---

## Benchmark Categories

### Beginner (Difficulty 2-4/10) - 5 Benchmarks
| ID | Name | Skills Tested | Expected Score |
|----|------|---------------|----------------|
| B1 | Struct/Enum Recognition | Syntax, derive macros | 85-95% |
| B2 | Function Comprehension | Methods, patterns | 80-90% |
| B3 | Cargo.toml Analysis | Dependencies, features | 90-100% |
| B4 | Error Handling | Result, Option, ? operator | 75-85% |
| B5 | Pattern Recognition | Common idioms, async | 80-90% |

### Intermediate (Difficulty 5-7/10) - 5 Benchmarks
| ID | Name | Skills Tested | Expected Score |
|----|------|---------------|----------------|
| I1 | Trait Hierarchy | Traits, generics, blanket impls | 65-80% |
| I2 | Lifetime Bug Detection | Borrow checker, self-referential | 60-75% |
| I3 | Code Refactoring | Error handling, builder pattern | 70-85% |
| I4 | Module Analysis | Visibility, imports, features | 75-90% |
| I5 | Concurrency Patterns | Async, channels, deadlocks | 60-75% |

### Advanced (Difficulty 8-10/10) - 5 Benchmarks
| ID | Name | Skills Tested | Expected Score |
|----|------|---------------|----------------|
| A1 | Generic Constraints | GATs, trait bounds, variance | 40-60% |
| A2 | Unsafe Bug Detection | Memory safety, FFI, UB | 35-55% |
| A3 | Architectural Design | System design, patterns | 50-70% |
| A4 | Complex Patterns | Actor pattern, state machines | 45-65% |
| A5 | Macro Design | proc-macros, code generation | 40-60% |

### Expert (Difficulty 9-10/10) - 5 Benchmarks
| ID | Name | Skills Tested | Expected Score |
|----|------|---------------|----------------|
| E1 | Zero-Cost Abstractions | Optimization, SIMD | 30-50% |
| E2 | Async Architecture | Cancellation, structured concurrency | 25-45% |
| E3 | Custom Allocators | Memory management, Allocator API | 20-40% |
| E4 | FFI Safety | Safe wrappers, Send/Sync | 35-55% |
| E5 | Type System Tricks | GATs, HRTBs, lending iterators | 25-45% |

### Real-World (Difficulty 7-9/10) - 5 Benchmarks
| ID | Name | Skills Tested | Expected Score |
|----|------|---------------|----------------|
| R1 | PR Code Review | Issue identification, severity | 60-80% |
| R2 | Feature Implementation | Adding features, integration | 55-75% |
| R3 | Debugging | Root cause analysis, fixes | 65-85% |
| R4 | Performance Optimization | Profiling, optimization | 50-70% |
| R5 | Edition Migration | Breaking changes, migration | 70-85% |

---

## Running Benchmarks

### Option 1: Simple Runner (Recommended for Beginners)

```bash
# Run all beginner benchmarks
python run_beginner_benchmarks.py --model qwen3.5:7b

# Run with custom endpoint
python run_beginner_benchmarks.py \
  --endpoint http://localhost:8888/v1 \
  --model Qwen/Qwen3.5-Coder \
  --output my_results.json
```

### Option 2: Full Framework

```bash
# Run all benchmarks
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5:14b \
  --difficulty beginner \
  --difficulty intermediate

# Run by category
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5:14b \
  --category bug_detection

# Run with limits
python -m rust_vlm_benchmark run rust_code_comprehension \
  --model qwen3.5:14b \
  --max-tests 10 \
  --timeout 60
```

### Option 3: Direct API Calls

```bash
# Test with curl
curl -X POST http://localhost:11434/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3.5:14b",
    "prompt": "Analyze this Rust code and answer questions...",
    "stream": false,
    "format": "json"
  }'
```

---

## Evaluation & Scoring

### Automated Scoring

```bash
# Evaluate model responses
python evaluate_benchmarks.py \
  --responses responses.json \
  --benchmarks beginner_benchmarks.json \
  --output scores.json

# Generate report
python evaluate_benchmarks.py \
  --responses responses.json \
  --format markdown \
  --output report.md
```

### Scoring Criteria

| Criterion | Weight | Description |
|-----------|--------|-------------|
| Correctness | 40% | Answer is technically correct |
| Completeness | 25% | All parts of question answered |
| Clarity | 20% | Explanation is clear and well-structured |
| Code Quality | 15% | Code examples are idiomatic |

### Grade Interpretation

| Score | Grade | Interpretation |
|-------|-------|----------------|
| 90-100% | A | Expert - Production ready |
| 80-89% | B+ | Advanced - Minor improvements needed |
| 70-79% | B | Proficient - Some gaps but competent |
| 60-69% | C+ | Developing - Significant gaps |
| 50-59% | C | Basic - Major learning needed |
| <50% | F | Novice - Fundamental gaps |

---

## Interpreting Results

### Example Output

```json
{
  "model": "qwen3.5:14b",
  "benchmark_suite": "rust_code_comprehension",
  "overall_score": 0.78,
  "grade": "B",
  "interpretation": "Proficient - Good understanding with some gaps",
  "category_scores": [
    {
      "category": "Comprehension",
      "score": 0.85,
      "weight": 0.25
    },
    {
      "category": "Bug Detection",
      "score": 0.72,
      "weight": 0.20
    },
    {
      "category": "Refactoring",
      "score": 0.80,
      "weight": 0.20
    },
    {
      "category": "Architecture",
      "score": 0.75,
      "weight": 0.20
    },
    {
      "category": "Documentation",
      "score": 0.78,
      "weight": 0.15
    }
  ],
  "difficulty_scores": [
    {
      "difficulty": "beginner",
      "score": 0.92,
      "multiplier": 1.0
    },
    {
      "difficulty": "intermediate",
      "score": 0.78,
      "multiplier": 1.5
    },
    {
      "difficulty": "advanced",
      "score": 0.65,
      "multiplier": 2.0
    }
  ],
  "test_results": [
    {
      "benchmark_id": "B1",
      "name": "Struct and Enum Recognition",
      "score": 0.95,
      "passed": true
    },
    {
      "benchmark_id": "I2",
      "name": "Lifetime Bug Detection",
      "score": 0.68,
      "passed": false,
      "feedback": "Missed self-referential struct issue"
    }
  ]
}
```

---

## Customizing Benchmarks

### Adding a New Benchmark

1. **Create benchmark definition** in `benchmarks.json`:

```json
{
  "id": "custom_001",
  "name": "My Custom Benchmark",
  "difficulty": "intermediate",
  "category": "comprehension",
  "code": "// Your Rust code here",
  "questions": [
    {
      "id": 1,
      "text": "What does this function do?",
      "expected_answer": "It processes...",
      "points": 5,
      "evaluation_type": "contains_key_terms"
    }
  ]
}
```

2. **Add evaluation logic** in `evaluate_benchmarks.py`:

```python
def evaluate_custom_001(response, expected):
    score = 0
    # Your evaluation logic
    return score
```

3. **Run the benchmark**:

```bash
python benchmark_runner.py --benchmark custom_001 --model qwen3.5:14b
```

### Custom Scoring Function

```python
from rust_vlm_benchmark.core.scoring import Scorer

class MyScorer(Scorer):
    def score(self, response, test_case, criterion):
        # Custom scoring logic
        if criterion.type == "regex":
            import re
            match = re.search(criterion.pattern, response)
            return 1.0 if match else 0.0
        elif criterion.type == "compile":
            # Try to compile as Rust code
            import subprocess
            result = subprocess.run(
                ["rustc", "--crate-type", "lib", "-"],
                input=response,
                capture_output=True
            )
            return 1.0 if result.returncode == 0 else 0.0
        return super().score(response, test_case, criterion)
```

---

## Troubleshooting

### Issue: Ollama Connection Refused

```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# If not running, start it
ollama serve &

# Or start with specific host
OLLAMA_HOST=0.0.0.0:11434 ollama serve
```

### Issue: Out of Memory

```bash
# Use smaller model
ollama pull qwen3.5:7b

# Or reduce context window
python benchmark_runner.py \
  --model qwen3.5:7b \
  --max-tokens 2048
```

### Issue: Model Not Found

```bash
# List available models
ollama list

# Pull the model
ollama pull qwen3.5:14b

# Verify
ollama run qwen3.5:14b "Hello"
```

### Issue: Slow Performance

```bash
# Use GPU if available
ollama run qwen3.5:14b --gpu

# Or reduce concurrent requests
python benchmark_runner.py \
  --model qwen3.5:14b \
  --max-concurrent 1
```

---

## Advanced Configuration

### Environment Variables

```bash
# Model endpoint
export RUST_VLM_ENDPOINT=http://localhost:11434/v1

# Default model
export RUST_VLM_MODEL=qwen3.5:14b

# Timeout settings
export RUST_VLM_TIMEOUT=60
export RUST_VLM_MAX_RETRIES=3

# Scoring weights
export RUST_VLM_CORRECTNESS_WEIGHT=0.40
export RUST_VLM_COMPLETENESS_WEIGHT=0.25
```

### Configuration File

Create `~/.rust_vlm_benchmark/config.yaml`:

```yaml
models:
  default: qwen3.5:14b
  available:
    - name: qwen3.5:7b
      endpoint: http://localhost:11434/v1
      context_length: 32768
    - name: qwen3.5:14b
      endpoint: http://localhost:11434/v1
      context_length: 32768
    - name: qwen3.5:32b
      endpoint: http://localhost:11434/v1
      context_length: 32768

scoring:
  weights:
    correctness: 0.40
    completeness: 0.25
    clarity: 0.20
    code_quality: 0.15

benchmarks:
  timeout_seconds: 60
  max_concurrent: 2
  output_format: json
```

---

## CI/CD Integration

### GitHub Actions

```yaml
name: Rust VLM Benchmark

on:
  push:
    branches: [main]
  schedule:
    - cron: '0 0 * * 0'  # Weekly

jobs:
  benchmark:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Ollama
        run: |
          curl -fsSL https://ollama.com/install.sh | sh
          ollama pull qwen3.5:14b
          
      - name: Run benchmarks
        run: |
          python -m rust_vlm_benchmark run rust_code_comprehension \
            --model qwen3.5:14b \
            --difficulty beginner \
            --difficulty intermediate \
            --fail-below 0.70 \
            --output results/
            
      - name: Upload results
        uses: actions/upload-artifact@v4
        with:
          name: benchmark-results
          path: results/
          
      - name: Comment on PR
        if: github.event_name == 'pull_request'
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            const results = JSON.parse(fs.readFileSync('results/scores.json'));
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `## Benchmark Results\n\nOverall Score: ${results.overall_score}%`
            });
```

---

## Performance Tips

### 1. Use Appropriate Model Size

| GPU VRAM | Recommended Model | Expected Performance |
|----------|-------------------|---------------------|
| 4GB | qwen3.5:7b | 10-20 tokens/sec |
| 8GB | qwen3.5:14b | 8-15 tokens/sec |
| 16GB | qwen3.5:14b (q4) | 15-25 tokens/sec |
| 24GB+ | qwen3.5:32b | 5-10 tokens/sec |

### 2. Optimize Context Length

```bash
# Use shorter context for faster inference
python benchmark_runner.py \
  --model qwen3.5:14b \
  --max-tokens 2048  # Instead of 8192
```

### 3. Batch Requests

```python
# Run multiple benchmarks in parallel
import asyncio
from rust_vlm_benchmark import BenchmarkRunner

async def run_parallel():
    runner = BenchmarkRunner()
    tasks = [
        runner.run_benchmark("B1"),
        runner.run_benchmark("B2"),
        runner.run_benchmark("B3"),
    ]
    results = await asyncio.gather(*tasks)
    return results
```

### 4. Cache Model Responses

```python
# Enable response caching
runner = BenchmarkRunner(
    cache_dir=".benchmark_cache",
    cache_responses=True
)
```

---

## Next Steps

### 1. Run Your First Benchmark

```bash
cd /mnt/okcomputer/output
python run_beginner_benchmarks.py --model qwen3.5:7b
```

### 2. Analyze Results

```bash
# View results
cat results/beginner_results.json | jq '.'

# Generate visual report
python -m rust_vlm_benchmark report --format html --output report.html
```

### 3. Compare Models

```bash
# Run same benchmarks on multiple models
for model in qwen3.5:7b qwen3.5:14b qwen3.5:32b; do
  python benchmark_runner.py \
    --model $model \
    --output results/${model//:/_}.json
done

# Compare results
python -m rust_vlm_benchmark compare results/*.json
```

### 4. Add Custom Benchmarks

```bash
# Create new benchmark
cp benchmarks/template benchmarks/my_benchmark

# Edit benchmark definition
vim benchmarks/my_benchmark/benchmark.json

# Run new benchmark
python benchmark_runner.py --benchmark my_benchmark
```

---

## Resources

### Documentation
- [COMPREHENSIVE_BENCHMARK_PROPOSALS.md](COMPREHENSIVE_BENCHMARK_PROPOSALS.md) - Full benchmark documentation
- [BENCHMARK_SUMMARY.md](BENCHMARK_SUMMARY.md) - Quick reference
- [Rust Book](https://doc.rust-lang.org/book/) - Rust learning resource
- [Async Rust Book](https://rust-lang.github.io/async-book/) - Async patterns

### Tools
- [Ollama](https://ollama.com/) - Local LLM serving
- [Qwen3.5](https://huggingface.co/Qwen) - Model downloads
- [Rust Playground](https://play.rust-lang.org/) - Test code snippets

### Community
- [Rust Language Forum](https://users.rust-lang.org/)
- [r/rust](https://reddit.com/r/rust) - Reddit community

---

## Support

For issues or questions:
1. Check [Troubleshooting](#troubleshooting) section
2. Review generated logs in `logs/`
3. Open issue with benchmark output and system info

---

**Ready to start benchmarking!** Run `python run_beginner_benchmarks.py --help` for more options.
