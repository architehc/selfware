# Rust VLM Benchmarks - README

## Overview

This directory contains practical, real-world benchmarks for testing Visual Language Models (VLMs) on Rust code understanding. The benchmarks are designed based on the selfware repository analysis and are suitable for localhost testing against Qwen3.5 models.

## Files

| File | Description |
|------|-------------|
| `rust_vlm_benchmarks.md` | Complete benchmark documentation with all 5 tasks |
| `benchmark_prompts.json` | JSON file with all benchmark prompts and evaluation criteria |
| `run_benchmarks.py` | Script to run benchmarks against a local model |
| `evaluate_benchmarks.py` | Script to evaluate model responses |
| `README_benchmarks.md` | This file |

## Quick Start

### 1. Setup Your Model

Using vLLM:
```bash
python -m vllm.entrypoints.openai.api_server \
    --model Qwen/Qwen3.5-32B \
    --tensor-parallel-size 4 \
    --max-model-len 32768 \
    --port 8000
```

Using llama.cpp:
```bash
./server -m qwen3.5-32b-q4_k_m.gguf \
    --ctx-size 32768 \
    --n-gpu-layers 999 \
    --port 8000
```

### 2. Run Benchmarks

Run all benchmarks:
```bash
python run_benchmarks.py --model-url http://localhost:8000/v1
```

Run a specific benchmark:
```bash
python run_benchmarks.py --benchmark pr_code_review
```

### 3. Evaluate Responses

Evaluate all saved responses:
```bash
python evaluate_benchmarks.py --all --responses-dir ./responses
```

Evaluate with detailed output:
```bash
python evaluate_benchmarks.py --benchmark pr_code_review --verbose
```

Get JSON output:
```bash
python evaluate_benchmarks.py --all --json > results.json
```

## The 5 Benchmarks

### 1. PR Code Review (`pr_code_review`)
**Difficulty: 7/10**

Tests the model's ability to review a PR diff and identify issues.

**Key Skills Tested:**
- Bug detection in diffs
- Severity assessment
- Performance issue identification
- Code quality evaluation

**Expected Issues to Find:**
- `sleep()` call in hot path (critical)
- `encode()` parameter change
- Heuristic factor change
- Message overhead reduction

---

### 2. Feature Implementation (`feature_implementation`)
**Difficulty: 8/10**

Tests the model's ability to add rate limiting to an existing API client.

**Key Skills Tested:**
- Algorithm implementation (token bucket)
- Pattern matching with existing codebase
- Integration with existing error types
- Configuration design
- Test writing

**Expected Components:**
- Token bucket rate limiter
- Configurable RPM/burst
- Integration with ApiClient
- Unit tests

---

### 3. Debugging Issue (`debugging_issue`)
**Difficulty: 8/10**

Tests the model's ability to diagnose a RefCell panic in async code.

**Key Skills Tested:**
- Root cause analysis from logs
- Understanding of async/await
- Interior mutability patterns
- Fix implementation

**Expected Diagnosis:**
- RefCell borrow across await point
- Explanation of why it happens
- Fix using tokio::sync primitives

---

### 4. Performance Optimization (`performance_optimization`)
**Difficulty: 9/10**

Tests the model's ability to optimize a tool parser hot path.

**Key Skills Tested:**
- Profiling data interpretation
- Algorithm optimization
- Memory allocation reduction
- Zero-copy techniques

**Expected Optimizations:**
- Single-pass regex
- Span-based text tracking
- Pre-allocated strings
- Fast path for native format

---

### 5. Edition Migration (`edition_migration`)
**Difficulty: 7/10**

Tests the model's ability to migrate code to Rust 2024 edition.

**Key Skills Tested:**
- Edition change knowledge
- Dependency breaking changes
- async trait evolution
- Migration planning

**Expected Changes:**
- Edition 2024 syntax
- Native async traits
- Dependency updates
- Migration checklist

## Scoring

### Evaluation Criteria

Each benchmark has specific criteria with point values. The general scoring thresholds are:

| Score | Rating | Description |
|-------|--------|-------------|
| 90-100 | Excellent | Production-ready output |
| 70-89 | Good | Correct with minor issues |
| 50-69 | Fair | Partially correct |
| <50 | Poor | Significant issues |

### Automated Evaluation

The `evaluate_benchmarks.py` script uses pattern matching to score responses:

```python
# Example scoring for PR review
sleep_detected = any(re.search(p, response, re.I) for p in [
    r"sleep.*10ms",
    r"thread::sleep",
    r"performance.*degradation"
])
```

### Manual Review

For production use, combine automated scoring with human review:

1. Run automated evaluation
2. Review borderline cases manually
3. Adjust scores based on context

## Example Usage

### Complete Workflow

```bash
# 1. Start your model server
python -m vllm.entrypoints.openai.api_server \
    --model Qwen/Qwen3.5-32B \
    --port 8000

# 2. Run benchmarks
python run_benchmarks.py \
    --model-url http://localhost:8000/v1 \
    --save-responses \
    --responses-dir ./my_results

# 3. Evaluate responses
python evaluate_benchmarks.py \
    --all \
    --responses-dir ./my_results \
    --verbose \
    --json > scores.json

# 4. View summary
cat scores.json | jq '.summary'
```

### Custom Benchmark

To add a custom benchmark:

1. Add entry to `benchmark_prompts.json`:
```json
"my_benchmark": {
    "name": "My Custom Benchmark",
    "difficulty": 5,
    "prompt": "...",
    "evaluation_criteria": {...}
}
```

2. Add evaluator to `evaluate_benchmarks.py`:
```python
def _eval_my_benchmark(self, response: str) -> EvaluationResult:
    # Your evaluation logic
    ...
```

## Model Requirements

### Minimum Specifications

- **Model**: Qwen3.5-32B or equivalent
- **Context Length**: 16K minimum, 32K recommended
- **Temperature**: 0.2 for consistent results
- **Max Tokens**: 4096 for complete responses

### Recommended Setup

```python
config = {
    "model": "Qwen3.5-32B",
    "temperature": 0.2,
    "max_tokens": 4096,
    "top_p": 0.95,
    "repetition_penalty": 1.1
}
```

## Interpreting Results

### Example Output

```
============================================================
Benchmark: pr_code_review
============================================================
Score: 85/100 (85.0%)
Status: PASS

Criteria Breakdown:
  critical_issue_detection: 30/30
  encode_detection: 10/15
  heuristic_detection: 10/10
  severity_assessment: 20/20
  actionable_suggestions: 15/15

Feedback:
  - Did not identify encode() parameter change impact
```

### What to Look For

**Excellent Results (90+):**
- All critical issues identified
- Correct severity assessment
- Actionable suggestions
- Minimal false positives

**Good Results (70-89):**
- Most issues identified
- Minor severity misclassifications
- Some suggestions could be more specific

**Fair Results (50-69):**
- Some issues missed
- False positives present
- Suggestions are generic

**Poor Results (<50):**
- Major issues missed
- Incorrect analysis
- Non-actionable output

## Troubleshooting

### Model Not Responding

```bash
# Test model connectivity
curl http://localhost:8000/v1/models

# Test chat endpoint
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model": "Qwen3.5-32B", "messages": [{"role": "user", "content": "Hello"}]}'
```

### Out of Memory

Reduce context length or batch size:
```bash
python -m vllm.entrypoints.openai.api_server \
    --model Qwen/Qwen3.5-32B \
    --max-model-len 16384 \
    --gpu-memory-utilization 0.85
```

### Timeouts

Increase timeout in `run_benchmarks.py`:
```python
response = requests.post(
    self.chat_endpoint,
    json={...},
    timeout=600  # Increase from 300
)
```

## Contributing

To add new benchmarks:

1. Design the benchmark based on real Rust scenarios
2. Add prompt to `benchmark_prompts.json`
3. Add evaluator to `evaluate_benchmarks.py`
4. Update documentation
5. Test with multiple models

## License

These benchmarks are provided for research and evaluation purposes.

## References

- Based on the selfware repository analysis
- Designed for Qwen3.5 model evaluation
- Inspired by real-world Rust development scenarios
