# Intermediate Rust Code Understanding Benchmarks

## Overview

This document contains 5 intermediate-level benchmark tasks designed to test visual language models' understanding of Rust code. These benchmarks focus on:
- Traits and implementations
- Lifetime and borrow checker issues
- Code refactoring
- Module hierarchies and imports
- Concurrency patterns (async/await, channels, Arc/Mutex)

**Target Models**: Qwen3.5 series (suitable for localhost testing)
**Difficulty Level**: Intermediate (5-7/10)

---

## Benchmark 1: Trait Analysis and Implementation Patterns

### Task Name: `trait_hierarchy_analysis`

### Description
Analyze a complex trait hierarchy with associated types, generic bounds, and blanket implementations. Identify relationships between traits and determine valid implementations.

### Sample Code
```rust
//! Data Processing Pipeline Traits
//! 
//! This module defines traits for building type-safe data processing pipelines.

use std::fmt::Debug;
use std::marker::PhantomData;

/// A source that produces items of type T
pub trait Source<T> {
    /// Error type for this source
    type Error: std::error::Error;
    
    /// Get the next item from the source
    fn next(&mut self) -> Result<Option<T>, Self::Error>;
    
    /// Check if the source is exhausted
    fn is_exhausted(&self) -> bool;
}

/// A sink that consumes items of type T
pub trait Sink<T> {
    /// Error type for this sink
    type Error: std::error::Error;
    
    /// Send an item to the sink
    fn send(&mut self, item: T) -> Result<(), Self::Error>;
    
    /// Flush any buffered data
    fn flush(&mut self) -> Result<(), Self::Error>;
}

/// A transformation that converts Input to Output
pub trait Transform<Input, Output> {
    /// Error type for this transformation
    type Error: std::error::Error;
    
    /// Transform an input item
    fn transform(&mut self, input: Input) -> Result<Output, Self::Error>;
}

/// A pipeline stage that can be chained
pub trait PipelineStage<I, O>: Transform<I, O> + Sized {
    /// Chain this stage with another transformation
    fn chain<T, U>(self, next: T) -> ChainedPipeline<Self, T, I, O, U>
    where
        T: Transform<O, U>,
    {
        ChainedPipeline {
            first: self,
            second: next,
            _phantom: PhantomData,
        }
    }
}

/// Chained pipeline combining two transformations
pub struct ChainedPipeline<F, S, I, M, O> {
    first: F,
    second: S,
    _phantom: PhantomData<(I, M, O)>,
}

impl<F, S, I, M, O> Transform<I, O> for ChainedPipeline<F, S, I, M, O>
where
    F: Transform<I, M>,
    S: Transform<M, O>,
{
    type Error = PipelineError<F::Error, S::Error>;
    
    fn transform(&mut self, input: I) -> Result<O, Self::Error> {
        let intermediate = self.first.transform(input)
            .map_err(PipelineError::First)?;
        self.second.transform(intermediate)
            .map_err(PipelineError::Second)
    }
}

/// Pipeline error type that preserves both stage errors
#[derive(Debug)]
pub enum PipelineError<E1, E2> {
    First(E1),
    Second(E2),
}

impl<E1: std::error::Error, E2: std::error::Error> std::fmt::Display for PipelineError<E1, E2> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PipelineError::First(e) => write!(f, "Pipeline stage 1 error: {}", e),
            PipelineError::Second(e) => write!(f, "Pipeline stage 2 error: {}", e),
        }
    }
}

impl<E1: std::error::Error, E2: std::error::Error> std::error::Error for PipelineError<E1, E2> {}

/// Blanket implementation: Any Transform is a PipelineStage
impl<T, I, O> PipelineStage<I, O> for T where T: Transform<I, O> {}

/// A processor that can work with both sources and sinks
pub trait Processor<I, O>: Transform<I, O> {
    /// Process all items from a source and send to a sink
    fn process<Si, So, E>(
        &mut self,
        source: &mut Si,
        sink: &mut So,
    ) -> Result<usize, ProcessError<E, Self::Error, So::Error>>
    where
        Si: Source<I, Error = E>,
        So: Sink<O>,
    {
        let mut count = 0;
        while let Some(item) = source.next()
            .map_err(ProcessError::Source)?
        {
            let output = self.transform(item)
                .map_err(ProcessError::Transform)?;
            sink.send(output)
                .map_err(ProcessError::Sink)?;
            count += 1;
        }
        sink.flush().map_err(ProcessError::Sink)?;
        Ok(count)
    }
}

/// Process error type
#[derive(Debug)]
pub enum ProcessError<SE, TE, SiE> {
    Source(SE),
    Transform(TE),
    Sink(SiE),
}

// Blanket implementation for all Transform types
impl<T, I, O> Processor<I, O> for T where T: Transform<I, O> {}

/// Concrete implementation: Vector source
pub struct VecSource<T> {
    data: Vec<T>,
    position: usize,
}

impl<T> VecSource<T> {
    pub fn new(data: Vec<T>) -> Self {
        Self { data, position: 0 }
    }
}

impl<T: Clone> Source<T> for VecSource<T> {
    type Error = std::convert::Infallible;
    
    fn next(&mut self) -> Result<Option<T>, Self::Error> {
        if self.position < self.data.len() {
            let item = self.data[self.position].clone();
            self.position += 1;
            Ok(Some(item))
        } else {
            Ok(None)
        }
    }
    
    fn is_exhausted(&self) -> bool {
        self.position >= self.data.len()
    }
}

/// Concrete implementation: Vector sink
pub struct VecSink<T> {
    data: Vec<T>,
}

impl<T> VecSink<T> {
    pub fn new() -> Self {
        Self { data: Vec::new() }
    }
    
    pub fn into_inner(self) -> Vec<T> {
        self.data
    }
}

impl<T> Default for VecSink<T> {
    fn default() -> Self {
        Self::new()
    }
}

impl<T> Sink<T> for VecSink<T> {
    type Error = std::convert::Infallible;
    
    fn send(&mut self, item: T) -> Result<(), Self::Error> {
        self.data.push(item);
        Ok(())
    }
    
    fn flush(&mut self) -> Result<(), Self::Error> {
        Ok(())
    }
}

/// Concrete transformation: Parser
pub struct Parser<F> {
    parser: F,
}

impl<F> Parser<F> {
    pub fn new(parser: F) -> Self {
        Self { parser }
    }
}

impl<F, I, O> Transform<I, O> for Parser<F>
where
    F: FnMut(I) -> Result<O, ParseError>,
{
    type Error = ParseError;
    
    fn transform(&mut self, input: I) -> Result<O, Self::Error> {
        (self.parser)(input)
    }
}

/// Parse error
#[derive(Debug, Clone)]
pub struct ParseError {
    message: String,
}

impl ParseError {
    pub fn new(msg: impl Into<String>) -> Self {
        Self { message: msg.into() }
    }
}

impl std::fmt::Display for ParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Parse error: {}", self.message)
    }
}

impl std::error::Error for ParseError {}
```

### Questions

1. **Trait Relationships**: Which traits have blanket implementations? Explain how `PipelineStage` relates to `Transform`.

2. **Associated Types**: What are the associated types for `Source<T>` and how are they constrained?

3. **Generic Bounds**: In the `process` method of `Processor`, what are the bounds on `Si` and `So`? Why is `E` needed as a type parameter?

4. **Chaining**: Explain how `ChainedPipeline` works and what the `PhantomData` is used for.

5. **Error Handling**: Describe the error propagation strategy used in this code. How do `PipelineError` and `ProcessError` differ?

### Expected Output Format

```json
{
  "question_1": {
    "blanket_impls": ["PipelineStage", "Processor"],
    "relationship": "PipelineStage has a blanket impl for any T: Transform<I, O>, making all Transform types automatically PipelineStages"
  },
  "question_2": {
    "associated_type": "Error",
    "constraint": "Must implement std::error::Error trait"
  },
  "question_3": {
    "si_bounds": "Si: Source<I, Error = E>",
    "so_bounds": "So: Sink<O>",
    "e_purpose": "E is the error type from Source, needed to unify Source::Error with ProcessError::Source variant"
  },
  "question_4": {
    "chained_pipeline": "Combines two Transform implementations sequentially",
    "phantom_data": "Required because I, M, O type parameters are not used in struct fields, only in impl bounds"
  },
  "question_5": {
    "pipeline_error": "Wraps errors from two sequential stages, distinguishing First vs Second",
    "process_error": "Wraps errors from three different sources: Source, Transform, Sink",
    "strategy": "Enum variants preserve the original error while adding context about where it occurred"
  }
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Blanket impls identified | 2 | Correctly identifies both PipelineStage and Processor |
| Associated types explained | 2 | Correctly describes Error type and its bounds |
| Generic bounds analysis | 2 | Correctly explains Si, So bounds and E purpose |
| Chaining mechanism | 2 | Correctly explains ChainedPipeline and PhantomData |
| Error handling strategy | 2 | Correctly differentiates PipelineError and ProcessError |
| **Total** | **10** | |

### Difficulty Rating: 6/10

---

## Benchmark 2: Lifetime and Borrow Checker Analysis

### Task Name: `lifetime_bug_detection`

### Description
Identify lifetime issues and borrow checker problems in the provided code. Explain why each issue occurs and provide the corrected code.

### Sample Code (with bugs)
```rust
//! Configuration Manager with Caching
//! 
//! This module provides a configuration manager that caches parsed values.
//! Contains intentional lifetime and borrow checker issues.

use std::collections::HashMap;

/// Configuration source that holds string data
pub struct ConfigSource<'a> {
    raw_data: &'a str,
    parsed: HashMap<&'a str, &'a str>,
}

impl<'a> ConfigSource<'a> {
    /// Create a new config source from raw string data
    pub fn new(data: &'a str) -> Self {
        Self {
            raw_data: data,
            parsed: HashMap::new(),
        }
    }
    
    /// Parse the configuration and populate the cache
    pub fn parse(&mut self) {
        for line in self.raw_data.lines() {
            if let Some((key, value)) = line.split_once('=') {
                let trimmed_key = key.trim();
                let trimmed_value = value.trim();
                self.parsed.insert(trimmed_key, trimmed_value);
            }
        }
    }
    
    /// Get a configuration value
    pub fn get(&self, key: &str) -> Option<&&'a str> {
        self.parsed.get(key)
    }
    
    /// Get all keys as a vector
    pub fn keys(&self) -> Vec<&str> {
        self.parsed.keys().copied().collect()
    }
}

/// Configuration manager that can merge multiple sources
pub struct ConfigManager<'a> {
    sources: Vec<ConfigSource<'a>>,
    merged: HashMap<String, String>,
}

impl<'a> ConfigManager<'a> {
    pub fn new() -> Self {
        Self {
            sources: Vec::new(),
            merged: HashMap::new(),
        }
    }
    
    /// Add a configuration source
    pub fn add_source(&mut self, source: ConfigSource<'a>) {
        self.sources.push(source);
    }
    
    /// Merge all sources into the merged cache
    pub fn merge(&mut self) {
        self.merged.clear();
        for source in &self.sources {
            for (key, value) in &source.parsed {
                self.merged.insert(key.to_string(), value.to_string());
            }
        }
    }
    
    /// Get a value from the merged configuration
    pub fn get_merged(&self, key: &str) -> Option<&String> {
        self.merged.get(key)
    }
    
    /// Get a value directly from the first source that has it
    pub fn get_from_sources(&self, key: &str) -> Option<&str> {
        for source in &self.sources {
            if let Some(value) = source.get(key) {
                return Some(*value);
            }
        }
        None
    }
}

/// A builder for constructing configurations
pub struct ConfigBuilder {
    temp_data: String,
    source: Option<ConfigSource>,
}

impl ConfigBuilder {
    pub fn new() -> Self {
        Self {
            temp_data: String::new(),
            source: None,
        }
    }
    
    pub fn add_line(mut self, line: &str) -> Self {
        self.temp_data.push_str(line);
        self.temp_data.push('\n');
        self
    }
    
    pub fn build(&mut self) -> ConfigSource {
        self.source = Some(ConfigSource::new(&self.temp_data));
        self.source.as_ref().unwrap().parse();
        self.source.take().unwrap()
    }
}

/// A configuration validator that checks required keys
pub struct ConfigValidator<'a> {
    required_keys: Vec<&'a str>,
}

impl<'a> ConfigValidator<'a> {
    pub fn new(keys: &[&'a str]) -> Self {
        Self {
            required_keys: keys.to_vec(),
        }
    }
    
    pub fn validate(&self, config: &ConfigSource) -> Result<(), Vec<&'a str>> {
        let mut missing = Vec::new();
        for key in &self.required_keys {
            if config.get(key).is_none() {
                missing.push(*key);
            }
        }
        if missing.is_empty() {
            Ok(())
        } else {
            Err(missing)
        }
    }
}

/// Helper function to create a parsed config from a string
pub fn parse_config(data: &str) -> HashMap<String, String> {
    let mut source = ConfigSource::new(data);
    source.parse();
    
    let mut result = HashMap::new();
    for (key, value) in source.parsed {
        result.insert(key.to_string(), value.to_string());
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_config_source() {
        let data = "key1=value1\nkey2=value2";
        let mut source = ConfigSource::new(data);
        source.parse();
        
        assert_eq!(source.get("key1"), Some(&"value1"));
    }
    
    #[test]
    fn test_config_builder() {
        let builder = ConfigBuilder::new()
            .add_line("host=localhost")
            .add_line("port=8080");
        
        let config = builder.build();
        assert_eq!(config.get("host"), Some(&"localhost"));
    }
}
```

### Questions

1. **Bug Identification**: Identify ALL lifetime and borrow checker issues in the code. For each issue:
   - Line number(s) where it occurs
   - The specific error message Rust would produce
   - Why the issue occurs

2. **ConfigBuilder Issue**: The `ConfigBuilder::build()` method has a critical flaw. Explain the lifetime problem and provide a corrected implementation.

3. **ConfigValidator Issue**: There's a potential issue with `ConfigValidator::validate()`. What is it and how would you fix it?

4. **parse_config Issue**: The `parse_config` function has a borrow checker problem. Explain why and provide the fix.

5. **Corrected Code**: Provide the fully corrected version of `ConfigBuilder` that compiles and works correctly.

### Expected Output Format

```json
{
  "question_1": {
    "issues": [
      {
        "location": "ConfigBuilder::build()",
        "error": "cannot return value referencing function parameter self.temp_data",
        "explanation": "ConfigSource stores reference to temp_data, but temp_data is dropped when build() returns"
      },
      {
        "location": "parse_config function",
        "error": "source.parsed cannot be iterated because source is dropped at end of function",
        "explanation": "HashMap contains references to data that goes out of scope"
      }
    ]
  },
  "question_2": {
    "problem": "self.temp_data is owned by ConfigBuilder, but ConfigSource stores references to it. When build() returns, temp_data is dropped but ConfigSource still holds references.",
    "solution": "Either store owned String in ConfigSource, or use Rc/Arc for shared ownership"
  },
  "question_3": {
    "problem": "validate() returns references with validator's lifetime, but they should have config's lifetime",
    "fix": "Change return type to Result<(), Vec<&str>> where missing keys have 'config lifetime"
  },
  "question_4": {
    "problem": "source is dropped at end of function but result tries to use data from source.parsed",
    "fix": "Clone the strings before source is dropped, or change ConfigSource to own its data"
  },
  "question_5": {
    "corrected_code": "pub struct ConfigBuilder {\n    lines: Vec<String>,\n}\n\nimpl ConfigBuilder {\n    pub fn new() -> Self {\n        Self { lines: Vec::new() }\n    }\n    \n    pub fn add_line(mut self, line: impl Into<String>) -> Self {\n        self.lines.push(line.into());\n        self\n    }\n    \n    pub fn build(self) -> OwnedConfigSource {\n        let data = self.lines.join(\"\\n\");\n        let mut source = OwnedConfigSource::new(data);\n        source.parse();\n        source\n    }\n}"
  }
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Issue identification | 3 | Correctly identifies all 3+ lifetime/borrow issues |
| Error message accuracy | 2 | Provides accurate Rust compiler error messages |
| Root cause explanation | 2 | Correctly explains why each issue occurs |
| ConfigBuilder fix | 2 | Provides working corrected implementation |
| Code quality | 1 | Solution follows Rust best practices |
| **Total** | **10** | |

### Difficulty Rating: 7/10

---

## Benchmark 3: Code Refactoring

### Task Name: `refactor_poor_structure`

### Description
Refactor poorly structured Rust code to improve:
- Error handling (replace panic/unwrap with proper Result types)
- Code organization (separate concerns, reduce duplication)
- API design (builder patterns, type safety)
- Performance (reduce unnecessary allocations)

### Sample Code (before refactoring)
```rust
//! User Service - Before Refactoring
//!
//! This module handles user management but has several code quality issues.

use std::collections::HashMap;

pub struct User {
    pub id: u64,
    pub username: String,
    pub email: String,
    pub age: i32,
    pub status: String,
}

impl User {
    pub fn new(id: u64, username: &str, email: &str, age: i32) -> Self {
        if username.is_empty() {
            panic!("Username cannot be empty");
        }
        if !email.contains('@') {
            panic!("Invalid email format");
        }
        if age < 0 || age > 150 {
            panic!("Invalid age");
        }
        
        Self {
            id,
            username: username.to_string(),
            email: email.to_string(),
            age,
            status: "active".to_string(),
        }
    }
}

pub struct UserService {
    users: HashMap<u64, User>,
    next_id: u64,
    db_connection: Option<String>,
}

impl UserService {
    pub fn new() -> Self {
        Self {
            users: HashMap::new(),
            next_id: 1,
            db_connection: None,
        }
    }
    
    pub fn connect(&mut self, connection_string: &str) {
        self.db_connection = Some(connection_string.to_string());
        println!("Connected to database: {}", connection_string);
    }
    
    pub fn create_user(&mut self, username: &str, email: &str, age: i32) -> u64 {
        let id = self.next_id;
        self.next_id += 1;
        
        let user = User::new(id, username, email, age);
        self.users.insert(id, user);
        
        if let Some(ref conn) = self.db_connection {
            println!("Saving user to database: {}", conn);
        }
        
        id
    }
    
    pub fn get_user(&self, id: u64) -> &User {
        self.users.get(&id).unwrap()
    }
    
    pub fn update_email(&mut self, id: u64, new_email: &str) -> bool {
        if !new_email.contains('@') {
            return false;
        }
        
        if let Some(user) = self.users.get_mut(&id) {
            user.email = new_email.to_string();
            true
        } else {
            false
        }
    }
    
    pub fn delete_user(&mut self, id: u64) {
        self.users.remove(&id);
    }
    
    pub fn list_active_users(&self) -> Vec<&User> {
        let mut result = Vec::new();
        for user in self.users.values() {
            if user.status == "active" {
                result.push(user);
            }
        }
        result
    }
    
    pub fn search_by_username(&self, query: &str) -> Vec<&User> {
        let mut result = Vec::new();
        for user in self.users.values() {
            if user.username.contains(query) {
                result.push(user);
            }
        }
        result
    }
    
    pub fn get_user_stats(&self) -> HashMap<String, i32> {
        let mut stats = HashMap::new();
        let mut active = 0;
        let mut inactive = 0;
        let mut total_age = 0;
        
        for user in self.users.values() {
            if user.status == "active" {
                active += 1;
            } else {
                inactive += 1;
            }
            total_age += user.age;
        }
        
        stats.insert("active".to_string(), active);
        stats.insert("inactive".to_string(), inactive);
        stats.insert("total".to_string(), (active + inactive) as i32);
        
        if !self.users.is_empty() {
            let avg = total_age / self.users.len() as i32;
            stats.insert("average_age".to_string(), avg);
        }
        
        stats
    }
    
    pub fn batch_update_status(&mut self, ids: &[u64], new_status: &str) -> usize {
        let mut count = 0;
        for id in ids {
            if let Some(user) = self.users.get_mut(id) {
                user.status = new_status.to_string();
                count += 1;
            }
        }
        count
    }
}

pub fn process_user_registration(data: &str) -> User {
    let parts: Vec<&str> = data.split(',').collect();
    if parts.len() != 3 {
        panic!("Invalid data format");
    }
    
    let username = parts[0].trim();
    let email = parts[1].trim();
    let age: i32 = parts[2].trim().parse().unwrap();
    
    User::new(0, username, email, age)
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_create_user() {
        let mut service = UserService::new();
        let id = service.create_user("alice", "alice@example.com", 25);
        assert_eq!(service.get_user(id).username, "alice");
    }
    
    #[test]
    #[should_panic]
    fn test_invalid_email() {
        User::new(1, "bob", "not-an-email", 30);
    }
}
```

### Refactoring Requirements

1. **Replace panics with Result types**: All validation errors should return `Result` instead of panicking
2. **Add proper error types**: Create an enum for different error cases
3. **Use builder pattern**: Create a `UserBuilder` for constructing users
4. **Add type safety**: Replace `String` status with an enum
5. **Improve API**: Return `Option` or `Result` instead of panicking
6. **Reduce allocations**: Minimize unnecessary string allocations
7. **Add validation**: Extract validation logic into reusable functions

### Questions

1. **Error Type Design**: Design a proper error enum for this module. What variants should it have?

2. **Builder Pattern**: Implement a `UserBuilder` that validates fields incrementally and returns a `Result<User, UserError>`.

3. **Status Enum**: Replace the `String` status with a proper enum. What variants should it have?

4. **Refactored UserService**: Show the refactored `UserService` with proper error handling and no panics.

5. **API Improvements**: What additional improvements would you make to the public API?

### Expected Output Format

```rust
// Error type
#[derive(Debug, Clone, PartialEq)]
pub enum UserError {
    EmptyUsername,
    InvalidEmail { provided: String },
    InvalidAge { provided: i32, min: i32, max: i32 },
    UserNotFound { id: u64 },
    InvalidDataFormat { expected: usize, got: usize },
    ParseError { field: String, reason: String },
}

impl std::fmt::Display for UserError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            UserError::EmptyUsername => write!(f, "Username cannot be empty"),
            UserError::InvalidEmail { provided } => {
                write!(f, "Invalid email format: {}", provided)
            }
            UserError::InvalidAge { provided, min, max } => {
                write!(f, "Age {} is outside valid range {}-{}", provided, min, max)
            }
            UserError::UserNotFound { id } => write!(f, "User with id {} not found", id),
            UserError::InvalidDataFormat { expected, got } => {
                write!(f, "Expected {} fields, got {}", expected, got)
            }
            UserError::ParseError { field, reason } => {
                write!(f, "Failed to parse field '{}': {}", field, reason)
            }
        }
    }
}

impl std::error::Error for UserError {}

// Status enum
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum UserStatus {
    Active,
    Inactive,
    Suspended,
    Pending,
}

impl Default for UserStatus {
    fn default() -> Self {
        UserStatus::Pending
    }
}

impl std::fmt::Display for UserStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            UserStatus::Active => write!(f, "active"),
            UserStatus::Inactive => write!(f, "inactive"),
            UserStatus::Suspended => write!(f, "suspended"),
            UserStatus::Pending => write!(f, "pending"),
        }
    }
}

// User with improved design
pub struct User {
    id: u64,
    username: String,
    email: String,
    age: u8, // Changed to u8 since age can't be negative
    status: UserStatus,
    created_at: std::time::Instant,
}

impl User {
    pub fn id(&self) -> u64 { self.id }
    pub fn username(&self) -> &str { &self.username }
    pub fn email(&self) -> &str { &self.email }
    pub fn age(&self) -> u8 { self.age }
    pub fn status(&self) -> UserStatus { self.status }
}

// UserBuilder
pub struct UserBuilder {
    id: Option<u64>,
    username: Option<String>,
    email: Option<String>,
    age: Option<u8>,
    status: UserStatus,
}

impl UserBuilder {
    pub fn new() -> Self {
        Self {
            id: None,
            username: None,
            email: None,
            age: None,
            status: UserStatus::default(),
        }
    }
    
    pub fn id(mut self, id: u64) -> Self {
        self.id = Some(id);
        self
    }
    
    pub fn username(mut self, username: impl Into<String>) -> Self {
        self.username = Some(username.into());
        self
    }
    
    pub fn email(mut self, email: impl Into<String>) -> Self {
        self.email = Some(email.into());
        self
    }
    
    pub fn age(mut self, age: u8) -> Self {
        self.age = Some(age);
        self
    }
    
    pub fn status(mut self, status: UserStatus) -> Self {
        self.status = status;
        self
    }
    
    pub fn build(self) -> Result<User, UserError> {
        let username = self.username.ok_or(UserError::EmptyUsername)?;
        if username.is_empty() {
            return Err(UserError::EmptyUsername);
        }
        
        let email = self.email.ok_or(UserError::EmptyUsername)?;
        if !Self::is_valid_email(&email) {
            return Err(UserError::InvalidEmail { provided: email });
        }
        
        let age = self.age.unwrap_or(0);
        if age > 150 {
            return Err(UserError::InvalidAge { 
                provided: age as i32, 
                min: 0, 
                max: 150 
            });
        }
        
        Ok(User {
            id: self.id.unwrap_or(0),
            username,
            email,
            age,
            status: self.status,
            created_at: std::time::Instant::now(),
        })
    }
    
    fn is_valid_email(email: &str) -> bool {
        email.contains('@') && !email.starts_with('@') && !email.ends_with('@')
    }
}

impl Default for UserBuilder {
    fn default() -> Self {
        Self::new()
    }
}

// Refactored UserService
pub struct UserService {
    users: HashMap<u64, User>,
    next_id: u64,
}

impl UserService {
    pub fn new() -> Self {
        Self {
            users: HashMap::new(),
            next_id: 1,
        }
    }
    
    pub fn create_user(&mut self, builder: UserBuilder) -> Result<u64, UserError> {
        let id = self.next_id;
        self.next_id += 1;
        
        let user = builder.id(id).build()?;
        self.users.insert(id, user);
        Ok(id)
    }
    
    pub fn get_user(&self, id: u64) -> Option<&User> {
        self.users.get(&id)
    }
    
    pub fn update_email(&mut self, id: u64, new_email: &str) -> Result<(), UserError> {
        if !new_email.contains('@') {
            return Err(UserError::InvalidEmail { 
                provided: new_email.to_string() 
            });
        }
        
        let user = self.users.get_mut(&id)
            .ok_or(UserError::UserNotFound { id })?;
        
        user.email = new_email.to_string();
        Ok(())
    }
    
    pub fn delete_user(&mut self, id: u64) -> Result<(), UserError> {
        self.users.remove(&id)
            .ok_or(UserError::UserNotFound { id })?;
        Ok(())
    }
    
    pub fn list_users_by_status(&self, status: UserStatus) -> Vec<&User> {
        self.users.values()
            .filter(|u| u.status() == status)
            .collect()
    }
    
    pub fn search_by_username(&self, query: &str) -> Vec<&User> {
        self.users.values()
            .filter(|u| u.username().contains(query))
            .collect()
    }
}

// Improved parsing function
pub fn parse_user_registration(data: &str) -> Result<User, UserError> {
    let parts: Vec<&str> = data.split(',').collect();
    if parts.len() != 3 {
        return Err(UserError::InvalidDataFormat { 
            expected: 3, 
            got: parts.len() 
        });
    }
    
    let age: u8 = parts[2].trim()
        .parse()
        .map_err(|e| UserError::ParseError { 
            field: "age".to_string(), 
            reason: e.to_string() 
        })?;
    
    UserBuilder::new()
        .username(parts[0].trim())
        .email(parts[1].trim())
        .age(age)
        .build()
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Error enum design | 2 | Comprehensive error variants with context |
| Builder pattern | 2 | Proper builder with incremental validation |
| Type safety | 2 | Status enum, u8 for age, proper types |
| No panics | 2 | All functions return Result/Option |
| API improvements | 2 | Additional improvements (immutability, iterators, etc.) |
| **Total** | **10** | |

### Difficulty Rating: 6/10

---

## Benchmark 4: Module Hierarchy and Import Analysis

### Task Name: `module_import_analysis`

### Description
Analyze a complex module hierarchy with re-exports, feature-gated modules, and cross-module dependencies. Answer questions about visibility, imports, and module organization.

### Sample Code Structure

```rust
// src/lib.rs
//! Selfware Core Library
//!
//! This is the main library crate for the Selfware project.

#![warn(missing_docs)]
#![cfg_attr(feature = "nightly", feature(async_fn_in_trait))]

pub mod agent;
pub mod config;
pub mod devops;
pub mod error;
pub mod output;

#[cfg(feature = "ui")]
pub mod ui;

#[cfg(feature = "tui")]
pub use ui::tui;

pub use error::{Error, Result};

/// Library version
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Prelude module for convenient imports
pub mod prelude {
    pub use crate::agent::{Agent, AgentConfig};
    pub use crate::config::AppConfig;
    pub use crate::error::{Error, Result};
    
    #[cfg(feature = "ui")]
    pub use crate::ui::Theme;
}

// src/agent/mod.rs
//! Agent System
//!
//! Provides the core agent functionality for task execution.

pub mod capabilities;
pub mod context;
pub mod memory;
pub mod planner;

mod executor;
mod tools;

pub use capabilities::{Capability, CapabilityRegistry};
pub use context::{AgentContext, ContextBuilder};
pub use memory::{Memory, MemoryStore};
pub use planner::{Plan, Planner};

use executor::TaskExecutor;
use tools::ToolRegistry;

/// Core agent struct
pub struct Agent {
    config: AgentConfig,
    executor: TaskExecutor,
    tools: ToolRegistry,
}

/// Agent configuration
#[derive(Debug, Clone)]
pub struct AgentConfig {
    /// Agent name
    pub name: String,
    /// Maximum iterations
    pub max_iterations: usize,
    /// Enable tracing
    pub tracing: bool,
}

impl Agent {
    /// Create a new agent with the given configuration
    pub fn new(config: AgentConfig) -> Self {
        Self {
            executor: TaskExecutor::new(),
            tools: ToolRegistry::default(),
            config,
        }
    }
    
    /// Execute a task
    pub async fn execute(&mut self, task: &str) -> Result<String, crate::Error> {
        self.executor.run(task, &self.tools).await
    }
}

// src/agent/capabilities.rs
//! Agent Capabilities
//!
//! Defines what an agent can do.

use std::collections::HashMap;

/// A capability that an agent can have
pub trait Capability: Send + Sync {
    /// Capability name
    fn name(&self) -> &str;
    /// Capability description
    fn description(&self) -> &str;
    /// Check if this capability is available
    fn is_available(&self) -> bool;
}

/// Registry of capabilities
pub struct CapabilityRegistry {
    capabilities: HashMap<String, Box<dyn Capability>>,
}

impl CapabilityRegistry {
    /// Register a new capability
    pub fn register<C: Capability + 'static>(&mut self, cap: C) {
        self.capabilities.insert(cap.name().to_string(), Box::new(cap));
    }
}

impl Default for CapabilityRegistry {
    fn default() -> Self {
        Self {
            capabilities: HashMap::new(),
        }
    }
}

// src/agent/executor.rs (private module)
//! Task Executor
//!
//! Internal task execution engine.

use super::tools::ToolRegistry;
use crate::error::Error;

pub struct TaskExecutor {
    max_depth: usize,
}

impl TaskExecutor {
    pub fn new() -> Self {
        Self { max_depth: 10 }
    }
    
    pub async fn run(&self, task: &str, tools: &ToolRegistry) -> Result<String, Error> {
        // Execution logic
        Ok(format!("Executed: {}", task))
    }
}

impl Default for TaskExecutor {
    fn default() -> Self {
        Self::new()
    }
}

// src/ui/mod.rs (feature-gated)
//! UI Components
//!
//! Available when the "ui" feature is enabled.

pub mod components;
pub mod style;

#[cfg(feature = "tui")]
pub mod tui;

pub use components::{Button, Component, Panel};
pub use style::{Style, Theme};

// src/ui/tui/mod.rs (feature-gated)
//! Terminal UI Components
//!
//! Available when the "tui" feature is enabled.

pub mod app;
pub mod layout;
pub mod widgets;

pub use app::TuiApp;
pub use layout::LayoutEngine;
pub use widgets::{TextWidget, Widget};

// src/ui/tui/app.rs
//! TUI Application

use super::layout::LayoutEngine;
use super::widgets::Widget;
use crate::ui::Theme;

/// TUI Application
pub struct TuiApp {
    layout: LayoutEngine,
    theme: Theme,
}

impl TuiApp {
    pub fn new(theme: Theme) -> Self {
        Self {
            layout: LayoutEngine::default(),
            theme,
        }
    }
}

// src/config.rs
//! Configuration Management

use std::path::PathBuf;

/// Application configuration
#[derive(Debug, Clone)]
pub struct AppConfig {
    /// Working directory
    pub work_dir: PathBuf,
    /// Log level
    pub log_level: String,
    /// Enable debug mode
    pub debug: bool,
}

impl AppConfig {
    /// Load configuration from a file
    pub fn from_file(path: &std::path::Path) -> Result<Self, crate::Error> {
        // Loading logic
        Ok(Self {
            work_dir: path.parent().unwrap_or(std::path::Path::new(".")).to_path_buf(),
            log_level: "info".to_string(),
            debug: false,
        })
    }
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            work_dir: std::env::current_dir().unwrap_or_default(),
            log_level: "info".to_string(),
            debug: false,
        }
    }
}

// src/error.rs
//! Error Types

use std::fmt;

/// Main error type
#[derive(Debug)]
pub enum Error {
    /// IO error
    Io(std::io::Error),
    /// Configuration error
    Config(String),
    /// Agent error
    Agent(String),
    /// UI error
    Ui(String),
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::Io(e) => write!(f, "IO error: {}", e),
            Error::Config(msg) => write!(f, "Config error: {}", msg),
            Error::Agent(msg) => write!(f, "Agent error: {}", msg),
            Error::Ui(msg) => write!(f, "UI error: {}", msg),
        }
    }
}

impl std::error::Error for Error {}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        Error::Io(e)
    }
}

/// Result type alias
pub type Result<T> = std::result::Result<T, Error>;
```

### Questions

1. **Visibility Analysis**: For each item below, determine its visibility (public/private) and where it can be accessed from:
   - `Agent::execute`
   - `TaskExecutor`
   - `CapabilityRegistry::register`
   - `TuiApp::new`
   - `Theme`

2. **Import Paths**: What are the valid import paths for:
   - Using `Agent` from an external crate
   - Using `TuiApp` when both "ui" and "tui" features are enabled
   - Using `Capability` trait
   - Using items from `prelude`

3. **Feature Gates**: Which modules/items are affected by feature gates? What happens if you try to use `tui` without the "tui" feature?

4. **Re-exports**: What items are re-exported at the crate root? Why might the crate use re-exports?

5. **Cross-module Dependencies**: Trace the dependency chain when `Agent::execute` is called. Which modules does it depend on?

### Expected Output Format

```json
{
  "question_1": {
    "Agent::execute": {
      "visibility": "public",
      "accessible_from": ["anywhere (external crates, all modules)"]
    },
    "TaskExecutor": {
      "visibility": "private (pub in agent module only)",
      "accessible_from": ["agent module and submodules only"]
    },
    "CapabilityRegistry::register": {
      "visibility": "public",
      "accessible_from": ["anywhere"]
    },
    "TuiApp::new": {
      "visibility": "public (when tui feature enabled)",
      "accessible_from": ["anywhere when tui feature is enabled"]
    },
    "Theme": {
      "visibility": "public (when ui feature enabled)",
      "accessible_from": ["anywhere when ui feature is enabled"]
    }
  },
  "question_2": {
    "Agent_external": "selfware::agent::Agent or selfware::prelude::Agent",
    "TuiApp": "selfware::tui::TuiApp (re-export) or selfware::ui::tui::TuiApp",
    "Capability": "selfware::agent::capabilities::Capability or selfware::agent::Capability",
    "prelude": "selfware::prelude::*"
  },
  "question_3": {
    "ui_module": "Gated by 'ui' feature",
    "tui_module": "Gated by 'tui' feature (also requires 'ui')",
    "Theme": "Gated by 'ui' feature",
    "without_tui_feature": "Compilation error: module not found or feature not enabled"
  },
  "question_4": {
    "re_exports": ["Error", "Result", "tui (when tui feature enabled)"],
    "reasons": ["Convenience - common items at crate root", "Feature-gated re-exports simplify conditional imports"]
  },
  "question_5": {
    "dependency_chain": [
      "agent::Agent::execute",
      "-> agent::executor::TaskExecutor::run",
      "-> agent::tools::ToolRegistry",
      "-> error::Error"
    ]
  }
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Visibility analysis | 2 | Correctly identifies visibility for all items |
| Import paths | 2 | Correctly provides valid import paths |
| Feature gates | 2 | Correctly identifies feature-gated items |
| Re-exports | 2 | Correctly identifies re-exports and their purpose |
| Dependency chain | 2 | Correctly traces cross-module dependencies |
| **Total** | **10** | |

### Difficulty Rating: 5/10

---

## Benchmark 5: Concurrency Pattern Analysis

### Task Name: `concurrency_pattern_analysis`

### Description
Analyze concurrent Rust code using async/await, channels, and shared state (Arc/Mutex). Identify potential issues like deadlocks, race conditions, and performance problems. Explain the patterns used.

### Sample Code
```rust
//! Async Task Scheduler
//!
//! A concurrent task scheduler using tokio for async execution.

use std::collections::VecDeque;
use std::sync::Arc;
use tokio::sync::{mpsc, Mutex, RwLock, Notify};
use tokio::task::JoinHandle;

/// Task priority levels
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Priority {
    Low = 0,
    Normal = 1,
    High = 2,
    Critical = 3,
}

/// A task to be executed
#[derive(Debug)]
pub struct Task {
    pub id: u64,
    pub name: String,
    pub priority: Priority,
    pub future: Box<dyn std::future::Future<Output = TaskResult> + Send + Unpin>,
}

/// Task execution result
#[derive(Debug, Clone)]
pub enum TaskResult {
    Success(String),
    Failed(String),
    Cancelled,
}

/// Task statistics
#[derive(Debug, Default)]
pub struct TaskStats {
    pub submitted: u64,
    pub completed: u64,
    pub failed: u64,
    pub cancelled: u64,
}

/// Shared state for the scheduler
struct SchedulerState {
    /// Task queues by priority
    queues: [VecDeque<Task>; 4],
    /// Running tasks
    running: Vec<u64>,
    /// Task statistics
    stats: TaskStats,
    /// Shutdown signal
    shutdown: bool,
}

impl SchedulerState {
    fn new() -> Self {
        Self {
            queues: [
                VecDeque::new(),
                VecDeque::new(),
                VecDeque::new(),
                VecDeque::new(),
            ],
            running: Vec::new(),
            stats: TaskStats::default(),
            shutdown: false,
        }
    }
    
    fn queue_for_priority(&mut self, priority: Priority) -> &mut VecDeque<Task> {
        &mut self.queues[priority as usize]
    }
}

/// Async task scheduler
pub struct TaskScheduler {
    state: Arc<RwLock<SchedulerState>>,
    task_tx: mpsc::Sender<Task>,
    workers: Vec<JoinHandle<()>>,
    max_concurrent: usize,
    notify: Arc<Notify>,
}

impl TaskScheduler {
    /// Create a new task scheduler
    pub fn new(max_concurrent: usize) -> Self {
        let (task_tx, mut task_rx) = mpsc::channel::<Task>(100);
        let state = Arc::new(RwLock::new(SchedulerState::new()));
        let notify = Arc::new(Notify::new());
        
        let mut scheduler = Self {
            state: state.clone(),
            task_tx,
            workers: Vec::new(),
            max_concurrent,
            notify: notify.clone(),
        };
        
        // Spawn worker tasks
        for worker_id in 0..max_concurrent {
            let state = state.clone();
            let notify = notify.clone();
            
            let handle = tokio::spawn(async move {
                loop {
                    let task = {
                        let mut state = state.write().await;
                        
                        // Check for shutdown
                        if state.shutdown {
                            break;
                        }
                        
                        // Find highest priority task
                        let mut found_task = None;
                        for priority in [Priority::Critical, Priority::High, Priority::Normal, Priority::Low] {
                            if let Some(task) = state.queue_for_priority(priority).pop_front() {
                                found_task = Some(task);
                                break;
                            }
                        }
                        
                        if let Some(ref task) = found_task {
                            state.running.push(task.id);
                        }
                        
                        found_task
                    };
                    
                    if let Some(task) = task {
                        // Execute the task
                        let result = (task.future).await;
                        
                        let mut state = state.write().await;
                        state.running.retain(|&id| id != task.id);
                        
                        match result {
                            TaskResult::Success(_) => state.stats.completed += 1,
                            TaskResult::Failed(_) => state.stats.failed += 1,
                            TaskResult::Cancelled => state.stats.cancelled += 1,
                        }
                        
                        drop(state);
                        notify.notify_one();
                    } else {
                        // No tasks available, wait for notification
                        drop(state);
                        notify.notified().await;
                    }
                }
                
                println!("Worker {} shutting down", worker_id);
            });
            
            scheduler.workers.push(handle);
        }
        
        // Spawn task receiver
        let state_clone = state.clone();
        let notify_clone = notify.clone();
        let receiver_handle = tokio::spawn(async move {
            while let Some(task) = task_rx.recv().await {
                let mut state = state_clone.write().await;
                
                if state.shutdown {
                    break;
                }
                
                state.stats.submitted += 1;
                let priority = task.priority;
                state.queue_for_priority(priority).push_back(task);
                
                drop(state);
                notify_clone.notify_one();
            }
        });
        
        scheduler.workers.push(receiver_handle);
        
        scheduler
    }
    
    /// Submit a new task
    pub async fn submit(&self, task: Task) -> Result<(), String> {
        self.task_tx.send(task).await
            .map_err(|_| "Scheduler is shut down".to_string())
    }
    
    /// Get current statistics
    pub async fn stats(&self) -> TaskStats {
        let state = self.state.read().await;
        TaskStats {
            submitted: state.stats.submitted,
            completed: state.stats.completed,
            failed: state.stats.failed,
            cancelled: state.stats.cancelled,
        }
    }
    
    /// Get number of running tasks
    pub async fn running_count(&self) -> usize {
        let state = self.state.read().await;
        state.running.len()
    }
    
    /// Get queue lengths by priority
    pub async fn queue_lengths(&self) -> [usize; 4] {
        let state = self.state.read().await;
        [
            state.queues[0].len(),
            state.queues[1].len(),
            state.queues[2].len(),
            state.queues[3].len(),
        ]
    }
    
    /// Shutdown the scheduler gracefully
    pub async fn shutdown(self) {
        // Signal shutdown
        {
            let mut state = self.state.write().await;
            state.shutdown = true;
        }
        self.notify.notify_waiters();
        
        // Wait for all workers to finish
        for handle in self.workers {
            let _ = handle.await;
        }
    }
}

/// A rate limiter for controlling task execution rate
pub struct RateLimiter {
    /// Maximum requests per interval
    max_requests: usize,
    /// Current interval request count
    count: Mutex<usize>,
    /// Interval duration
    interval: std::time::Duration,
    /// Last reset time
    last_reset: Mutex<std::time::Instant>,
}

impl RateLimiter {
    pub fn new(max_requests: usize, interval: std::time::Duration) -> Self {
        Self {
            max_requests,
            count: Mutex::new(0),
            interval,
            last_reset: Mutex::new(std::time::Instant::now()),
        }
    }
    
    pub async fn acquire(&self) -> bool {
        let mut count = self.count.lock().await;
        let mut last_reset = self.last_reset.lock().await;
        
        // Check if we need to reset the counter
        if last_reset.elapsed() >= self.interval {
            *count = 0;
            *last_reset = std::time::Instant::now();
        }
        
        if *count < self.max_requests {
            *count += 1;
            true
        } else {
            false
        }
    }
}

/// Shared counter with atomic operations
pub struct SharedCounter {
    value: Arc<Mutex<i64>>,
}

impl SharedCounter {
    pub fn new(initial: i64) -> Self {
        Self {
            value: Arc::new(Mutex::new(initial)),
        }
    }
    
    pub async fn increment(&self) -> i64 {
        let mut value = self.value.lock().await;
        *value += 1;
        *value
    }
    
    pub async fn decrement(&self) -> i64 {
        let mut value = self.value.lock().await;
        *value -= 1;
        *value
    }
    
    pub async fn get(&self) -> i64 {
        *self.value.lock().await
    }
    
    /// Create a clone that shares the same counter
    pub fn clone(&self) -> Self {
        Self {
            value: Arc::clone(&self.value),
        }
    }
}

/// A concurrent cache with read-heavy workload optimization
pub struct ConcurrentCache<K, V> {
    data: Arc<RwLock<std::collections::HashMap<K, V>>>,
    hits: Arc<Mutex<u64>>,
    misses: Arc<Mutex<u64>>,
}

impl<K: std::hash::Hash + Eq + Clone, V: Clone> ConcurrentCache<K, V> {
    pub fn new() -> Self {
        Self {
            data: Arc::new(RwLock::new(std::collections::HashMap::new())),
            hits: Arc::new(Mutex::new(0)),
            misses: Arc::new(Mutex::new(0)),
        }
    }
    
    pub async fn get(&self, key: &K) -> Option<V> {
        let data = self.data.read().await;
        let result = data.get(key).cloned();
        drop(data);
        
        if result.is_some() {
            let mut hits = self.hits.lock().await;
            *hits += 1;
        } else {
            let mut misses = self.misses.lock().await;
            *misses += 1;
        }
        
        result
    }
    
    pub async fn insert(&self, key: K, value: V) {
        let mut data = self.data.write().await;
        data.insert(key, value);
    }
    
    pub async fn stats(&self) -> (u64, u64) {
        let hits = *self.hits.lock().await;
        let misses = *self.misses.lock().await;
        (hits, misses)
    }
}

impl<K, V> Clone for ConcurrentCache<K, V> {
    fn clone(&self) -> Self {
        Self {
            data: Arc::clone(&self.data),
            hits: Arc::clone(&self.hits),
            misses: Arc::clone(&self.misses),
        }
    }
}

/// Example usage demonstrating patterns
pub mod examples {
    use super::*;
    
    /// Example: Producer-consumer pattern with channels
    pub async fn producer_consumer_example() {
        let (tx, mut rx) = mpsc::channel::<i32>(10);
        
        // Producer
        let producer = tokio::spawn(async move {
            for i in 0..100 {
                if tx.send(i).await.is_err() {
                    break;
                }
            }
        });
        
        // Consumer
        let consumer = tokio::spawn(async move {
            let mut sum = 0;
            while let Some(value) = rx.recv().await {
                sum += value;
            }
            sum
        });
        
        let _ = producer.await;
        let result = consumer.await.unwrap();
        println!("Sum: {}", result);
    }
    
    /// Example: Shared state pattern
    pub async fn shared_state_example() {
        let counter = SharedCounter::new(0);
        
        let mut handles = vec![];
        
        for _ in 0..10 {
            let counter = counter.clone();
            let handle = tokio::spawn(async move {
                for _ in 0..100 {
                    counter.increment().await;
                }
            });
            handles.push(handle);
        }
        
        for handle in handles {
            let _ = handle.await;
        }
        
        println!("Final count: {}", counter.get().await);
    }
}
```

### Questions

1. **Synchronization Primitives**: Identify all synchronization primitives used in the code and explain what each protects:
   - `RwLock<SchedulerState>`
   - `Mutex<usize>` in RateLimiter
   - `mpsc::Channel`
   - `Notify`

2. **Potential Deadlocks**: Are there any potential deadlock scenarios? If yes, explain when and how they could occur. If no, explain why the code is deadlock-free.

3. **Performance Issues**: Identify any performance issues or inefficiencies in the concurrent code:
   - Look at the RateLimiter implementation
   - Look at the ConcurrentCache implementation
   - Consider lock granularity and duration

4. **Pattern Identification**: What concurrency patterns are used in this code? Match each pattern to the code that implements it:
   - Producer-Consumer
   - Worker Pool
   - Shared State
   - Rate Limiting

5. **Improvements**: Suggest improvements for:
   - The RateLimiter (hint: consider lock ordering and async)
   - The ConcurrentCache (hint: consider RwLock usage for stats)
   - The TaskScheduler (hint: consider task cancellation)

### Expected Output Format

```json
{
  "question_1": {
    "RwLock<SchedulerState>": "Protects all scheduler state (queues, running tasks, stats). Allows multiple readers or single writer.",
    "Mutex<usize> in RateLimiter": "Protects the request count and last reset time. Two separate mutexes could cause inconsistency.",
    "mpsc::Channel": "Provides async communication between task submitter and scheduler receiver. Backpressure with bounded channel.",
    "Notify": "Used for efficient waiting when no tasks are available. Workers wait instead of busy-polling."
  },
  "question_2": {
    "potential_deadlocks": true,
    "scenarios": [
      {
        "location": "RateLimiter::acquire",
        "issue": "Holds two mutexes simultaneously - if another task acquires them in opposite order, deadlock possible",
        "fix": "Use a single mutex for both fields, or acquire in consistent order"
      }
    ]
  },
  "question_3": {
    "rate_limiter_issues": [
      "Holds both mutexes for entire method duration",
      "No async-friendly rate limiting (just returns false instead of waiting)",
      "Two separate mutexes could lead to inconsistency"
    ],
    "concurrent_cache_issues": [
      "Stats updates acquire mutex even for reads (could use atomics)",
      "Holding read lock while acquiring stats mutex extends critical section"
    ]
  },
  "question_4": {
    "Producer-Consumer": "examples::producer_consumer_example with mpsc channel",
    "Worker Pool": "TaskScheduler with multiple worker tasks processing from shared queues",
    "Shared State": "SharedCounter with Arc<Mutex<i64>>",
    "Rate Limiting": "RateLimiter with token bucket-like behavior"
  },
  "question_5": {
    "rate_limiter_improvement": "Use tokio::time::Interval for periodic reset, single Mutex for state, or semaphore-based approach",
    "concurrent_cache_improvement": "Use AtomicU64 for stats instead of Mutex, reduce critical section",
    "task_scheduler_improvement": "Add cancellation tokens, use tokio::select! for graceful shutdown, consider work-stealing"
  }
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Synchronization primitives | 2 | Correctly identifies and explains each primitive |
| Deadlock analysis | 2 | Correctly identifies deadlock potential in RateLimiter |
| Performance issues | 2 | Identifies lock granularity and async issues |
| Pattern identification | 2 | Correctly matches patterns to code |
| Improvement suggestions | 2 | Provides valid improvement suggestions |
| **Total** | **10** | |

### Difficulty Rating: 7/10

---

## Summary

| Benchmark | Focus Area | Difficulty | Key Skills Tested |
|-----------|------------|------------|-------------------|
| 1. Trait Analysis | Traits, Generics, Associated Types | 6/10 | Trait hierarchies, blanket impls, error handling |
| 2. Lifetime Issues | Lifetimes, Borrow Checker | 7/10 | Self-referential structs, lifetime elision, borrowing rules |
| 3. Code Refactoring | Error Handling, API Design | 6/10 | Result types, builder pattern, type safety |
| 4. Module Analysis | Visibility, Imports, Features | 5/10 | Module hierarchy, re-exports, feature gates |
| 5. Concurrency | Async, Channels, Shared State | 7/10 | Deadlock detection, performance analysis, patterns |

## Running the Benchmarks

### For Localhost Testing with Qwen3.5

```bash
# Example: Test with a local Qwen3.5 model via Ollama or similar
# Each benchmark should be presented as a complete prompt

# Benchmark 1 - Traits
curl -X POST http://localhost:11434/api/generate \
  -d '{
    "model": "qwen3.5",
    "prompt": "Analyze this Rust trait hierarchy... [full code]",
    "stream": false
  }'

# Evaluate response against expected output criteria
```

### Scoring Guide

- **9-10 points**: Excellent understanding, all concepts correctly explained
- **7-8 points**: Good understanding, minor issues or omissions
- **5-6 points**: Basic understanding, some significant gaps
- **3-4 points**: Limited understanding, major gaps
- **0-2 points**: Poor understanding, fundamental misconceptions
