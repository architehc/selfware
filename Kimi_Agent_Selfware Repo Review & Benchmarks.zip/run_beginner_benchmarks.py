#!/usr/bin/env python3
"""
Beginner Rust Benchmark Test Runner for Qwen3.5 Models

This script runs the beginner-level Rust code understanding benchmarks
against a locally hosted Qwen3.5 model via OpenAI-compatible API.

Usage:
    python run_beginner_benchmarks.py --endpoint http://localhost:8000/v1
    
Or with Ollama:
    python run_beginner_benchmarks.py --endpoint http://localhost:11434/v1 --model qwen2.5-coder
"""

import argparse
import json
import requests
import sys
from dataclasses import dataclass
from typing import List, Dict, Optional
from datetime import datetime


@dataclass
class Benchmark:
    name: str
    description: str
    code: str
    questions: str
    expected_answers: Dict[int, str]
    points_per_question: Dict[int, int]
    difficulty: int


# Benchmark definitions
BENCHMARKS = [
    Benchmark(
        name="Benchmark 1: Struct and Enum Recognition",
        description="Test understanding of struct/enum definitions",
        code='''use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Represents a single key-value entry in the store
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Entry {
    pub key: String,
    pub value: String,
    pub tags: Vec<String>,
    pub metadata: HashMap<String, String>,
}

/// Error types for key-value store operations
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum KvStoreError {
    KeyNotFound(String),
    KeyAlreadyExists(String),
    StorageError(String),
    SerializationError(String),
}''',
        questions='''1. What is the name of the struct defined in this code?
2. How many fields does the Entry struct have? List them with their types.
3. What is the purpose of the #[derive(...)] attribute on the Entry struct?
4. What enum is defined and what are its variants?
5. Which variant of KvStoreError would be appropriate when a requested key doesn't exist in the store?''',
        expected_answers={
            1: "Entry",
            2: "4 fields: key: String, value: String, tags: Vec<String>, metadata: HashMap<String, String>",
            3: "Automatically implements Debug, Clone, Serialize, Deserialize traits",
            4: "KvStoreError with 4 variants: KeyNotFound, KeyAlreadyExists, StorageError, SerializationError",
            5: "KeyNotFound"
        },
        points_per_question={1: 1, 2: 2, 3: 2, 4: 2, 5: 1},
        difficulty=2
    ),
    
    Benchmark(
        name="Benchmark 2: Function Comprehension",
        description="Test understanding of function implementations",
        code='''impl Entry {
    pub fn new(key: impl Into<String>, value: impl Into<String>) -> Self {
        Self {
            key: key.into(),
            value: value.into(),
            tags: Vec::new(),
            metadata: HashMap::new(),
        }
    }

    pub fn with_tags(mut self, tags: Vec<String>) -> Self {
        self.tags = tags;
        self
    }

    pub fn add_tag(&mut self, tag: impl Into<String>) {
        self.tags.push(tag.into());
    }

    pub fn has_tag(&self, tag: &str) -> bool {
        self.tags.iter().any(|t| t == tag)
    }

    pub fn get_metadata(&self, key: &str) -> Option<&String> {
        self.metadata.get(key)
    }
}''',
        questions='''1. What does the `new` function do? What pattern does it follow?
2. What is the difference between `with_tags` and `add_tag` methods?
3. What does `has_tag` return if the entry has no tags at all?
4. What does `get_metadata` return if the key doesn't exist in metadata?
5. Which methods take `&mut self` vs `&self`? Why?''',
        expected_answers={
            1: "Creates a new Entry; follows the builder/constructor pattern",
            2: "with_tags replaces all tags (consumes self), add_tag appends one tag (mutates)",
            3: "false",
            4: "None",
            5: "&mut self: with_tags, add_tag (need to modify); &self: new, has_tag, get_metadata (read-only)"
        },
        points_per_question={1: 2, 2: 2, 3: 1, 4: 1, 5: 2},
        difficulty=3
    ),
    
    Benchmark(
        name="Benchmark 3: Cargo.toml Dependencies",
        description="Test understanding of Cargo.toml configuration",
        code='''[package]
name = "selfware"
version = "0.1.0"
edition = "2021"
license = "MIT"
description = "Your personal AI workshop"
rust-version = "1.91"

[dependencies]
tokio = { version = "1.43", features = ["rt-multi-thread", "macros", "sync", "time"] }
anyhow = "1.0"
serde = { version = "1.0", features = ["derive"] }
reqwest = { version = "0.13", features = ["json", "stream"] }
clap = { version = "4.4", features = ["derive"] }
tracing = "0.1"
chrono = { version = "0.4", features = ["serde"] }
uuid = { version = "1.6", features = ["v4"] }

[dev-dependencies]
tokio-test = "0.4"
criterion = { version = "0.8", features = ["html_reports"] }

[features]
default = []
tui = []
workflows = []
resilience = []''',
        questions='''1. What is the minimum Rust version required to build this project?
2. Which crate is used for async runtime and what features are enabled?
3. What is the difference between [dependencies] and [dev-dependencies]?
4. Which crate provides derive macros for serialization?
5. How would you enable the "tui" feature when building this project?
6. Which dependency is used for command-line argument parsing?''',
        expected_answers={
            1: "1.91",
            2: "tokio with rt-multi-thread, macros, sync, time",
            3: "dependencies: required for building/running; dev-dependencies: only for tests/benchmarks",
            4: "serde",
            5: "cargo build --features tui",
            6: "clap"
        },
        points_per_question={1: 1, 2: 2, 3: 2, 4: 1, 5: 2, 6: 1},
        difficulty=2
    ),
    
    Benchmark(
        name="Benchmark 4: Error Handling",
        description="Test understanding of Result and Option types",
        code='''pub type Result<T> = std::result::Result<T, KvStoreError>;

impl KvStore {
    pub fn get(&self, key: &str) -> Result<String> {
        match self.data.get(key) {
            Some(entry) => Ok(entry.value.clone()),
            None => Err(KvStoreError::KeyNotFound(key.to_string())),
        }
    }

    pub fn contains_key(&self, key: &str) -> bool {
        self.data.contains_key(key)
    }

    pub fn remove(&mut self, key: &str) -> Result<String> {
        match self.data.remove(key) {
            Some(entry) => {
                let value = entry.value.clone();
                if let Some(ref path) = self.path {
                    self.save()?;
                }
                Ok(value)
            }
            None => Err(KvStoreError::KeyNotFound(key.to_string())),
        }
    }

    pub fn get_entry(&self, key: &str) -> Result<&Entry> {
        self.data.get(key).ok_or_else(|| {
            KvStoreError::KeyNotFound(key.to_string())
        })
    }
}''',
        questions='''1. What is the return type of `get` and what does each variant represent?
2. What happens in `remove` if `self.path` is `None`?
3. What does the `?` operator do in `self.save()?`?
4. Rewrite `get_entry` using `match` instead of `ok_or_else`.
5. If `contains_key("foo")` returns `true`, what will `get("foo")` return?''',
        expected_answers={
            1: "Result<String>: Ok contains the value, Err contains KvStoreError",
            2: "The save() call is skipped, function continues and returns Ok(value)",
            3: "Unwraps Ok or returns Err early from the function",
            4: "match self.data.get(key) { Some(entry) => Ok(entry), None => Err(KvStoreError::KeyNotFound(key.to_string())) }",
            5: "Ok(the_value)"
        },
        points_per_question={1: 2, 2: 2, 3: 2, 4: 2, 5: 1},
        difficulty=4
    ),
    
    Benchmark(
        name="Benchmark 5: Pattern Recognition",
        description="Test identification of common Rust patterns",
        code='''#[tokio::main]
async fn main() -> Result<()> {
    let config = Config::load(None)?;
    
    let client = ApiClient::new(&config)?;
    
    let messages = vec![
        Message::system("You are a helpful assistant."),
        Message::user("Hello!"),
    ];
    
    let response = client.chat(messages, None, ThinkingMode::Disabled).await?;
    let answer = &response.choices[0].message.content;
    
    println!("Response: {}", answer);
    
    Ok(())
}

impl Default for KvStore {
    fn default() -> Self {
        Self::new()
    }
}

impl std::fmt::Display for KvStoreError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            KvStoreError::KeyNotFound(key) => write!(f, "Key not found: {}", key),
            KvStoreError::StorageError(msg) => write!(f, "Storage error: {}", msg),
            _ => write!(f, "Unknown error"),
        }
    }
}''',
        questions='''1. What does `#[tokio::main]` do and why is the `main` function marked `async`?
2. What pattern does `impl Default for KvStore` implement? Why is this useful?
3. What trait is being implemented in the second `impl` block and what method does it require?
4. What does the `_` pattern mean in the match arm `_ => write!(f, "Unknown error")`?
5. What would happen if we removed `.await` from `client.chat(...).await?`?''',
        expected_answers={
            1: "Sets up tokio runtime; async allows using await inside main",
            2: "Default trait; allows KvStore::default() and use with #[derive(Default)]",
            3: "Display trait; requires fmt method",
            4: "Wildcard pattern that matches any remaining variants",
            5: "Compilation error: can't use ? on Future, need to await first"
        },
        points_per_question={1: 2, 2: 2, 3: 2, 4: 1, 5: 2},
        difficulty=3
    ),
]


class BenchmarkRunner:
    def __init__(self, endpoint: str, model: str, temperature: float = 0.0):
        self.endpoint = endpoint.rstrip('/')
        self.model = model
        self.temperature = temperature
        self.results = []
        
    def query_model(self, prompt: str) -> str:
        """Send query to the model and return response."""
        try:
            response = requests.post(
                f"{self.endpoint}/chat/completions",
                json={
                    "model": self.model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": self.temperature
                },
                timeout=120
            )
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except requests.exceptions.RequestException as e:
            print(f"Error querying model: {e}")
            return f"ERROR: {e}"
    
    def build_prompt(self, benchmark: Benchmark) -> str:
        """Build the prompt for a benchmark."""
        return f"""You are a Rust code analysis assistant. Analyze the following code carefully and answer the questions precisely.

## Code to Analyze:

```{"toml" if "Cargo.toml" in benchmark.name else "rust"}
{benchmark.code}
```

## Questions:

{benchmark.questions}

## Instructions:
- Answer each question clearly and concisely
- For code rewrites, provide valid Rust syntax
- Be specific about types, patterns, and behavior
- Number your answers to match the questions

## Your Answers:"""
    
    def run_benchmark(self, benchmark: Benchmark, verbose: bool = False) -> Dict:
        """Run a single benchmark and return results."""
        print(f"\n{'='*60}")
        print(f"Running: {benchmark.name}")
        print(f"Difficulty: {benchmark.difficulty}/10")
        print(f"{'='*60}")
        
        prompt = self.build_prompt(benchmark)
        response = self.query_model(prompt)
        
        if verbose:
            print(f"\nModel Response:\n{response}")
        
        # Calculate total possible points
        total_points = sum(benchmark.points_per_question.values())
        
        result = {
            "name": benchmark.name,
            "difficulty": benchmark.difficulty,
            "response": response,
            "total_points": total_points,
            "timestamp": datetime.now().isoformat()
        }
        
        return result
    
    def run_all(self, verbose: bool = False) -> List[Dict]:
        """Run all benchmarks."""
        print(f"Starting Benchmark Run")
        print(f"Endpoint: {self.endpoint}")
        print(f"Model: {self.model}")
        print(f"Temperature: {self.temperature}")
        
        for benchmark in BENCHMARKS:
            result = self.run_benchmark(benchmark, verbose)
            self.results.append(result)
        
        return self.results
    
    def generate_report(self, output_file: Optional[str] = None):
        """Generate and save the benchmark report."""
        report = {
            "metadata": {
                "endpoint": self.endpoint,
                "model": self.model,
                "temperature": self.temperature,
                "timestamp": datetime.now().isoformat(),
                "total_benchmarks": len(BENCHMARKS)
            },
            "results": self.results,
            "summary": {
                "benchmarks_completed": len(self.results),
                "total_questions": sum(len(b.points_per_question) for b in BENCHMARKS),
                "total_possible_points": sum(sum(b.points_per_question.values()) for b in BENCHMARKS)
            }
        }
        
        # Print summary
        print(f"\n{'='*60}")
        print("BENCHMARK SUMMARY")
        print(f"{'='*60}")
        
        for i, result in enumerate(self.results, 1):
            print(f"\n{i}. {result['name']}")
            print(f"   Difficulty: {result['difficulty']}/10")
            print(f"   Max Points: {result['total_points']}")
            print(f"   Status: {'Completed' if not result['response'].startswith('ERROR') else 'Failed'}")
        
        print(f"\n{'='*60}")
        print(f"Total Benchmarks: {report['summary']['benchmarks_completed']}")
        print(f"Total Questions: {report['summary']['total_questions']}")
        print(f"Total Possible Points: {report['summary']['total_possible_points']}")
        print(f"{'='*60}")
        
        # Save to file if specified
        if output_file:
            with open(output_file, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"\nReport saved to: {output_file}")
        
        return report


def main():
    parser = argparse.ArgumentParser(
        description="Run beginner Rust benchmarks against Qwen3.5 models"
    )
    parser.add_argument(
        "--endpoint",
        default="http://localhost:8000/v1",
        help="API endpoint URL (default: http://localhost:8000/v1)"
    )
    parser.add_argument(
        "--model",
        default="Qwen/Qwen3.5-Coder",
        help="Model name (default: Qwen/Qwen3.5-Coder)"
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.0,
        help="Sampling temperature (default: 0.0)"
    )
    parser.add_argument(
        "--output",
        default="benchmark_results.json",
        help="Output file for results (default: benchmark_results.json)"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Print model responses"
    )
    
    args = parser.parse_args()
    
    runner = BenchmarkRunner(
        endpoint=args.endpoint,
        model=args.model,
        temperature=args.temperature
    )
    
    runner.run_all(verbose=args.verbose)
    runner.generate_report(output_file=args.output)


if __name__ == "__main__":
    main()
