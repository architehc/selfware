use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_int};
use std::slice;
use std::ptr;
use std::mem;

/// Security scanner for detecting secrets in memory
pub struct SecurityScanner {
    /// Pattern database (externally allocated)
    patterns: *const Pattern,
    pattern_count: usize,
    /// Scan buffer (reused across scans)
    buffer: *mut u8,
    buffer_capacity: usize,
}

#[repr(C)]
pub struct Pattern {
    pub regex_ptr: *const c_char,
    pub severity: c_int,
    pub name: *const c_char,
}

#[derive(Debug)]
pub struct ScanResult {
    pub pattern_name: String,
    pub severity: i32,
    pub position: usize,
    pub matched_text: String,
}

impl SecurityScanner {
    /// Create new scanner with externally-provided patterns
    /// 
    /// # Safety
    /// patterns must be valid for the lifetime of the scanner
    pub unsafe fn new(patterns: *const Pattern, count: usize) -> Self {
        let buffer = libc::malloc(4096) as *mut u8;
        
        Self {
            patterns,
            pattern_count: count,
            buffer,
            buffer_capacity: 4096,
        }
    }

    /// Scan content for secrets
    pub fn scan(&mut self, content: &[u8]) -> Vec<ScanResult> {
        let mut results = Vec::new();
        
        // Resize buffer if needed
        if content.len() > self.buffer_capacity {
            // BUG 1: Potential memory leak - old buffer not freed
            self.buffer = unsafe {
                libc::realloc(self.buffer as *mut _, content.len()) as *mut u8
            };
            self.buffer_capacity = content.len();
        }
        
        // Copy content to buffer
        unsafe {
            ptr::copy_nonoverlapping(
                content.as_ptr(),
                self.buffer,
                content.len()
            );
        }
        
        // Scan with each pattern
        for i in 0..self.pattern_count {
            let pattern = unsafe { &*self.patterns.add(i) };
            
            // BUG 2: No null check before dereferencing
            let regex_str = unsafe {
                CStr::from_ptr(pattern.regex_ptr)
                    .to_string_lossy()
                    .into_owned()
            };
            
            // BUG 3: Creating slice from raw pointer without length validation
            let buffer_slice = unsafe {
                slice::from_raw_parts(self.buffer, self.buffer_capacity)
            };
            
            // Simulate pattern matching
            if let Some(pos) = self.find_pattern(buffer_slice, &regex_str) {
                // BUG 4: Unbounded string creation - potential panic
                let matched = unsafe {
                    let start = self.buffer.add(pos);
                    let len = regex_str.len().min(100);
                    let slice = slice::from_raw_parts(start, len);
                    String::from_utf8_unchecked(slice.to_vec())
                };
                
                results.push(ScanResult {
                    pattern_name: unsafe {
                        CStr::from_ptr(pattern.name)
                            .to_string_lossy()
                            .into_owned()
                    },
                    severity: pattern.severity,
                    position: pos,
                    matched_text: matched,
                });
            }
        }
        
        results
    }

    fn find_pattern(&self, content: &[u8], pattern: &str) -> Option<usize> {
        // Simplified pattern matching
        content.windows(pattern.len())
            .position(|window| window == pattern.as_bytes())
    }

    /// Get raw buffer pointer (for FFI)
    pub fn buffer_ptr(&self) -> *const u8 {
        self.buffer
    }

    /// Set buffer capacity directly (for performance tuning)
    /// 
    /// # Safety
    /// Caller must ensure buffer is properly allocated
    pub unsafe fn set_capacity(&mut self, new_capacity: usize) {
        // BUG 5: No synchronization, can race with scan()
        self.buffer_capacity = new_capacity;
    }
}

impl Drop for SecurityScanner {
    fn drop(&mut self) {
        unsafe {
            // BUG 6: Double-free risk if buffer was reallocated
            libc::free(self.buffer as *mut _);
            
            // BUG 7: patterns is not owned by us, but we're not documenting this
        }
    }
}

/// FFI-exported function for C integration
/// 
/// # Safety
/// All pointers must be valid
#[no_mangle]
pub unsafe extern "C" fn scanner_create(
    patterns: *const Pattern,
    count: c_int,
) -> *mut SecurityScanner {
    // BUG 8: No validation of count parameter
    let scanner = SecurityScanner::new(patterns, count as usize);
    
    // BUG 9: Leaking Box - no corresponding free function provided
    Box::into_raw(Box::new(scanner))
}

/// Export scan results to C
/// 
/// # Safety
/// scanner must be valid, results_out must point to valid memory
#[no_mangle]
pub unsafe extern "C" fn scanner_scan(
    scanner: *mut SecurityScanner,
    content: *const c_char,
    results_out: *mut *mut ScanResult,
    count_out: *mut c_int,
) -> c_int {
    // BUG 10: No null checks
    let scanner = &mut *scanner;
    let content_str = CStr::from_ptr(content).to_bytes();
    
    let results = scanner.scan(content_str);
    
    // BUG 11: Memory leak - results allocated but never freed
    let results_ptr = libc::malloc(
        results.len() * mem::size_of::<ScanResult>()
    ) as *mut ScanResult;
    
    ptr::copy_nonoverlapping(
        results.as_ptr(),
        results_ptr,
        results.len()
    );
    
    *results_out = results_ptr;
    *count_out = results.len() as c_int;
    
    0 // success
}

/// Thread-local scanner storage
thread_local! {
    static THREAD_SCANNER: *mut SecurityScanner = ptr::null_mut();
}

/// Set thread-local scanner
/// 
/// # Safety
/// scanner must be valid for the lifetime of the thread
pub unsafe fn set_thread_scanner(scanner: *mut SecurityScanner) {
    // BUG 12: No synchronization, data race on thread-local
    THREAD_SCANNER.with(|s| {
        *s = scanner;
    });
}

/// Get thread-local scanner
pub fn get_thread_scanner() -> Option<*mut SecurityScanner> {
    unsafe {
        THREAD_SCANNER.with(|s| {
            if s.is_null() {
                None
            } else {
                Some(*s)
            }
        })
    }
}
