use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::RwLock;
use std::collections::HashMap;

/// Monolithic token tracker with multiple responsibilities
pub struct TokenTracker {
    prompt_tokens: AtomicUsize,
    completion_tokens: AtomicUsize,
    api_calls: AtomicUsize,
    step_usage: RwLock<Vec<StepUsage>>,
    budget_limits: HashMap<String, usize>,
    cost_per_1k_prompt: f64,
    cost_per_1k_completion: f64,
    model_name: String,
}

#[derive(Clone, Debug)]
pub struct StepUsage {
    pub step: usize,
    pub prompt: usize,
    pub completion: usize,
    pub tool_name: Option<String>,
}

impl TokenTracker {
    pub fn new(model: &str) -> Self {
        let (prompt_cost, completion_cost) = match model {
            "gpt-4" => (0.03, 0.06),
            "gpt-3.5-turbo" => (0.0015, 0.002),
            "claude-3-opus" => (0.015, 0.075),
            _ => (0.001, 0.002),
        };

        Self {
            prompt_tokens: AtomicUsize::new(0),
            completion_tokens: AtomicUsize::new(0),
            api_calls: AtomicUsize::new(0),
            step_usage: RwLock::new(Vec::new()),
            budget_limits: HashMap::new(),
            cost_per_1k_prompt: prompt_cost,
            cost_per_1k_completion: completion_cost,
            model_name: model.to_string(),
        }
    }

    pub fn record_usage(&self, prompt: usize, completion: usize) {
        self.prompt_tokens.fetch_add(prompt, Ordering::Relaxed);
        self.completion_tokens.fetch_add(completion, Ordering::Relaxed);
        self.api_calls.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_step(&self, step: usize, prompt: usize, completion: usize, tool_name: Option<String>) {
        if let Ok(mut usage) = self.step_usage.write() {
            usage.push(StepUsage {
                step,
                prompt,
                completion,
                tool_name,
            });
        }
    }

    pub fn estimate_cost(&self) -> f64 {
        let prompt = self.prompt_tokens.load(Ordering::Relaxed) as f64;
        let completion = self.completion_tokens.load(Ordering::Relaxed) as f64;
        
        (prompt / 1000.0) * self.cost_per_1k_prompt +
        (completion / 1000.0) * self.cost_per_1k_completion
    }

    pub fn check_budget(&self, budget_name: &str) -> bool {
        let limit = self.budget_limits.get(budget_name).copied().unwrap_or(usize::MAX);
        let total = self.prompt_tokens.load(Ordering::Relaxed) +
                    self.completion_tokens.load(Ordering::Relaxed);
        total < limit
    }

    pub fn summary(&self) -> TokenSummary {
        TokenSummary {
            prompt_tokens: self.prompt_tokens.load(Ordering::Relaxed),
            completion_tokens: self.completion_tokens.load(Ordering::Relaxed),
            total_tokens: self.total_tokens(),
            api_calls: self.api_calls.load(Ordering::Relaxed),
            estimated_cost: self.estimate_cost(),
        }
    }

    fn total_tokens(&self) -> usize {
        self.prompt_tokens.load(Ordering::Relaxed) +
        self.completion_tokens.load(Ordering::Relaxed)
    }
}

#[derive(Debug, Clone)]
pub struct TokenSummary {
    pub prompt_tokens: usize,
    pub completion_tokens: usize,
    pub total_tokens: usize,
    pub api_calls: usize,
    pub estimated_cost: f64,
}
