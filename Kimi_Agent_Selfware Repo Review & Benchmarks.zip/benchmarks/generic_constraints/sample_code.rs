use std::sync::{Arc, RwLock};
use std::collections::HashMap;
use serde::{Serialize, Deserialize};

/// Token-budget aware memory layer trait
pub trait MemoryLayer<B: BudgetPolicy>: Sized + Send + Sync {
    type Item: Clone + Serialize + for<'de> Deserialize<'de>;
    type Iterator<'a>: Iterator<Item = &'a Self::Item>
    where
        Self: 'a,
        Self::Item: 'a;

    fn budget_policy(&self) -> &B;
    fn iter<'a>(&'a self) -> Self::Iterator<'a>;
    fn estimate_tokens(item: &Self::Item) -> usize;
}

/// Budget allocation policy trait
pub trait BudgetPolicy: Clone + Send + Sync + 'static {
    fn max_tokens(&self) -> usize;
    fn allocate(&self, requested: usize) -> usize;
}

/// Hierarchical memory with three layers
pub struct HierarchicalMemory<W, E, S, B>
where
    W: MemoryLayer<B>,
    E: MemoryLayer<B, Item = W::Item>,
    S: MemoryLayer<B, Item = W::Item>,
    B: BudgetPolicy,
{
    working: W,
    episodic: Arc<RwLock<E>>,
    semantic: Arc<RwLock<S>>,
    budget: B,
    token_usage: HashMap<String, usize>,
}

impl<W, E, S, B> HierarchicalMemory<W, E, S, B>
where
    W: MemoryLayer<B>,
    E: MemoryLayer<B, Item = W::Item>,
    S: MemoryLayer<B, Item = W::Item>,
    B: BudgetPolicy,
{
    pub fn new(working: W, episodic: E, semantic: S, budget: B) -> Self {
        Self {
            working,
            episodic: Arc::new(RwLock::new(episodic)),
            semantic: Arc::new(RwLock::new(semantic)),
            budget,
            token_usage: HashMap::new(),
        }
    }

    /// Transfer items from working to episodic memory
    pub fn consolidate(&mut self) -> Result<usize, MemoryError> {
        let mut transferred = 0;
        let mut tokens = 0;

        for item in self.working.iter() {
            let item_tokens = W::estimate_tokens(item);
            if tokens + item_tokens > self.budget.allocate(tokens + item_tokens) {
                break;
            }
            
            // Attempt to write to episodic memory
            let mut episodic = self.episodic.write().map_err(|_| MemoryError::LockPoisoned)?;
            
            // BUG: This doesn't actually insert - trait doesn't have insert method!
            tokens += item_tokens;
            transferred += 1;
        }

        Ok(transferred)
    }
}

#[derive(Debug)]
pub enum MemoryError {
    LockPoisoned,
    BudgetExceeded,
    SerializationFailed,
}

// Concrete implementations
#[derive(Clone)]
pub struct FixedBudget {
    max: usize,
}

impl BudgetPolicy for FixedBudget {
    fn max_tokens(&self) -> usize {
        self.max
    }
    
    fn allocate(&self, requested: usize) -> usize {
        requested.min(self.max)
    }
}

pub struct WorkingMemoryLayer<T, B> {
    items: Vec<T>,
    budget: B,
}

impl<T, B> MemoryLayer<B> for WorkingMemoryLayer<T, B>
where
    T: Clone + Serialize + for<'de> Deserialize<'de> + Send + Sync,
    B: BudgetPolicy,
{
    type Item = T;
    type Iterator<'a> = std::slice::Iter<'a, T>
    where
        T: 'a;

    fn budget_policy(&self) -> &B {
        &self.budget
    }

    fn iter<'a>(&'a self) -> Self::Iterator<'a> {
        self.items.iter()
    }

    fn estimate_tokens(item: &T) -> usize {
        // Simplified estimation
        std::mem::size_of_val(item) / 4
    }
}
