# Advanced Rust Code Understanding Benchmarks

## For Visual Language Models (Qwen3.5 Testing)

This benchmark suite tests expert-level Rust code comprehension, architectural design, and debugging skills. Each benchmark is designed for localhost testing against Qwen3.5 models.

---

## Quick Start

### Prerequisites

```bash
# Rust toolchain
rustup default stable
rustup component add clippy rustfmt

# Local LLM endpoint (e.g., vLLM, Ollama, llama.cpp)
# Should be running on localhost:8080 or similar
```

### Running Benchmarks

```bash
# 1. Start your local LLM server
# Example with vLLM:
# python -m vllm.entrypoints.openai.api_server \
#   --model Qwen/Qwen3.5-Coder-32B \
#   --port 8080

# 2. Run a specific benchmark
cargo run --bin benchmark -- generic_constraints

# 3. Evaluate results
cargo run --bin evaluate

# 4. Run all benchmarks
./run_all_benchmarks.sh
```

---

## Benchmark Overview

| # | Benchmark | Difficulty | Focus Area | Time Estimate |
|---|-----------|------------|------------|---------------|
| 1 | Generic Constraints | 9/10 | Type System | 30-45 min |
| 2 | Architectural Improvements | 8/10 | Design Patterns | 45-60 min |
| 3 | Complex Patterns | 9/10 | Async/Concurrency | 60-90 min |
| 4 | Unsafe Bug Detection | 10/10 | Memory Safety | 45-60 min |
| 5 | Macro Design | 9/10 | Metaprogramming | 60-90 min |

---

## Benchmark 1: Generic Constraint Analysis

**File:** `generic_constraints/sample_code.rs`

### Description
Analyze a complex generic system with multiple trait bounds, associated types, and lifetime constraints. Identify constraint violations, suggest improvements, and explain type system interactions.

### Key Concepts Tested
- Generic Associated Types (GATs)
- Lifetime constraints
- Trait bound reasoning
- Variance analysis

### Questions
1. Identify all trait bounds and explain necessity
2. Explain lifetime constraints on GATs
3. Find the design flaw in `consolidate()`
4. Rewrite GAT with simpler approach
5. Analyze variance of all type parameters

### Evaluation
```bash
cat generic_constraints/sample_code.rs | \
  curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d @- > results/generic_constraints-response.json
```

---

## Benchmark 2: Architectural Improvements

**File:** `architectural_improvements/sample_code.rs`

### Description
Analyze a token budget management system and propose architectural improvements. The current implementation has coupling, extensibility, and testing issues.

### Key Concepts Tested
- Single Responsibility Principle (SRP)
- Open/Closed Principle (OCP)
- Design patterns (Strategy, Observer, Builder)
- Testability improvements

### Tasks
1. Identify 5+ architectural issues
2. Propose new architecture with patterns
3. Implement refactored code
4. Design migration strategy
5. Show testing improvements

### Evaluation
```bash
cat architectural_improvements/sample_code.rs | \
  curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d @- > results/architectural_improvements-response.json
```

---

## Benchmark 3: Complex Pattern Implementation

**File:** `complex_patterns/sample_code.rs`

### Description
Implement a robust agent state machine using the Actor pattern with message passing. Handle concurrent state transitions, backpressure, and graceful shutdown.

### Key Concepts Tested
- Actor pattern
- State machines
- Async/await
- Backpressure handling
- Graceful shutdown

### Tasks
1. Implement state transition validation
2. Complete Actor message processing
3. Handle concurrent tool execution
4. Implement queue limits
5. Ensure graceful shutdown

### Evaluation
```bash
# This benchmark requires code implementation
cargo test --test complex_patterns
```

---

## Benchmark 4: Unsafe Bug Detection

**File:** `unsafe_bugs/sample_code.rs`

### Description
Analyze unsafe Rust code and identify all memory safety issues, undefined behavior risks, and logic bugs. Explain each issue and provide fixes.

### Key Concepts Tested
- Unsafe Rust safety rules
- Memory safety violations
- Undefined behavior identification
- FFI safety
- Safe abstraction design

### Bugs to Find (12+)
1. Memory leak in buffer reallocation
2. Null pointer dereference
3. Invalid slice creation
4. Unbounded string operations
5. Race condition on capacity
6. Double-free risk
7. Ownership documentation missing
8. Invalid count parameter
9. Memory leak in FFI
10. Missing null checks
11. Memory leak in results
12. Data race on thread-local

### Evaluation
```bash
cat unsafe_bugs/sample_code.rs | \
  curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d @- > results/unsafe_bugs-response.json
```

---

## Benchmark 5: Macro & Procedural Macro Design

**File:** `macros/sample_code.rs`

### Description
Design and implement declarative and procedural macros for the cognitive system. Create macros that reduce boilerplate for state management and memory operations.

### Key Concepts Tested
- Declarative macros (macro_rules!)
- Procedural macros (proc_macro)
- Derive macros
- Attribute macros
- Code generation

### Tasks
1. Implement `cognitive_state!`, `memory_layer!`, `pdvr_transition!` macros
2. Create `#[derive(CognitiveState)]` proc-macro
3. Create `#[derive(MemoryBudget)]` proc-macro
4. Create `#[pdvr_cycle]` attribute macro
5. Show before/after boilerplate reduction

### Evaluation
```bash
# This benchmark requires proc-macro implementation
cargo test --test macros
```

---

## Scoring Rubric

### Individual Benchmark Scoring

| Grade | Score Range | Description |
|-------|-------------|-------------|
| Expert | 90-100 | Deep understanding, production-ready solutions |
| Proficient | 80-89 | Good understanding, minor gaps |
| Competent | 70-79 | Basic understanding, some misconceptions |
| Developing | 60-69 | Significant gaps in understanding |
| Novice | <60 | Fundamental misunderstandings |

### Overall Assessment

| Overall Score | Assessment |
|---------------|------------|
| 450-500 | Expert Rust developer - Can architect complex systems |
| 400-449 | Advanced Rust developer - Strong in most areas |
| 350-399 | Intermediate Rust developer - Good foundation |
| 300-349 | Developing Rust developer - Needs more practice |
| <300 | Beginner Rust developer - Focus on fundamentals |

---

## Directory Structure

```
benchmarks/
├── README.md                          # This file
├── evaluate.rs                        # Evaluation script
├── generic_constraints/
│   ├── sample_code.rs                 # Code to analyze
│   └── rubric.json                    # Scoring criteria
├── architectural_improvements/
│   ├── sample_code.rs
│   └── rubric.json
├── complex_patterns/
│   ├── sample_code.rs
│   └── rubric.json
├── unsafe_bugs/
│   ├── sample_code.rs
│   └── rubric.json
├── macros/
│   ├── sample_code.rs
│   └── rubric.json
└── results/                           # Store model responses here
```

---

## Model Configuration

### For Qwen3.5 Testing

```toml
# selfware.toml or similar config
[api]
endpoint = "http://localhost:8080/v1"
model = "Qwen/Qwen3.5-Coder-32B"
max_tokens = 32768
temperature = 0.2  # Lower for consistent results
top_p = 0.9

[benchmark]
system_prompt = """
You are an expert Rust developer analyzing code for a benchmark.
Provide detailed, accurate responses with code examples where appropriate.
Focus on correctness, safety, and idiomatic Rust patterns.
"""
```

### Prompt Template

```json
{
  "model": "Qwen/Qwen3.5-Coder-32B",
  "messages": [
    {
      "role": "system",
      "content": "You are an expert Rust developer..."
    },
    {
      "role": "user",
      "content": "Analyze the following Rust code and answer the questions...\n\n```rust\n[CODE]\n```\n\nQuestions:..."
    }
  ],
  "temperature": 0.2,
  "max_tokens": 32768
}
```

---

## Tips for Evaluators

1. **Consistency**: Use the same model configuration across all benchmarks
2. **Temperature**: Lower temperature (0.2) for more consistent results
3. **Time Limits**: Set reasonable time limits for each benchmark
4. **Multiple Runs**: Consider running each benchmark 3x and averaging scores
5. **Manual Review**: Automated evaluation is a guide; manual review for edge cases

---

## Extending the Benchmarks

To add a new benchmark:

1. Create a new directory under `benchmarks/`
2. Add `sample_code.rs` with the code to analyze
3. Add `rubric.json` with scoring criteria
4. Update this README with benchmark description
5. Add evaluation logic to `evaluate.rs`

---

## License

MIT License - See LICENSE file for details

---

## References

- [Selfware Repository](https://github.com/architehc/selfware)
- [Rust Book - Advanced Topics](https://doc.rust-lang.org/book/ch19-00-advanced-features.html)
- [Rustonomicon - Unsafe Rust](https://doc.rust-lang.org/nomicon/)
- [Proc Macro Workshop](https://github.com/dtolnay/proc-macro-workshop)
