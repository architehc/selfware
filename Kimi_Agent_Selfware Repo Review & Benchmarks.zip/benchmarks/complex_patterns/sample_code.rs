use std::collections::VecDeque;
use std::sync::Arc;
use tokio::sync::{mpsc, oneshot, RwLock};
use anyhow::Result;

/// Tool execution result
#[derive(Debug, Clone)]
pub struct ToolResult {
    pub tool_name: String,
    pub success: bool,
    pub output: String,
    pub execution_time_ms: u64,
}

/// Tool to be executed
#[derive(Debug, Clone)]
pub struct ToolCall {
    pub id: String,
    pub name: String,
    pub arguments: serde_json::Value,
}

/// Messages that can be sent to the agent actor
#[derive(Debug)]
pub enum AgentMessage {
    /// Start processing a new task
    StartTask { task: String, respond_to: oneshot::Sender<TaskId> },
    /// Execute a tool
    ExecuteTool { call: ToolCall, respond_to: oneshot::Sender<Result<ToolResult>> },
    /// Get current state
    GetState { respond_to: oneshot::Sender<AgentState> },
    /// Pause execution
    Pause { respond_to: oneshot::Sender<Result<()>> },
    /// Resume execution
    Resume { respond_to: oneshot::Sender<Result<()>> },
    /// Graceful shutdown
    Shutdown { respond_to: oneshot::Sender<Result<()>> },
    /// Cancel current task
    CancelTask { task_id: TaskId, respond_to: oneshot::Sender<Result<()>> },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct TaskId(pub u64);

/// Agent states following PDVR cycle
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AgentState {
    Idle,
    Planning,
    Executing,
    Verifying,
    Reflecting,
    Paused,
    ShuttingDown,
    Error,
}

/// Actor handle for external interaction
#[derive(Debug, Clone)]
pub struct AgentHandle {
    sender: mpsc::Sender<AgentMessage>,
}

impl AgentHandle {
    pub async fn start_task(&self, task: String) -> Result<TaskId> {
        let (tx, rx) = oneshot::channel();
        self.sender.send(AgentMessage::StartTask { task, respond_to: tx }).await?;
        Ok(rx.await?)
    }

    pub async fn execute_tool(&self, call: ToolCall) -> Result<ToolResult> {
        let (tx, rx) = oneshot::channel();
        self.sender.send(AgentMessage::ExecuteTool { call, respond_to: tx }).await?;
        rx.await?
    }

    pub async fn get_state(&self) -> Result<AgentState> {
        let (tx, rx) = oneshot::channel();
        self.sender.send(AgentMessage::GetState { respond_to: tx }).await?;
        Ok(rx.await?)
    }

    pub async fn shutdown(&self) -> Result<()> {
        let (tx, rx) = oneshot::channel();
        self.sender.send(AgentMessage::Shutdown { respond_to: tx }).await?;
        rx.await?
    }
}

// IMPLEMENTATION TASK: Complete the Actor system below

/// State machine for valid transitions
pub struct StateMachine {
    current: AgentState,
}

impl StateMachine {
    pub fn new() -> Self {
        Self { current: AgentState::Idle }
    }

    pub fn can_transition(&self, to: AgentState) -> bool {
        // TODO: Implement valid transition logic
        // Valid transitions:
        // Idle -> Planning
        // Planning -> Do
        // Do -> Verify
        // Verify -> Reflect
        // Reflect -> Plan OR Reflect -> Do (short-circuit)
        // Any -> Paused
        // Paused -> previous state
        // Any -> ShuttingDown
        true
    }

    pub fn transition(&mut self, to: AgentState) -> Result<()> {
        if self.can_transition(to) {
            self.current = to;
            Ok(())
        } else {
            Err(anyhow::anyhow!("Invalid state transition"))
        }
    }
}

/// Agent actor implementation
pub struct AgentActor {
    state: StateMachine,
    mailbox: mpsc::Receiver<AgentMessage>,
    current_task: Option<TaskId>,
    task_counter: u64,
}

impl AgentActor {
    pub fn new(mailbox_size: usize) -> (Self, AgentHandle) {
        let (tx, rx) = mpsc::channel(mailbox_size);
        let actor = Self {
            state: StateMachine::new(),
            mailbox: rx,
            current_task: None,
            task_counter: 0,
        };
        let handle = AgentHandle { sender: tx };
        (actor, handle)
    }

    pub async fn run(mut self) {
        // TODO: Implement message processing loop
        // - Handle all message types
        // - Manage state transitions
        // - Handle concurrent tool execution
        // - Implement graceful shutdown
    }
}
