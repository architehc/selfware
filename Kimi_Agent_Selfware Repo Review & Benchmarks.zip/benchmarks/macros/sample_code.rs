use serde::{Serialize, Deserialize};

/// Current manual implementation - lots of boilerplate!
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CognitiveState {
    pub cycle_phase: CyclePhase,
    pub working_memory: WorkingMemory,
    pub episodic_memory: EpisodicMemory,
    pub strategic_goals: Vec<StrategicGoal>,
    pub iteration_count: u32,
}

impl CognitiveState {
    pub fn new() -> Self {
        Self {
            cycle_phase: CyclePhase::Plan,
            working_memory: WorkingMemory::default(),
            episodic_memory: EpisodicMemory::default(),
            strategic_goals: Vec::new(),
            iteration_count: 0,
        }
    }

    pub fn transition_to(&mut self, new_phase: CyclePhase) -> Result<(), StateError> {
        let valid = match (&self.cycle_phase, &new_phase) {
            (CyclePhase::Plan, CyclePhase::Do) => true,
            (CyclePhase::Do, CyclePhase::Verify) => true,
            (CyclePhase::Verify, CyclePhase::Reflect) => true,
            (CyclePhase::Reflect, CyclePhase::Plan) => true,
            (CyclePhase::Reflect, CyclePhase::Do) => true,
            _ => false,
        };
        
        if valid {
            self.cycle_phase = new_phase;
            self.iteration_count += 1;
            Ok(())
        } else {
            Err(StateError::InvalidTransition)
        }
    }
}

impl Default for CognitiveState {
    fn default() -> Self {
        Self::new()
    }
}

// Manual token estimation - repetitive!
pub trait TokenEstimable {
    fn estimate_tokens(&self) -> usize;
}

impl TokenEstimable for CognitiveState {
    fn estimate_tokens(&self) -> usize {
        let mut total = 0;
        total += self.cycle_phase.estimate_tokens();
        total += self.working_memory.estimate_tokens();
        total += self.episodic_memory.estimate_tokens();
        for goal in &self.strategic_goals {
            total += goal.estimate_tokens();
        }
        total += 4; // iteration_count
        total
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum CyclePhase {
    Plan,
    Do,
    Verify,
    Reflect,
}

impl TokenEstimable for CyclePhase {
    fn estimate_tokens(&self) -> usize {
        match self {
            CyclePhase::Plan => 1,
            CyclePhase::Do => 1,
            CyclePhase::Verify => 1,
            CyclePhase::Reflect => 1,
        }
    }
}

#[derive(Debug)]
pub enum StateError {
    InvalidTransition,
}

// More boilerplate for WorkingMemory, EpisodicMemory, etc.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct WorkingMemory {
    pub context: String,
    pub hypotheses: Vec<String>,
}

impl TokenEstimable for WorkingMemory {
    fn estimate_tokens(&self) -> usize {
        self.context.len() / 4 + self.hypotheses.iter().map(|h| h.len() / 4).sum::<usize>()
    }
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct EpisodicMemory {
    pub episodes: Vec<Episode>,
}

impl TokenEstimable for EpisodicMemory {
    fn estimate_tokens(&self) -> usize {
        self.episodes.len() * 10
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Episode {
    pub content: String,
    pub timestamp: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StrategicGoal {
    pub description: String,
    pub priority: u8,
}

impl TokenEstimable for StrategicGoal {
    fn estimate_tokens(&self) -> usize {
        self.description.len() / 4 + 1
    }
}

// TASK: Create macros to reduce this boilerplate!
// 
// Desired usage after macros:
//
// #[derive(CognitiveState)]
// #[pdvr_cycle]
// pub struct CognitiveState {
//     pub cycle_phase: CyclePhase,
//     pub working_memory: WorkingMemory,
//     pub episodic_memory: EpisodicMemory,
//     #[token_weight = 4]
//     pub iteration_count: u32,
// }
//
// #[derive(MemoryBudget)]
// pub struct WorkingMemory {
//     pub context: String,
//     pub hypotheses: Vec<String>,
// }
