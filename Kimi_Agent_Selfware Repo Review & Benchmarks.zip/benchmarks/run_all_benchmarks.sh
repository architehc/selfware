#!/bin/bash
# Run all advanced Rust benchmarks against local LLM

set -e

# Configuration
LLM_ENDPOINT="${LLM_ENDPOINT:-http://localhost:8080/v1}"
MODEL="${MODEL:-Qwen/Qwen3.5-Coder-32B}"
RESULTS_DIR="results"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Create results directory
mkdir -p "$RESULTS_DIR"

echo "=========================================="
echo "Advanced Rust Benchmark Suite"
echo "=========================================="
echo "Model: $MODEL"
echo "Endpoint: $LLM_ENDPOINT"
echo "Timestamp: $TIMESTAMP"
echo ""

# Check if LLM endpoint is available
if ! curl -s "$LLM_ENDPOINT/models" > /dev/null 2>&1; then
    echo "ERROR: LLM endpoint not available at $LLM_ENDPOINT"
    echo "Please start your local LLM server first."
    exit 1
fi

echo "LLM endpoint is available."
echo ""

# Function to run a benchmark
run_benchmark() {
    local name=$1
    local code_file=$2
    local questions_file=$3
    
    echo "Running benchmark: $name"
    echo "  Code file: $code_file"
    
    # Read the code
    if [ ! -f "$code_file" ]; then
        echo "  ERROR: Code file not found: $code_file"
        return 1
    fi
    
    CODE=$(cat "$code_file")
    
    # Create prompt
    cat > "$RESULTS_DIR/${name}_prompt.json" << EOF
{
  "model": "$MODEL",
  "messages": [
    {
      "role": "system",
      "content": "You are an expert Rust developer participating in a code analysis benchmark. Provide detailed, accurate responses with code examples where appropriate. Focus on correctness, safety, and idiomatic Rust patterns."
    },
    {
      "role": "user",
      "content": "Please analyze the following Rust code and answer the questions that follow.\n\n\`\`\`rust\n$CODE\n\`\`\`\n\n$(cat "$questions_file" 2>/dev/null || echo "Analyze this code for issues, improvements, and explain key concepts.")"
    }
  ],
  "temperature": 0.2,
  "max_tokens": 32768
}
EOF
    
    # Send to LLM
    echo "  Sending to LLM..."
    curl -s -X POST "$LLM_ENDPOINT/chat/completions" \
        -H "Content-Type: application/json" \
        -d @"$RESULTS_DIR/${name}_prompt.json" \
        > "$RESULTS_DIR/${name}_response_${TIMESTAMP}.json"
    
    if [ $? -eq 0 ]; then
        echo "  ✓ Completed: $RESULTS_DIR/${name}_response_${TIMESTAMP}.json"
    else
        echo "  ✗ Failed to get response"
        return 1
    fi
    
    echo ""
}

# Run each benchmark
run_benchmark "generic_constraints" \
    "generic_constraints/sample_code.rs" \
    "generic_constraints/questions.txt"

run_benchmark "architectural_improvements" \
    "architectural_improvements/sample_code.rs" \
    "architectural_improvements/questions.txt"

run_benchmark "unsafe_bugs" \
    "unsafe_bugs/sample_code.rs" \
    "unsafe_bugs/questions.txt"

# Note: complex_patterns and macros require implementation, not just analysis
echo "Note: complex_patterns and macros benchmarks require code implementation."
echo "These should be evaluated manually or with cargo test."
echo ""

# Generate summary report
echo "=========================================="
echo "Benchmark Run Complete"
echo "=========================================="
echo "Results saved to: $RESULTS_DIR/"
echo ""
echo "Files generated:"
ls -la "$RESULTS_DIR/"*"_${TIMESTAMP}.json" 2>/dev/null || echo "  No response files found"
echo ""
echo "Next steps:"
echo "  1. Review responses in $RESULTS_DIR/"
echo "  2. Run evaluation: cargo run --bin evaluate"
echo "  3. For implementation benchmarks:"
echo "     - complex_patterns: cargo test --test complex_patterns"
echo "     - macros: cargo test --test macros"
