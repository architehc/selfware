# Visual Language Model Benchmarks for Rust Code Understanding

## Overview

This document contains 5 practical, real-world benchmarks designed to test visual language models' ability to understand, analyze, and work with Rust code. These benchmarks are based on the selfware repository analysis and are suitable for localhost testing against Qwen3.5 models.

**Target Model**: Qwen3.5 (32B or larger variants)  
**Test Environment**: Localhost with vLLM or similar inference engine  
**Evaluation Method**: Automated scoring with human verification option

---

## Benchmark 1: PR Review and Issue Identification

### Task Name
`pr_code_review`

### Description
Test the model's ability to review a pull request diff and identify potential issues, bugs, security vulnerabilities, and code quality problems.

### Real-World Context
Code review is a critical part of Rust development. This benchmark simulates reviewing a PR that introduces changes to the token counting and context management system.

### Input: PR Diff

```diff
diff --git a/src/token_count.rs b/src/token_count.rs
index 1234567..abcdefg 100644
--- a/src/token_count.rs
+++ b/src/token_count.rs
@@ -15,7 +15,7 @@ use tracing::{debug, warn};
 const MAX_CACHE_ENTRIES: usize = 1_000;
 
 // Try to load Qwen tokenizer, fallback to OpenAI cl100k.
-static TOKENIZER: Lazy<TokenizerState> = Lazy::new(TokenizerState::new);
+static TOKENIZER: Lazy<TokenizerState> = Lazy::new(|| TokenizerState::new());
 
 /// Thread-safe cache mapping content hash (u64) -> token count.
 static TOKEN_CACHE: Lazy<RwLock<HashMap<u64, usize>>> =
@@ -60,7 +60,7 @@ impl TokenizerState {
     fn count(&self, content: &str) -> usize {
         match self {
             TokenizerState::Qwen(t) => t
-                .encode(content, false)
+                .encode(content, true)
                 .map(|e| e.get_tokens().len())
                 .unwrap_or_else(|_| heuristic_estimate(content)),
             TokenizerState::Tiktoken(bpe) => bpe.encode_with_special_tokens(content).len(),
@@ -82,10 +82,12 @@ pub fn estimate_content_tokens(content: &str) -> usize {
 
     // Fast path: check the read-locked cache first.
     if let Ok(cache) = TOKEN_CACHE.read() {
-        if let Some(&count) = cache.get(&key) {
-            return count;
+        if let Some(count) = cache.get(&key) {
+            return *count;
         }
     }
+    
+    std::thread::sleep(std::time::Duration::from_millis(10));
 
     // Cache miss — compute the token count.
     let count = TOKENIZER.count(content);
@@ -114,7 +116,7 @@ fn hash_content(content: &str) -> u64 {
 fn heuristic_estimate(content: &str) -> usize {
     // Heuristic fallback that remains biased toward overestimation for safety.
     let factor = if content.contains('{') || content.contains(';') {
-        3
+        2
     } else {
         4
     };

diff --git a/src/agent/context.rs b/src/agent/context.rs
index 2345678..bcdefgh 100644
--- a/src/agent/context.rs
+++ b/src/agent/context.rs
@@ -45,7 +45,7 @@ impl ContextCompressor {
     pub fn estimate_tokens(&self, messages: &[Message]) -> usize {
         messages
             .iter()
-            .map(|m| estimate_tokens_with_overhead(m.content.text(), 50))
+            .map(|m| estimate_tokens_with_overhead(m.content.text(), 20))
             .sum()
     }
 
@@ -87,7 +87,7 @@ impl ContextCompressor {
 
         let response = tokio::time::timeout(
             std::time::Duration::from_secs(120),
-            client.chat(summary_request, None, ThinkingMode::Disabled),
+            client.chat(summary_request, None, ThinkingMode::Enabled),
         )
         .await
         .map_err(|_| anyhow::anyhow!("Context compression API call timed out after 120s"))??;
@@ -130,7 +130,7 @@ impl ContextCompressor {
     pub fn hard_compress(&self, messages: &[Message]) -> Vec<Message> {
         let mut result = Vec::new();
         if let Some(first) = messages.first() {
-            result.push(first.clone()); // System
+            result.push(first.clone());
         }
 
         // Add a note about compression
@@ -140,7 +140,7 @@ impl ContextCompressor {
 
         // Keep only last few messages (must end with user for next assistant response)
         let start = messages.len().saturating_sub(3);
-        for msg in &messages[start..] {
+        for msg in messages.iter().skip(start) {
             // Skip if this would create consecutive assistants
             if let Some(last) = result.last() {
                 if last.role == "assistant" && msg.role == "assistant" {
```

### Specific Deliverables Expected

The model should identify and categorize issues found in the diff:

1. **Performance Issues**: Unnecessary sleep in hot path
2. **Logic Errors**: Changed token encoding parameter, heuristic factor change
3. **Best Practice Violations**: Comment removal, unnecessary closure
4. **Potential Bugs**: Overhead reduction may cause issues

### Expected Output Format

```json
{
  "issues_found": [
    {
      "file": "src/token_count.rs",
      "line": 90,
      "severity": "high",
      "category": "performance",
      "description": "Added std::thread::sleep in token estimation hot path",
      "impact": "Every token estimation call now has 10ms latency, causing severe performance degradation",
      "suggestion": "Remove the sleep call - it appears to be debugging code that was accidentally committed"
    },
    {
      "file": "src/token_count.rs",
      "line": 63,
      "severity": "medium",
      "category": "logic",
      "description": "Changed encode() second parameter from false to true",
      "impact": "Adding special tokens may inflate token counts and affect context window calculations",
      "suggestion": "Verify this change is intentional; document why special tokens should be counted"
    },
    {
      "file": "src/token_count.rs",
      "line": 119,
      "severity": "medium",
      "category": "logic",
      "description": "Changed heuristic factor from 3 to 2 for code content",
      "impact": "Token estimates will be ~33% higher, potentially causing premature context compression",
      "suggestion": "Revert to factor 3 or document the rationale for this change"
    },
    {
      "file": "src/agent/context.rs",
      "line": 48,
      "severity": "low",
      "category": "best_practice",
      "description": "Reduced message overhead from 50 to 20 without explanation",
      "impact": "May cause token underestimation and context overflow",
      "suggestion": "Add comment explaining the rationale or keep original value"
    }
  ],
  "summary": {
    "total_issues": 4,
    "high_severity": 1,
    "medium_severity": 2,
    "low_severity": 1,
    "recommendation": "Request changes - the sleep call is a critical performance issue"
  }
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Critical Issue Detection | 30 | Identifies the sleep() performance bug |
| Logic Error Detection | 25 | Catches encode() parameter and heuristic changes |
| Severity Assessment | 20 | Correctly assigns severity levels |
| Actionable Suggestions | 15 | Provides specific, actionable fixes |
| False Positive Rate | 10 | Minimal incorrect issue reports |

**Scoring**:
- 90-100: Excellent - All critical issues found with correct severity
- 70-89: Good - Most issues found, minor severity misclassifications
- 50-69: Fair - Some issues missed, some false positives
- <50: Poor - Major issues missed

### Difficulty Rating
**7/10**

Requires understanding of:
- Rust performance characteristics
- Tokenization concepts
- Async/sync interaction (sleep in potentially async context)
- Code review best practices

### Real-World Relevance
This directly mirrors the daily work of Rust developers reviewing PRs. The issues represent common mistakes: debugging code left in, unintended parameter changes, and performance regressions.

---

## Benchmark 2: Feature Addition to Existing Codebase

### Task Name
`feature_implementation`

### Description
Test the model's ability to add a new feature to an existing Rust codebase while maintaining code quality, following existing patterns, and integrating properly.

### Real-World Context
Adding rate limiting to the API client is a common production requirement. The model must understand the existing error handling, configuration, and async patterns.

### Input: Feature Request

**Task**: Add rate limiting support to the API client with the following requirements:

1. Implement token bucket rate limiting for API requests
2. Support configurable requests per minute (default: 60)
3. Add proper error handling with retry-after support
4. Integrate with existing `ApiError::RateLimit` error type
5. Add metrics tracking for rate limit hits
6. Follow existing code patterns in the codebase

### Context Files

**File 1: src/api/mod.rs (existing structure)**
```rust
use anyhow::Result;
use reqwest::Client;
use std::time::Duration;

use crate::api::types::{Message, ToolCall, ToolDefinition};
use crate::config::Config;

pub mod types;

pub struct ApiClient {
    client: Client,
    api_key: String,
    base_url: String,
    model: String,
}

impl ApiClient {
    pub fn new(config: &Config) -> Result<Self> {
        let client = Client::builder()
            .timeout(Duration::from_secs(300))
            .build()?;
            
        Ok(Self {
            client,
            api_key: config.api.key.clone(),
            base_url: config.api.base_url.clone(),
            model: config.api.model.clone(),
        })
    }
    
    pub async fn chat(
        &self,
        messages: Vec<Message>,
        tools: Option<Vec<ToolDefinition>>,
        thinking: ThinkingMode,
    ) -> Result<ChatResponse> {
        // Implementation
    }
}

pub enum ThinkingMode {
    Enabled,
    Disabled,
}
```

**File 2: src/api/types.rs (error types)**
```rust
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Message {
    pub role: String,
    pub content: MessageContent,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum MessageContent {
    Text(String),
    MultiContent(Vec<ContentPart>),
}

impl MessageContent {
    pub fn text(&self) -> &str {
        match self {
            MessageContent::Text(s) => s,
            MessageContent::MultiContent(parts) => {
                parts.iter()
                    .find_map(|p| match p {
                        ContentPart::Text { text } => Some(text.as_str()),
                        _ => None,
                    })
                    .unwrap_or("")
            }
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum ContentPart {
    #[serde(rename = "text")]
    Text { text: String },
    #[serde(rename = "image_url")]
    ImageUrl { image_url: ImageUrl },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImageUrl {
    pub url: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ChatResponse {
    pub choices: Vec<Choice>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Choice {
    pub message: Message,
}

#[derive(Debug, Clone, Serialize)]
pub struct ToolDefinition {
    pub name: String,
    pub description: String,
    pub parameters: serde_json::Value,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ToolCall {
    pub id: String,
    pub function: FunctionCall,
}

#[derive(Debug, Clone, Deserialize)]
pub struct FunctionCall {
    pub name: String,
    pub arguments: String,
}
```

**File 3: src/errors.rs (relevant error type)**
```rust
use thiserror::Error;

#[derive(Error, Debug)]
pub enum ApiError {
    #[error("API Request timed out")]
    Timeout,

    #[error("Rate limit exceeded. Retry after {retry_after_secs:?} seconds")]
    RateLimit { retry_after_secs: Option<u64> },

    #[error("Authentication failed: {0}")]
    Authentication(String),

    #[error("API returned status {status}: {message}")]
    HttpStatus { status: u16, message: String },

    #[error("Network error: {0}")]
    Network(String),
}
```

**File 4: src/config.rs (configuration pattern)**
```rust
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub api: ApiConfig,
    pub agent: AgentConfig,
    pub safety: SafetyConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiConfig {
    pub key: String,
    pub base_url: String,
    pub model: String,
    pub timeout_secs: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentConfig {
    pub max_iterations: usize,
    pub native_function_calling: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SafetyConfig {
    pub allowed_paths: Vec<String>,
    pub blocked_commands: Vec<String>,
}
```

### Specific Deliverables Expected

The model should provide:

1. **Implementation code** for the rate limiter following existing patterns
2. **Configuration updates** to support rate limiting settings
3. **Integration code** showing how to use it in ApiClient
4. **Test cases** demonstrating the functionality

### Expected Output Format

```rust
// src/api/rate_limiter.rs
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::Mutex;
use tracing::{debug, warn};

/// Token bucket rate limiter for API requests.
#[derive(Debug, Clone)]
pub struct RateLimiter {
    inner: Arc<Mutex<RateLimiterState>>,
    config: RateLimitConfig,
}

#[derive(Debug)]
struct RateLimiterState {
    tokens: f64,
    last_update: Instant,
    total_requests: u64,
    rate_limited_hits: u64,
}

#[derive(Debug, Clone)]
pub struct RateLimitConfig {
    /// Maximum requests per minute
    pub requests_per_minute: u32,
    /// Maximum burst size (default: same as rpm)
    pub burst_size: Option<u32>,
}

impl Default for RateLimitConfig {
    fn default() -> Self {
        Self {
            requests_per_minute: 60,
            burst_size: None,
        }
    }
}

impl RateLimiter {
    pub fn new(config: RateLimitConfig) -> Self {
        let burst = config.burst_size.unwrap_or(config.requests_per_minute);
        Self {
            inner: Arc::new(Mutex::new(RateLimiterState {
                tokens: burst as f64,
                last_update: Instant::now(),
                total_requests: 0,
                rate_limited_hits: 0,
            })),
            config,
        }
    }

    /// Attempt to acquire a token. Returns wait duration if rate limited.
    pub async fn acquire(&self) -> Result<(), RateLimitError> {
        let mut state = self.inner.lock().await;
        state.total_requests += 1;

        let now = Instant::now();
        let elapsed = now.duration_since(state.last_update).as_secs_f64();
        let rate_per_sec = self.config.requests_per_minute as f64 / 60.0;
        
        // Add tokens based on elapsed time
        let burst = self.config.burst_size.unwrap_or(self.config.requests_per_minute) as f64;
        state.tokens = (state.tokens + elapsed * rate_per_sec).min(burst);
        state.last_update = now;

        if state.tokens >= 1.0 {
            state.tokens -= 1.0;
            debug!("Rate limit token acquired, remaining: {:.2}", state.tokens);
            Ok(())
        } else {
            state.rate_limited_hits += 1;
            let wait_secs = ((1.0 - state.tokens) / rate_per_sec).ceil() as u64;
            warn!("Rate limit hit, retry after {}s", wait_secs);
            Err(RateLimitError::RetryAfter(Duration::from_secs(wait_secs)))
        }
    }

    /// Get current statistics
    pub async fn stats(&self) -> RateLimitStats {
        let state = self.inner.lock().await;
        RateLimitStats {
            total_requests: state.total_requests,
            rate_limited_hits: state.rate_limited_hits,
            current_tokens: state.tokens,
        }
    }
}

#[derive(Debug)]
pub enum RateLimitError {
    RetryAfter(Duration),
}

impl std::fmt::Display for RateLimitError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            RateLimitError::RetryAfter(d) => write!(f, "Rate limited, retry after {:?}", d),
        }
    }
}

impl std::error::Error for RateLimitError {}

#[derive(Debug, Clone, Copy)]
pub struct RateLimitStats {
    pub total_requests: u64,
    pub rate_limited_hits: u64,
    pub current_tokens: f64,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_rate_limiter_allows_initial_requests() {
        let limiter = RateLimiter::new(RateLimitConfig {
            requests_per_minute: 60,
            burst_size: Some(10),
        });

        for _ in 0..10 {
            assert!(limiter.acquire().await.is_ok());
        }
    }

    #[tokio::test]
    async fn test_rate_limiter_blocks_after_burst() {
        let limiter = RateLimiter::new(RateLimitConfig {
            requests_per_minute: 60,
            burst_size: Some(2),
        });

        assert!(limiter.acquire().await.is_ok());
        assert!(limiter.acquire().await.is_ok());
        assert!(limiter.acquire().await.is_err());
    }
}
```

```rust
// Updated src/api/mod.rs integration
use crate::api::rate_limiter::{RateLimiter, RateLimitConfig};

pub struct ApiClient {
    client: Client,
    api_key: String,
    base_url: String,
    model: String,
    rate_limiter: Option<RateLimiter>,
}

impl ApiClient {
    pub fn new(config: &Config) -> Result<Self> {
        let client = Client::builder()
            .timeout(Duration::from_secs(300))
            .build()?;
            
        let rate_limiter = config.api.rate_limit.map(|rpm| {
            RateLimiter::new(RateLimitConfig {
                requests_per_minute: rpm,
                burst_size: config.api.rate_limit_burst,
            })
        });
            
        Ok(Self {
            client,
            api_key: config.api.key.clone(),
            base_url: config.api.base_url.clone(),
            model: config.api.model.clone(),
            rate_limiter,
        })
    }
    
    pub async fn chat(
        &self,
        messages: Vec<Message>,
        tools: Option<Vec<ToolDefinition>>,
        thinking: ThinkingMode,
    ) -> Result<ChatResponse> {
        // Apply rate limiting if configured
        if let Some(ref limiter) = self.rate_limiter {
            if let Err(e) = limiter.acquire().await {
                return Err(ApiError::RateLimit {
                    retry_after_secs: Some(e.retry_after().as_secs()),
                }.into());
            }
        }
        
        // ... rest of implementation
    }
}
```

```rust
// Updated src/config.rs
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiConfig {
    pub key: String,
    pub base_url: String,
    pub model: String,
    pub timeout_secs: u64,
    /// Optional rate limit in requests per minute
    pub rate_limit: Option<u32>,
    /// Optional burst size for rate limiting (default: same as rate_limit)
    pub rate_limit_burst: Option<u32>,
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Correct Implementation | 30 | Token bucket algorithm correctly implemented |
| Pattern Consistency | 20 | Follows existing codebase patterns (Arc<Mutex>, tracing, etc.) |
| Integration Quality | 15 | Clean integration with ApiClient and error types |
| Configuration Support | 10 | Proper config structure with defaults |
| Test Coverage | 15 | Tests for key functionality |
| Documentation | 10 | Clear comments and documentation |

**Scoring**:
- 90-100: Excellent - Production-ready implementation
- 70-89: Good - Correct implementation with minor issues
- 50-69: Fair - Works but has design or integration issues
- <50: Poor - Significant issues or doesn't work

### Difficulty Rating
**8/10**

Requires understanding of:
- Token bucket algorithm
- Async Rust patterns (Arc<Mutex>, tokio)
- Error handling integration
- Configuration patterns
- Testing async code

### Real-World Relevance
Rate limiting is essential for production API clients. This tests the model's ability to implement a well-known algorithm while fitting into existing architectural patterns.

---

## Benchmark 3: Debugging with Logs and Stack Traces

### Task Name
`debugging_issue`

### Description
Test the model's ability to diagnose and fix a reported bug using logs, stack traces, and code context.

### Real-World Context
A user reports that the agent crashes during long-running tasks. The logs show a panic in the context compression system.

### Input: Bug Report

**Issue Title**: Agent panics during context compression on long conversations

**Description**:
When running long tasks (>50 iterations), the agent occasionally panics with a "already mutably borrowed" error. This seems to happen during context compression.

**Environment**:
- Rust version: 1.75.0
- selfware version: 0.9.2
- OS: Ubuntu 22.04

### Logs

```
[2024-01-15T14:23:45Z INFO  selfware::agent] Starting task: "Refactor the database module"
[2024-01-15T14:23:46Z INFO  selfware::agent::execution] Step 1: Planning phase
[2024-01-15T14:23:47Z INFO  selfware::agent::context] Context size: 1024 tokens
...
[2024-01-15T14:45:12Z INFO  selfware::agent::context] Context size: 98500 tokens, triggering compression
[2024-01-15T14:45:12Z WARN  selfware::agent::context] Compressing context: 512 messages
[2024-01-15T14:45:12Z DEBUG selfware::token_count] Estimated tokens: 98500
[2024-01-15T14:45:13Z ERROR selfware::agent] Panic occurred: already mutably borrowed: BorrowMutError
thread 'tokio-runtime-worker' panicked at src/agent/context.rs:92:14:
already mutably borrowed: BorrowMutError
stack backtrace:
   0: rust_begin_unwind
             at /rustc/.../library/std/src/panicking.rs:645:5
   1: core::panics::panic_fmt
             at /rustc/.../library/core/src/panics.rs:72:14
   2: core::cell::panic_already_mutably_borrowed
             at /rustc/.../library/core/src/cell.rs:...:5
   3: selfware::agent::context::ContextCompressor::compress
             at ./src/agent/context.rs:92:14
   4: selfware::agent::Agent::maybe_compress_context
             at ./src/agent/mod.rs:523:17
   5: selfware::agent::Agent::run_loop::{{closure}}
             at ./src/agent/mod.rs:312:9
   6: <core::pin::Pin<P> as core::future::future::Future>::poll
             at /rustc/.../library/core/src/future/future.rs:...:13
note: Some details are omitted, run with `RUST_BACKTRACE=1` for a verbose backtrace.
```

### Code Context

**File: src/agent/context.rs**
```rust
use crate::api::types::Message;
use crate::api::ApiClient;
use crate::api::ThinkingMode;
use crate::token_count::estimate_tokens_with_overhead;
use anyhow::Result;
use std::cell::RefCell;
use tracing::{debug, info, warn};

const MAX_MESSAGE_COUNT: usize = 512;

pub struct ContextCompressor {
    compression_threshold: usize,
    min_messages_to_keep: usize,
    // Cache for token estimates
    token_cache: RefCell<HashMap<u64, usize>>,
}

impl ContextCompressor {
    pub fn new(token_budget: usize) -> Self {
        Self {
            compression_threshold: (token_budget as f32 * 0.85) as usize,
            min_messages_to_keep: 6,
            token_cache: RefCell::new(HashMap::new()),
        }
    }

    pub fn should_compress(&self, messages: &[Message]) -> bool {
        if messages.len() > MAX_MESSAGE_COUNT {
            return true;
        }
        let estimated = self.estimate_tokens(messages);
        estimated > self.compression_threshold
    }

    pub fn estimate_tokens(&self, messages: &[Message]) -> usize {
        messages
            .iter()
            .map(|m| {
                let content = m.content.text();
                let hash = self.hash_content(content);
                
                // Check cache first
                if let Some(&count) = self.token_cache.borrow().get(&hash) {
                    return count;
                }
                
                let estimate = estimate_tokens_with_overhead(content, 50);
                self.token_cache.borrow_mut().insert(hash, estimate);
                estimate
            })
            .sum()
    }

    pub async fn compress(&self, client: &ApiClient, messages: &[Message]) -> Result<Vec<Message>> {
        if messages.len() <= self.min_messages_to_keep + 1 {
            warn!("Too few messages to compress, returning as-is");
            return Ok(messages.to_vec());
        }

        info!("Compressing context: {} messages", messages.len());

        let system_msg = messages.first().cloned();
        let recent_start = messages.len().saturating_sub(self.min_messages_to_keep);
        let recent_msgs: Vec<Message> = messages[recent_start..].to_vec();
        let to_summarize = &messages[1..recent_start];

        if to_summarize.is_empty() {
            return Ok(messages.to_vec());
        }

        let summary_content = format!(
            "Summarize these previous interactions concisely...\n\n{}",
            to_summarize.iter().enumerate().map(|(i, m)| {
                let content = if m.content.chars().count() > 500 {
                    format!("{}...[truncated]", m.content.chars().take(500).collect::<String>())
                } else {
                    m.content.text().to_string()
                };
                format!("[{}] {}: {}", i, m.role, content)
            }).collect::<Vec<_>>().join("\n\n")
        );

        let summary_request = vec![
            Message::system("You are a context summarizer..."),
            Message::user(summary_content)
        ];

        // Line 92 - PANIC OCCURS HERE
        let response = tokio::time::timeout(
            std::time::Duration::from_secs(120),
            client.chat(summary_request, None, ThinkingMode::Disabled),
        )
        .await
        .map_err(|_| anyhow::anyhow!("Context compression API call timed out after 120s"))??;

        let summary = response
            .choices
            .first()
            .map(|c| c.message.content.text().to_string())
            .unwrap_or_else(|| "[Context compression failed]".to_string());

        let mut compressed = Vec::new();
        if let Some(sys) = system_msg {
            compressed.push(sys);
        }

        compressed.push(Message::user(format!(
            "[CONTEXT SUMMARY - {} earlier messages compressed]:\n{}",
            to_summarize.len(),
            summary
        )));

        compressed.extend(recent_msgs);
        Ok(compressed)
    }

    fn hash_content(&self, content: &str) -> u64 {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};
        
        let mut hasher = DefaultHasher::new();
        content.hash(&mut hasher);
        hasher.finish()
    }
}
```

**File: src/agent/mod.rs (caller context)**
```rust
impl Agent {
    async fn maybe_compress_context(&mut self) -> Result<()> {
        if self.compressor.should_compress(&self.messages) {
            // This is line 523 in the stack trace
            let compressed = self.compressor.compress(&self.client, &self.messages).await?;
            self.messages = compressed;
        }
        Ok(())
    }
    
    async fn run_loop(&mut self) -> Result<()> {
        loop {
            // Line 312 - calls maybe_compress_context
            self.maybe_compress_context().await?;
            // ... rest of loop
        }
    }
}
```

### Specific Deliverables Expected

The model should:

1. **Identify the root cause** of the panic
2. **Explain why it happens** (RefCell borrowing across await points)
3. **Provide a fix** that resolves the issue
4. **Explain the fix** and why it works

### Expected Output Format

```markdown
## Root Cause Analysis

The panic occurs due to a **RefCell borrow across an await point** in an async context.

### The Problem

In `estimate_tokens()`, the code uses `RefCell` for the token cache:
```rust
self.token_cache.borrow().get(&hash)     // Immutable borrow
self.token_cache.borrow_mut().insert(...) // Mutable borrow
```

The issue is that `compress()` is an async function, and between the `.borrow()` 
and `.borrow_mut()` calls, the async runtime can suspend the task. When another 
task (or the same task on resume) tries to borrow the RefCell, it panics because 
the borrow is still active.

This is a classic async Rust anti-pattern: **holding a RefCell borrow across an await point**.

## The Fix

Replace `RefCell` with `tokio::sync::RwLock` which is designed for async contexts:

```rust
use tokio::sync::RwLock;
use std::sync::Arc;

pub struct ContextCompressor {
    compression_threshold: usize,
    min_messages_to_keep: usize,
    token_cache: Arc<RwLock<HashMap<u64, usize>>>,
}

impl ContextCompressor {
    pub fn new(token_budget: usize) -> Self {
        Self {
            compression_threshold: (token_budget as f32 * 0.85) as usize,
            min_messages_to_keep: 6,
            token_cache: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    pub async fn estimate_tokens(&self, messages: &[Message]) -> usize {
        let mut total = 0;
        for m in messages {
            let content = m.content.text();
            let hash = self.hash_content(content);
            
            // Check cache first - acquire read lock
            let cache = self.token_cache.read().await;
            if let Some(&count) = cache.get(&hash) {
                total += count;
                continue;
            }
            drop(cache); // Explicitly drop read lock before acquiring write lock
            
            let estimate = estimate_tokens_with_overhead(content, 50);
            
            // Acquire write lock to insert
            let mut cache = self.token_cache.write().await;
            cache.insert(hash, estimate);
            total += estimate;
        }
        total
    }
    
    // ... rest of implementation
}
```

## Alternative Fix (Simpler)

If the cache doesn't need to be shared across tasks, we can remove the shared 
state entirely and use a local cache in `estimate_tokens`:

```rust
pub fn estimate_tokens(&self, messages: &[Message]) -> usize {
    let mut local_cache: HashMap<u64, usize> = HashMap::new();
    
    messages
        .iter()
        .map(|m| {
            let content = m.content.text();
            let hash = self.hash_content(content);
            
            *local_cache.entry(hash).or_insert_with(|| {
                estimate_tokens_with_overhead(content, 50)
            })
        })
        .sum()
}
```

This is simpler and avoids the async synchronization issue entirely.

## Why This Happens

1. RefCell uses runtime borrow checking (single-threaded)
2. In async code, the task can be suspended at any await point
3. If the borrow is held across an await, another code path might try to borrow
4. This causes the "already mutably borrowed" panic

## Prevention

- Never use RefCell in async code that spans await points
- Use tokio::sync::RwLock or tokio::sync::Mutex for async-safe interior mutability
- Consider if shared state is actually needed
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Root Cause Identification | 30 | Correctly identifies RefCell across await issue |
| Explanation Quality | 20 | Clear explanation of why the panic occurs |
| Fix Correctness | 25 | Provides a working fix |
| Alternative Solutions | 15 | Provides or discusses alternatives |
| Prevention Advice | 10 | Suggests how to avoid similar issues |

**Scoring**:
- 90-100: Excellent - Complete understanding and solution
- 70-89: Good - Correct diagnosis with minor fix issues
- 50-69: Fair - Partial understanding, fix has issues
- <50: Poor - Misdiagnoses the issue

### Difficulty Rating
**8/10**

Requires understanding of:
- RefCell and interior mutability
- Async/await execution model
- Send/Sync traits
- Tokio synchronization primitives
- Borrow checker behavior at runtime

### Real-World Relevance
This is one of the most common async Rust bugs. Understanding RefCell limitations in async contexts is essential for production Rust development.

---

## Benchmark 4: Performance Optimization

### Task Name
`performance_optimization`

### Description
Test the model's ability to identify performance bottlenecks and suggest optimizations for a critical code path.

### Real-World Context
The tool parser is a hot path that processes every model response. Current implementation has performance issues with large inputs.

### Input: Performance Analysis Request

**Context**: The `tool_parser.rs` module parses tool calls from model responses. Profiling shows it's a bottleneck for large responses (>1MB).

**Current Implementation**:

```rust
// src/tool_parser.rs
use regex::Regex;
use serde_json::Value;
use std::sync::OnceLock;

pub struct ParsedToolCall {
    pub tool_name: String,
    pub arguments: Value,
    pub raw_text: String,
    pub parse_method: ParseMethod,
}

pub enum ParseMethod {
    Native, Xml, Json, Markdown,
}

pub struct ParseResult {
    pub tool_calls: Vec<ParsedToolCall>,
    pub text_content: String,
    pub parse_errors: Vec<String>,
}

// Regex patterns - compiled once
static XML_TOOL_REGEX: OnceLock<Regex> = OnceLock::new();
static JSON_BLOCK_REGEX: OnceLock<Regex> = OnceLock::new();
static QWEN3_TOOL_CALL_REGEX: OnceLock<Regex> = OnceLock::new();

pub fn parse_tool_calls(content: &str) -> ParseResult {
    let mut result = ParseResult {
        tool_calls: Vec::new(),
        text_content: String::new(),
        parse_errors: Vec::new(),
    };

    // Try native format first
    if let Some(calls) = try_parse_native(content) {
        result.tool_calls.extend(calls);
        return result;
    }

    // Try XML format
    let xml_regex = XML_TOOL_REGEX.get_or_init(|| {
        Regex::new(r"<tool>\s*<name>([^<]+)</name>\s*<arguments>(.*?)</arguments>\s*</tool>")
            .unwrap()
    });
    
    for cap in xml_regex.captures_iter(content) {
        let name = cap.get(1).map(|m| m.as_str().trim()).unwrap_or("");
        let args_str = cap.get(2).map(|m| m.as_str()).unwrap_or("{}");
        
        match serde_json::from_str::<Value>(args_str) {
            Ok(args) => {
                result.tool_calls.push(ParsedToolCall {
                    tool_name: name.to_string(),
                    arguments: args,
                    raw_text: cap.get(0).unwrap().as_str().to_string(),
                    parse_method: ParseMethod::Xml,
                });
            }
            Err(e) => {
                result.parse_errors.push(format!("XML parse error: {}", e));
            }
        }
    }

    // Try JSON blocks
    let json_regex = JSON_BLOCK_REGEX.get_or_init(|| {
        Regex::new(r"```json\s*\n(.*?)\n```").unwrap()
    });
    
    for cap in json_regex.captures_iter(content) {
        let json_str = cap.get(1).map(|m| m.as_str()).unwrap_or("");
        
        match serde_json::from_str::<Value>(json_str) {
            Ok(Value::Object(mut obj)) => {
                if let Some(Value::String(name)) = obj.remove("tool_name") {
                    result.tool_calls.push(ParsedToolCall {
                        tool_name: name,
                        arguments: Value::Object(obj),
                        raw_text: cap.get(0).unwrap().as_str().to_string(),
                        parse_method: ParseMethod::Json,
                    });
                }
            }
            _ => {}
        }
    }

    // Extract text content (remove tool calls)
    result.text_content = extract_text_content(content, &result.tool_calls);
    
    result
}

fn extract_text_content(content: &str, tool_calls: &[ParsedToolCall]) -> String {
    let mut text = content.to_string();
    for call in tool_calls {
        text = text.replace(&call.raw_text, "");
    }
    text.trim().to_string()
}

fn try_parse_native(content: &str) -> Option<Vec<ParsedToolCall>> {
    // Try to parse as native tool_calls format
    if let Ok(Value::Array(calls)) = serde_json::from_str(content) {
        let parsed: Vec<ParsedToolCall> = calls
            .into_iter()
            .filter_map(|call| {
                let obj = call.as_object()?;
                Some(ParsedToolCall {
                    tool_name: obj.get("name")?.as_str()?.to_string(),
                    arguments: obj.get("arguments")?.clone(),
                    raw_text: call.to_string(),
                    parse_method: ParseMethod::Native,
                })
            })
            .collect();
        if !parsed.is_empty() {
            return Some(parsed);
        }
    }
    None
}
```

**Profiling Data**:
```
Flamegraph analysis (1MB input):
- 45% time in regex captures_iter
- 25% time in string allocations (to_string, replace)
- 15% time in JSON parsing
- 10% time in regex compilation (first call)
- 5% other

Memory profile:
- 3x input size allocated during processing
- Peak memory: ~3.5MB for 1MB input
```

### Specific Deliverables Expected

The model should:

1. **Identify bottlenecks** in the current implementation
2. **Suggest optimizations** with code examples
3. **Estimate performance improvements**
4. **Discuss trade-offs** of each optimization

### Expected Output Format

```markdown
## Performance Bottlenecks Identified

### 1. Multiple Regex Scans (45% of time)
The code runs multiple `captures_iter()` passes over the entire content, 
even if an earlier format succeeds.

### 2. Excessive String Allocations (25% of time)
- `to_string()` called on every match
- `extract_text_content` does O(n²) string replacements
- Each replacement creates a new String

### 3. Eager Parsing
All formats are attempted even if one succeeds early.

## Optimized Implementation

```rust
use regex::Regex;
use serde_json::Value;
use std::sync::OnceLock;

pub struct ParsedToolCall {
    pub tool_name: String,
    pub arguments: Value,
    pub span: TextSpan,  // Store span instead of cloned text
    pub parse_method: ParseMethod,
}

#[derive(Clone, Copy)]
pub struct TextSpan {
    pub start: usize,
    pub end: usize,
}

pub struct ParseResult {
    pub tool_calls: Vec<ParsedToolCall>,
    pub text_content: String,
    pub parse_errors: Vec<String>,
}

// Pre-compiled regexes with better patterns
static XML_REGEX: OnceLock<Regex> = OnceLock::new();
static JSON_BLOCK_REGEX: OnceLock<Regex> = OnceLock::new();

/// Optimized parser with single-pass scanning
pub fn parse_tool_calls(content: &str) -> ParseResult {
    // Fast path: try native JSON first (no regex needed)
    if let Some(calls) = try_parse_native(content) {
        let text = extract_text_content_fast(content, &calls);
        return ParseResult {
            tool_calls: calls,
            text_content: text,
            parse_errors: Vec::new(),
        };
    }

    // Single-pass combined regex for XML and JSON blocks
    let combined_regex = get_combined_regex();
    let mut tool_calls = Vec::new();
    let mut last_end = 0;
    
    for cap in combined_regex.captures_iter(content) {
        let full_match = cap.get(0).unwrap();
        let start = full_match.start();
        let end = full_match.end();
        
        // Try XML format (group 1 is name, group 2 is args)
        if let Some(name_match) = cap.get(1) {
            let name = name_match.as_str().trim();
            let args_str = cap.get(2).map(|m| m.as_str()).unwrap_or("{}");
            
            if let Ok(args) = serde_json::from_str::<Value>(args_str) {
                tool_calls.push(ParsedToolCall {
                    tool_name: name.to_string(),
                    arguments: args,
                    span: TextSpan { start, end },
                    parse_method: ParseMethod::Xml,
                });
            }
        }
        // Try JSON block format (group 3 is the JSON content)
        else if let Some(json_match) = cap.get(3) {
            if let Ok(Value::Object(mut obj)) = 
                serde_json::from_str::<Value>(json_match.as_str()) {
                if let Some(Value::String(name)) = obj.remove("tool_name") {
                    tool_calls.push(ParsedToolCall {
                        tool_name: name,
                        arguments: Value::Object(obj),
                        span: TextSpan { start, end },
                        parse_method: ParseMethod::Json,
                    });
                }
            }
        }
        
        last_end = end;
    }

    // Build text content without tool calls - single allocation
    let text_content = build_text_content(content, &tool_calls);
    
    ParseResult {
        tool_calls,
        text_content,
        parse_errors: Vec::new(),
    }
}

/// Build text content efficiently using a single String allocation
fn build_text_content(content: &str, tool_calls: &[ParsedToolCall]) -> String {
    if tool_calls.is_empty() {
        return content.trim().to_string();
    }

    let mut result = String::with_capacity(content.len());
    let mut last_end = 0;
    
    for call in tool_calls {
        // Append content before this tool call
        result.push_str(&content[last_end..call.span.start]);
        last_end = call.span.end;
    }
    
    // Append remaining content
    result.push_str(&content[last_end..]);
    
    result.trim().to_string()
}

/// Fast native JSON parsing attempt
fn try_parse_native(content: &str) -> Option<Vec<ParsedToolCall>> {
    // Quick check: must start with [ for array
    if !content.trim_start().starts_with('[') {
        return None;
    }
    
    let value: Value = serde_json::from_str(content).ok()?;
    let calls = value.as_array()?;
    
    let parsed: Vec<ParsedToolCall> = calls
        .iter()
        .filter_map(|call| {
            let obj = call.as_object()?;
            Some(ParsedToolCall {
                tool_name: obj.get("name")?.as_str()?.to_string(),
                arguments: obj.get("arguments")?.clone(),
                span: TextSpan { start: 0, end: 0 }, // Would need proper span tracking
                parse_method: ParseMethod::Native,
            })
        })
        .collect();
    
    if parsed.is_empty() {
        None
    } else {
        Some(parsed)
    }
}

fn get_combined_regex() -> &'static Regex {
    XML_REGEX.get_or_init(|| {
        // Combined pattern for both XML and JSON blocks
        Regex::new(r"(?s)(?:<tool>\s*<name>([^<]+)</name>\s*<arguments>(.*?)</arguments>\s*</tool>)|(?:```json\s*\n(.*?)\n```)")
            .unwrap()
    })
}

fn extract_text_content_fast(content: &str, _tool_calls: &[ParsedToolCall]) -> String {
    content.trim().to_string()
}
```

## Performance Improvements

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Time (1MB) | ~150ms | ~40ms | **2.7x faster** |
| Memory | 3.5MB | 1.2MB | **2.9x less** |
| Allocations | ~500 | ~50 | **10x fewer** |

## Key Optimizations

1. **Single-pass regex**: Combined patterns into one regex scan
2. **Span-based tracking**: Store positions instead of cloning strings
3. **Efficient text extraction**: Build result in single pass with pre-allocated capacity
4. **Fast path for native format**: Check array marker before attempting JSON parse
5. **Early returns**: Return immediately if native format succeeds

## Trade-offs

- **Complexity**: Combined regex is more complex to maintain
- **Error messages**: Less granular error reporting
- **Extensibility**: Adding new formats requires regex modification

## Further Optimizations (if needed)

1. **Streaming parser**: For very large inputs, use a streaming approach
2. **SIMD string search**: Use memchr for fast pattern detection
3. **Arena allocation**: Use bumpalo for temporary allocations
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Bottleneck Identification | 25 | Correctly identifies major performance issues |
| Optimization Quality | 30 | Suggestions meaningfully improve performance |
| Code Correctness | 20 | Optimized code is correct and maintains functionality |
| Trade-off Analysis | 15 | Discusses pros/cons of optimizations |
| Quantitative Estimates | 10 | Provides realistic performance estimates |

**Scoring**:
- 90-100: Excellent - Comprehensive optimization with significant gains
- 70-89: Good - Solid optimizations with minor issues
- 50-69: Fair - Some good suggestions but misses key opportunities
- <50: Poor - Optimizations don't significantly help or are incorrect

### Difficulty Rating
**9/10**

Requires understanding of:
- Regex performance characteristics
- Memory allocation patterns
- String manipulation efficiency
- Zero-copy techniques
- Rust performance profiling

### Real-World Relevance
Performance optimization is critical for production systems. This tests the model's ability to analyze profiling data and apply optimization techniques.

---

## Benchmark 5: Migration to Newer Rust Edition/Dependencies

### Task Name
`edition_migration`

### Description
Test the model's ability to migrate code to a newer Rust edition and update dependencies, handling breaking changes appropriately.

### Real-World Context
The codebase needs to migrate from Rust 2021 to Rust 2024 edition, and update several key dependencies with breaking changes.

### Input: Migration Requirements

**Current State**:
- Rust edition: 2021
- tokio: 1.35.0
- serde: 1.0.193
- regex: 1.10.0
- thiserror: 1.0.50
- anyhow: 1.0.75

**Target State**:
- Rust edition: 2024
- tokio: 1.40.0
- serde: 1.0.210
- regex: 1.11.0
- thiserror: 2.0.0
- anyhow: 1.0.90

**Code to Migrate**:

**File 1: Cargo.toml**
```toml
[package]
name = "selfware"
version = "0.9.2"
edition = "2021"
rust-version = "1.70"

[dependencies]
tokio = { version = "1.35.0", features = ["full"] }
serde = { version = "1.0.193", features = ["derive"] }
serde_json = "1.0"
regex = "1.10.0"
thiserror = "1.0.50"
anyhow = "1.0.75"
tracing = "0.1"
tracing-subscriber = "0.3"
reqwest = { version = "0.11", features = ["json"] }
clap = { version = "4.4", features = ["derive"] }
```

**File 2: src/errors.rs**
```rust
use std::path::PathBuf;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum SelfwareError {
    #[error("Agent error: {0}")]
    Agent(#[from] AgentError),

    #[error("API error: {0}")]
    Api(#[from] ApiError),

    #[error("Tool error: {0}")]
    Tool(#[from] ToolError),

    #[error("Safety error: {0}")]
    Safety(#[from] SafetyError),
}

#[derive(Error, Debug)]
pub enum AgentError {
    #[error("Tool '{tool_name}' requires confirmation")]
    ConfirmationRequired { tool_name: String },

    #[error("Iteration limit reached ({limit})")]
    IterationLimit { limit: usize },

    #[error("Step timeout after {seconds} seconds")]
    StepTimeout { seconds: u64 },

    #[error("Invalid state transition from {from} to {to}")]
    InvalidStateTransition { from: String, to: String },

    #[error("Task cancelled by user")]
    Cancelled,
}

#[derive(Error, Debug)]
pub enum ApiError {
    #[error("API Request timed out")]
    Timeout,

    #[error("Rate limit exceeded. Retry after {retry_after_secs:?} seconds")]
    RateLimit { retry_after_secs: Option<u64> },

    #[error("Authentication failed: {0}")]
    Authentication(String),

    #[error("API returned status {status}: {message}")]
    HttpStatus { status: u16, message: String },
}

#[derive(Error, Debug)]
pub enum ToolError {
    #[error("Tool '{name}' failed: {message}")]
    Execution { name: String, message: String },

    #[error("Tool '{name}' not found")]
    NotFound { name: String },
}

#[derive(Error, Debug)]
pub enum SafetyError {
    #[error("Path blocked by safety policy: {path}")]
    BlockedPath { path: String },

    #[error("Dangerous command blocked: {command} ({reason})")]
    BlockedCommand { command: String, reason: String },
}
```

**File 3: src/agent/mod.rs (async trait usage)**
```rust
use anyhow::Result;
use async_trait::async_trait;

#[async_trait]
pub trait Tool: Send + Sync {
    fn name(&self) -> &str;
    fn description(&self) -> &str;
    async fn execute(&self, args: serde_json::Value) -> Result<String>;
}

pub struct FileReadTool;

#[async_trait]
impl Tool for FileReadTool {
    fn name(&self) -> &str {
        "file_read"
    }
    
    fn description(&self) -> &str {
        "Read a file from disk"
    }
    
    async fn execute(&self, args: serde_json::Value) -> Result<String> {
        let path = args.get("path").unwrap().as_str().unwrap();
        tokio::fs::read_to_string(path).await.map_err(|e| e.into())
    }
}
```

**File 4: src/main.rs (macro usage)**
```rust
#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let _ = env_logger::builder()
        .filter_level(log::LevelFilter::Info)
        .try_init();
    
    selfware::cli::run().await
}
```

**Breaking Changes to Handle**:

1. **Rust 2024 Edition Changes**:
   - `gen` is now a reserved keyword
   - Changes to `macro_rules` hygiene
   - New unsafe op semantics
   - `impl Trait` lifetime captures

2. **thiserror 2.0 Breaking Changes**:
   - `#[error(transparent)]` behavior change
   - New `#[error(\"{0}\")]` interpolation syntax
   - `Display` impl changes

3. **tokio 1.40 Changes**:
   - `tokio::task::Builder` changes
   - New runtime configuration options

4. **regex 1.11 Changes**:
   - Pattern syntax changes for some edge cases
   - New `Regex::captures_iter` behavior

### Specific Deliverables Expected

The model should provide:

1. **Updated Cargo.toml** with correct versions
2. **Migrated source code** handling all breaking changes
3. **Migration notes** explaining what changed and why
4. **Potential issues** to watch for

### Expected Output Format

```toml
# Updated Cargo.toml
[package]
name = "selfware"
version = "0.9.2"
edition = "2024"
rust-version = "1.80"  # Rust 2024 requires 1.80+

[dependencies]
tokio = { version = "1.40.0", features = ["full"] }
serde = { version = "1.0.210", features = ["derive"] }
serde_json = "1.0"
regex = "1.11.0"
thiserror = "2.0.0"
anyhow = "1.0.90"
tracing = "0.1"
tracing-subscriber = "0.3"
reqwest = { version = "0.12", features = ["json"] }  # Also updated
clap = { version = "4.5", features = ["derive"] }    # Also updated
```

```rust
// Updated src/errors.rs
// thiserror 2.0 changes: #[error(transparent)] now requires explicit display
// The migration is mostly automatic, but we should verify the behavior

use std::path::PathBuf;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum SelfwareError {
    #[error("Agent error: {0}")]
    Agent(#[from] AgentError),

    #[error("API error: {0}")]
    Api(#[from] ApiError),

    #[error("Tool error: {0}")]
    Tool(#[from] ToolError),

    #[error("Safety error: {0}")]
    Safety(#[from] SafetyError),
    
    // For anyhow::Error, we need to handle the transparent case differently
    // in thiserror 2.0 if we want custom display
    #[error(transparent)]
    Other(#[from] anyhow::Error),
}

// No changes needed for these - they work the same in thiserror 2.0
#[derive(Error, Debug)]
pub enum AgentError {
    #[error("Tool '{tool_name}' requires confirmation")]
    ConfirmationRequired { tool_name: String },

    #[error("Iteration limit reached ({limit})")]
    IterationLimit { limit: usize },

    #[error("Step timeout after {seconds} seconds")]
    StepTimeout { seconds: u64 },

    #[error("Invalid state transition from {from} to {to}")]
    InvalidStateTransition { from: String, to: String },

    #[error("Task cancelled by user")]
    Cancelled,
}

#[derive(Error, Debug)]
pub enum ApiError {
    #[error("API Request timed out")]
    Timeout,

    #[error("Rate limit exceeded. Retry after {retry_after_secs:?} seconds")]
    RateLimit { retry_after_secs: Option<u64> },

    #[error("Authentication failed: {0}")]
    Authentication(String),

    #[error("API returned status {status}: {message}")]
    HttpStatus { status: u16, message: String },
}

#[derive(Error, Debug)]
pub enum ToolError {
    #[error("Tool '{name}' failed: {message}")]
    Execution { name: String, message: String },

    #[error("Tool '{name}' not found")]
    NotFound { name: String },
}

#[derive(Error, Debug)]
pub enum SafetyError {
    #[error("Path blocked by safety policy: {path}")]
    BlockedPath { path: String },

    #[error("Dangerous command blocked: {command} ({reason})")]
    BlockedCommand { command: String, reason: String },
}
```

```rust
// Updated src/agent/mod.rs
// Rust 2024 edition: async traits are now natively supported!
// We can remove the async_trait crate dependency

use anyhow::Result;

// Native async trait - no #[async_trait] needed in Rust 2024!
pub trait Tool: Send + Sync {
    fn name(&self) -> &str;
    fn description(&self) -> &str;
    fn execute(&self, args: serde_json::Value) -> impl std::future::Future<Output = Result<String>> + Send;
}

pub struct FileReadTool;

impl Tool for FileReadTool {
    fn name(&self) -> &str {
        "file_read"
    }
    
    fn description(&self) -> &str {
        "Read a file from disk"
    }
    
    async fn execute(&self, args: serde_json::Value) -> Result<String> {
        let path = args.get("path").unwrap().as_str().unwrap();
        tokio::fs::read_to_string(path).await.map_err(|e| e.into())
    }
}

// Alternative: Use RPITIT (Return Position Impl Trait In Traits) explicitly
// for more complex cases:
pub trait AdvancedTool: Send + Sync {
    fn name(&self) -> &str;
    type ExecuteFuture<'a>: std::future::Future<Output = Result<String>> + Send
    where
        Self: 'a;
    fn execute<'a>(&'a self, args: serde_json::Value) -> Self::ExecuteFuture<'a>;
}
```

```rust
// Updated src/main.rs
// Rust 2024: No significant changes needed for this file
// But we should verify the tokio::main macro behavior

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // In Rust 2024, we might want to use the new let/else syntax
    // but the existing code works fine
    let _ = env_logger::builder()
        .filter_level(log::LevelFilter::Info)
        .try_init();
    
    selfware::cli::run().await
}
```

## Migration Notes

### Rust 2024 Edition Changes

1. **Native Async Traits**: The biggest win! We can remove `async_trait` crate
   - Replace `#[async_trait]` with native `impl Future` return types
   - More efficient (no boxing)
   - Cleaner code

2. **`gen` Keyword**: Check for any variables named `gen` - now reserved
   - Search: `grep -r "\bgen\b" src/`
   - Rename any occurrences

3. **Unsafe Op Semantics**: If using raw pointers, verify behavior
   - Our codebase doesn't use unsafe, so no changes needed

### Dependency Updates

1. **thiserror 2.0**:
   - Mostly backward compatible
   - `#[error(transparent)]` now derives Display from source
   - Our usage is compatible

2. **tokio 1.40**:
   - No breaking changes affecting our code
   - New features available if needed

3. **regex 1.11**:
   - No breaking changes for our usage patterns
   - Performance improvements

4. **anyhow 1.0.90**:
   - Fully backward compatible

### Potential Issues to Watch For

1. **Rust Version Requirement**: Rust 2024 requires 1.80+
   - Update CI/CD to use Rust 1.80+
   - Update documentation

2. **Third-Party Crate Compatibility**:
   - Verify all dependencies support Rust 2024
   - Check for any edition-gated features

3. **Async Trait Migration**:
   - Test thoroughly - native async traits have different type inference
   - Some edge cases may need explicit type annotations

### Migration Checklist

- [ ] Update `Cargo.toml` edition and dependencies
- [ ] Update `rust-version` in `Cargo.toml`
- [ ] Remove `async_trait` crate if no longer needed
- [ ] Migrate async trait definitions
- [ ] Search for `gen` keyword usage
- [ ] Run `cargo fix --edition`
- [ ] Run full test suite
- [ ] Update CI to Rust 1.80+
- [ ] Update documentation
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Cargo.toml Updates | 15 | Correct version updates |
| Rust 2024 Adaptation | 30 | Properly handles edition changes |
| Dependency Migration | 25 | Handles breaking changes correctly |
| Code Quality | 15 | Clean, maintainable migrated code |
| Documentation | 15 | Clear migration notes and checklist |

**Scoring**:
- 90-100: Excellent - Complete migration with all edge cases handled
- 70-89: Good - Correct migration with minor issues
- 50-69: Fair - Migration works but misses some changes
- <50: Poor - Migration breaks code or misses critical changes

### Difficulty Rating
**7/10**

Requires understanding of:
- Rust edition changes
- Dependency versioning and breaking changes
- Async trait evolution
- Migration strategies
- Backward compatibility

### Real-World Relevance
Dependency and edition migration is a regular maintenance task. This tests the model's knowledge of Rust ecosystem evolution and breaking changes.

---

## Summary

| Benchmark | Difficulty | Focus Area | Key Skills Tested |
|-----------|------------|------------|-------------------|
| PR Review | 7/10 | Code Review | Bug detection, severity assessment |
| Feature Addition | 8/10 | Implementation | Pattern matching, integration |
| Debugging | 8/10 | Problem Solving | Root cause analysis, async understanding |
| Performance | 9/10 | Optimization | Profiling, algorithmic thinking |
| Migration | 7/10 | Maintenance | Ecosystem knowledge, breaking changes |

## Testing Instructions

### Localhost Setup for Qwen3.5

```bash
# Using vLLM
python -m vllm.entrypoints.openai.api_server \
    --model Qwen/Qwen3.5-32B \
    --tensor-parallel-size 4 \
    --max-model-len 32768

# Or using llama.cpp
./server -m qwen3.5-32b-q4_k_m.gguf \
    --ctx-size 32768 \
    --n-gpu-layers 999
```

### Running Benchmarks

```python
import requests
import json

def run_benchmark(benchmark_name, prompt):
    response = requests.post(
        "http://localhost:8000/v1/chat/completions",
        json={
            "model": "Qwen3.5-32B",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.2,
            "max_tokens": 4096
        }
    )
    return response.json()["choices"][0]["message"]["content"]

# Load benchmark prompts
with open("benchmarks.json") as f:
    benchmarks = json.load(f)

for name, benchmark in benchmarks.items():
    result = run_benchmark(name, benchmark["prompt"])
    score = evaluate_result(name, result, benchmark["criteria"])
    print(f"{name}: {score}/100")
```

## Evaluation Automation

Each benchmark includes:
- **Expected output patterns**: Regex patterns to check for key elements
- **Scoring rubric**: Point breakdown for each criterion
- **Test cases**: Specific inputs/outputs for verification

Example evaluation script provided in `evaluate_benchmarks.py`.
