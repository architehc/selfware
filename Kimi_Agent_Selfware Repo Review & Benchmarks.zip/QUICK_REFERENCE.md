# Quick Reference: Intermediate Rust Benchmarks

## Running a Complete Evaluation

```bash
# 1. Navigate to the output directory
cd /mnt/okcomputer/output

# 2. Test the evaluator with sample responses
python benchmark_runner.py \
    --benchmark trait_hierarchy_analysis \
    --response sample_responses/trait_hierarchy_analysis_response.json

# 3. Evaluate all sample responses
python benchmark_runner.py \
    --all-responses sample_responses/ \
    --output evaluation_results.json
```

## Benchmark Quick Guide

| # | Benchmark | Difficulty | Focus | Key Concepts |
|---|-----------|------------|-------|--------------|
| 1 | Trait Analysis | 6/10 | Traits, Generics | Blanket impls, PhantomData, Associated types |
| 2 | Lifetime Issues | 7/10 | Borrow Checker | Self-referential structs, dangling refs |
| 3 | Refactoring | 6/10 | Error Handling | Result types, Builder pattern, Enums |
| 4 | Module Analysis | 5/10 | Visibility | Re-exports, Feature gates, Imports |
| 5 | Concurrency | 7/10 | Async/Parallel | Deadlocks, RwLock/Mutex, Patterns |

## Prompt Template for Models

```
You are a Rust expert. Analyze the following Rust code and answer the questions.
Respond in valid JSON format only.

[CODE BLOCK HERE]

Questions:
1. [Question text]
2. [Question text]
...

Respond with JSON in this format:
{
  "question_1": { "answer": "..." },
  "question_2": { "answer": "..." }
}
```

## Evaluation Criteria Summary

### Benchmark 1: Trait Analysis (10 points)
- Blanket impls identified (2 pts)
- Associated types explained (2 pts)
- Generic bounds analysis (2 pts)
- Chaining mechanism (2 pts)
- Error handling strategy (2 pts)

### Benchmark 2: Lifetime Issues (10 points)
- Issue identification (3 pts)
- Error message accuracy (2 pts)
- Root cause explanation (2 pts)
- ConfigBuilder fix (2 pts)
- Code quality (1 pt)

### Benchmark 3: Refactoring (10 points)
- Error enum design (2 pts)
- Builder pattern (2 pts)
- Type safety (2 pts)
- No panics (2 pts)
- API improvements (2 pts)

### Benchmark 4: Module Analysis (10 points)
- Visibility analysis (2 pts)
- Import paths (2 pts)
- Feature gates (2 pts)
- Re-exports (2 pts)
- Dependencies (2 pts)

### Benchmark 5: Concurrency (10 points)
- Synchronization primitives (2 pts)
- Deadlock analysis (2 pts)
- Performance issues (2 pts)
- Pattern identification (2 pts)
- Improvements (2 pts)

## Pass Thresholds

| Benchmark | Pass Score | Pass % |
|-----------|------------|--------|
| All | 7/10 | 70% |
| Module Analysis | 6/10 | 60% |
| Others | 7/10 | 70% |

## Common Keywords for Evaluation

### Trait Analysis
- "blanket", "pipeline", "processor", "phantom", "associated type"

### Lifetime Issues
- "dropped", "reference", "scope", "dangling", "self-referential"

### Refactoring
- "result", "error", "builder", "enum", "panic", "unwrap"

### Module Analysis
- "public", "private", "feature", "re-export", "accessible"

### Concurrency
- "deadlock", "mutex", "rwlock", "channel", "atomic", "race"

## Testing with Different Models

### Ollama
```bash
ollama run qwen3.5 "[prompt]"
```

### LM Studio
```bash
curl http://localhost:1234/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "[prompt]"}]}'
```

### Text Generation WebUI
```bash
curl http://localhost:5000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{"prompt": "[prompt]", "max_tokens": 2000}'
```

## Troubleshooting

### Invalid JSON Response
Add to prompt: "Respond ONLY with valid JSON. No markdown, no explanations outside JSON."

### Low Scores
- Check if model understands Rust syntax
- Verify prompt includes complete code
- Consider using a larger model variant

### Partial Matches
The evaluator uses keyword matching. For semantic evaluation, consider using:
- Sentence transformers for similarity
- LLM-as-judge pattern
- Manual review

## File Structure

```
output/
├── intermediate_rust_benchmarks.md    # Full benchmark specs
├── benchmark_runner.py                 # Evaluation script
├── README.md                           # Documentation
├── QUICK_REFERENCE.md                  # This file
└── sample_responses/                   # Example responses
    ├── trait_hierarchy_analysis_response.json
    ├── lifetime_bug_detection_response.json
    ├── refactor_poor_structure_response.json
    ├── module_import_analysis_response.json
    └── concurrency_pattern_analysis_response.json
```

## Next Steps

1. **Run baseline evaluation** with sample responses
2. **Test with your model** using the prompt templates
3. **Compare results** across different models
4. **Extend benchmarks** with additional test cases
5. **Fine-tune evaluation** for your specific use case
