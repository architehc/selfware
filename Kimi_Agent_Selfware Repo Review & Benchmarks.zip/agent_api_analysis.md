# Comprehensive Analysis: selfware/src/agent/ and src/api/ Modules

## Executive Summary

The selfware repository is a sophisticated AI-powered software engineering assistant written in Rust. 
The `src/agent/` and `src/api/` directories form the core of the system, implementing an autonomous 
agent that orchestrates LLM reasoning with tool execution, and a robust API client for communicating 
with OpenAI-compatible endpoints.

---

## 1. src/agent/ MODULE ANALYSIS

### Module Structure

The agent module consists of 14 files organized into a cohesive system:

```
src/agent/
├── mod.rs                 # Core Agent struct and implementation
├── context.rs             # Context compression for token management
├── context_management.rs  # Context file tracking and reloading
├── checkpointing.rs       # Task checkpointing for resumption
├── execution.rs           # Tool execution and step processing
├── interactive.rs         # Interactive REPL mode
├── last_tool.rs           # Last tool tracking for quick re-execution
├── learning.rs            # Self-improvement and learning systems
├── loop_control.rs        # Agent state machine and iteration control
├── planning.rs            # Task planning prompts
├── streaming.rs           # Streaming response handling
├── task_runner.rs         # Main task execution loop
├── tests.rs               # Unit tests
└── tui_events.rs          # TUI event emission
```

### 1.1 Core Agent (mod.rs)

**Purpose**: Central orchestrator that manages the entire AI assistant lifecycle.

**Key Struct: `Agent`**
```rust
pub struct Agent {
    client: ApiClient,                    // LLM API communication
    tools: ToolRegistry,                  // Available tools
    memory: AgentMemory,                  // Conversation memory
    safety: SafetyChecker,                // Safety validation
    config: Config,                       // Configuration
    loop_control: AgentLoop,              // Iteration control
    messages: Vec<Message>,               // Conversation history
    compressor: ContextCompressor,        // Token management
    checkpoint_manager: Option<CheckpointManager>,
    current_checkpoint: Option<TaskCheckpoint>,
    cognitive_state: CognitiveState,      // PDVR cycle state
    self_improvement: SelfImprovementEngine, // Learning system
    verification_gate: VerificationGate,  // Code validation
    error_analyzer: ErrorAnalyzer,        // Error analysis
    context_files: Vec<String>,           // Tracked context files
    stale_files: HashSet<String>,         // Modified files
    edit_history: EditHistory,            // Undo support
    chat_store: ChatStore,                // Session persistence
    cancelled: Arc<AtomicBool>,           // Cancellation token
    pending_messages: VecDeque<String>,   // Queued messages
    max_context_tokens: usize,            // Token limit
    recent_tool_calls: VecDeque<(String, u64)>, // Repetition detection
}
```

**Key Methods**:
- `new(config: Config) -> Result<Self>`: Initializes agent with cognitive state, verification gate, and error analyzer
- `needs_confirmation(tool_name: &str) -> bool`: Determines if tool execution requires user confirmation based on execution mode
- `execution_mode() / set_execution_mode()`: Controls execution behavior (Normal, AutoEdit, Yolo, Daemon)
- `cancel_token() / is_cancelled() / reset_cancellation()`: Handles Ctrl+C interruption

**Execution Modes**:
- `Normal`: Asks for confirmation on all non-read-only tools
- `AutoEdit`: Auto-approves file operations, asks for destructive operations
- `Yolo`: Never asks for confirmation (dangerous)
- `Daemon`: Non-interactive mode for automated operation

**System Prompt Strategy**:
The agent supports two modes:
1. **Native Function Calling**: Simple prompt, tools passed via API
2. **XML-based**: Embeds tools in system prompt for backends without native support

The system prompt includes:
- Mandatory workflow (PLAN → IMPLEMENT → VERIFY → FIX → TEST)
- Critical rules (never skip verification, include context for edits)
- Global lessons learned from episodic memory
- Evolved prompt variants from self-improvement engine

---

### 1.2 Context Management (context.rs)

**Purpose**: Manages token budget and compresses conversation history when needed.

**Key Struct: `ContextCompressor`**
```rust
pub struct ContextCompressor {
    compression_threshold: usize,  // 85% of token budget
    min_messages_to_keep: usize,   // Minimum 6 messages
}
```

**Key Methods**:
- `should_compress(messages) -> bool`: Checks if compression is needed based on token estimate or message count (hard limit: 512 messages)
- `estimate_tokens(messages) -> usize`: Estimates token count with overhead
- `compress(client, messages) -> Result<Vec<Message>>`: Uses LLM to summarize older messages

**Compression Strategy**:
1. Keeps system message and recent messages (min_messages_to_keep)
2. Summarizes middle messages using the LLM
3. Returns compressed conversation history

---

### 1.3 Loop Control (loop_control.rs)

**Purpose**: Manages agent state machine and iteration limits.

**Key Enum: `AgentState`**
```rust
pub enum AgentState {
    Planning,
    Executing { step: usize },
    ErrorRecovery { error: String },
    Completed,
    Failed { reason: String },
}
```

**Key Struct: `AgentLoop`**
```rust
pub struct AgentLoop {
    state: AgentState,
    max_iterations: usize,
    current_step: usize,
    iteration: usize,
}
```

**Key Methods**:
- `next_state() -> Option<AgentState>`: Advances state, returns Failed if max iterations exceeded
- `approaching_limit_warning() -> Option<String>`: Returns warnings at 80% and 90% of iteration limit
- `reset_for_task()`: Resets iteration counter for new tasks

---

### 1.4 Planning (planning.rs)

**Purpose**: Generates structured prompts for task planning and code analysis.

**Key Struct: `Planner`** (stateless)

**Key Methods**:
- `create_plan(task, context) -> String`: Creates step-by-step planning prompt
- `analyze_prompt(path) -> String`: Prompt for codebase structure analysis
- `review_prompt(file_path, content) -> String`: Prompt for code review

---

### 1.5 Task Execution (execution.rs)

**Purpose**: Handles the core execution loop for processing LLM responses and executing tools.

**Key Types**:
```rust
struct AssistantStepResponse {
    content: String,
    reasoning_content: Option<String>,
    native_tool_calls: Option<Vec<ToolCall>>,
}
```

**Key Methods on Agent**:
- `execute_step_with_logging() -> Result<bool>`: Executes one step with checkpoint logging
- `execute_pending_tool_calls() -> Result<bool>`: Executes tool calls from last assistant message
- `execute_step_internal() -> Result<bool>`: Core execution logic

**Execution Flow**:
1. Makes API call or uses last message
2. Parses assistant response (native or XML tool calls)
3. Extracts reasoning content if present
4. Executes tools with safety checks
5. Handles tool results and errors
6. Updates checkpoint with tool call log
7. Manages cognitive state transitions

**Tool Call Handling**:
- Supports both native OpenAI-style tool calls
- Supports XML-based tool parsing (`<tool><name>...</name><arguments>...</arguments></tool>`)
- Extracts base64 PNG images from tool results
- Builds image result summaries for context

---

### 1.6 Task Runner (task_runner.rs)

**Purpose**: Main entry point for running tasks with full lifecycle management.

**Key Method: `Agent::run_task()`**

**Execution Flow**:
1. Resets loop control state
2. Sets up Ctrl+C handler for graceful shutdown
3. Initializes checkpoint if not resuming
4. Starts learning session
5. Sets up cognitive state goals and plans
6. Runs the main execution loop:
   - Checks for cancellation
   - Emits TUI events
   - Manages checkpoint persistence
   - Handles tool execution with verification
   - Processes errors with analyzer
   - Compresses context when needed
   - Detects repetition loops
7. Finalizes checkpoint on completion

**Checkpoint Management**:
- Persists checkpoints at configurable intervals
- Tracks tool call count for persistence decisions
- Handles checkpoint recovery on resume

---

### 1.7 Interactive Mode (interactive.rs)

**Purpose**: Provides REPL-style interactive interface for user interaction.

**Key Method: `Agent::interactive()`**

**Features**:
- Advanced line editing with reedline (autocomplete, history, syntax highlighting)
- Fallback to basic mode if reedline unavailable
- Mode indicator display ([normal], [auto-edit], [YOLO], [DAEMON])
- Context stats display on startup
- Command handling:
  - `/help`: Show available commands
  - `/mode`: Switch execution modes
  - `/tools`: List available tools
  - `/ctx`: Show context statistics
  - `/save`, `/load`: Session management
  - `/undo`, `/redo`: Edit history
  - `/copy`: Copy last assistant response
  - `/exit`, `/quit`: Exit interactive mode

---

### 1.8 TUI Events (tui_events.rs)

**Purpose**: Event emission system for real-time UI updates.

**Key Enum: `AgentEvent`**
```rust
pub enum AgentEvent {
    Started,
    Completed,
    Failed { error: String },
    Status { message: String },
    ToolCall { name: String, args: String },
    ToolResult { name: String, result: String },
    Message { role: String, content: String },
    Checkpoint { task_id: String },
}
```

**Key Trait: `EventEmitter`**
```rust
pub trait EventEmitter: Send + Sync {
    fn emit(&self, event: AgentEvent);
}
```

**Implementations**:
- `NoopEmitter`: No-op implementation for non-TUI mode
- `TuiEmitter`: Sends events to TUI for display

---

### 1.9 Learning (learning.rs)

**Purpose**: Self-improvement through outcome tracking and strategy evolution.

**Key Methods on Agent**:
- `start_learning_session()`: Initializes learning context for a task
- `record_tool_outcome()`: Records success/failure of tool calls
- `record_error_outcome()`: Records error patterns and resolutions
- `evolve_prompt()`: Evolves prompts based on outcomes

---

### 1.10 Checkpointing (checkpointing.rs)

**Purpose**: Persists task state for resumption after interruption.

**Integration with Agent**:
- Checkpoint manager initialized in `Agent::new()`
- Checkpoints persisted during task execution
- Tool call log tracked for replay
- Recovery on resume from checkpoint

---

## 2. src/api/ MODULE ANALYSIS

### Module Structure

```
src/api/
├── mod.rs      # ApiClient and streaming infrastructure
└── types.rs    # API types and data structures
```

### 2.1 API Client (mod.rs)

**Purpose**: HTTP client for OpenAI-compatible chat completion APIs with retry logic, circuit breaking, and streaming support.

**Key Trait: `LlmClient`**
```rust
#[async_trait]
pub trait LlmClient: Send + Sync {
    async fn chat(
        &self,
        messages: Vec<Message>,
        tools: Option<Vec<ToolDefinition>>,
        thinking: ThinkingMode,
    ) -> Result<ChatResponse>;

    async fn chat_stream(
        &self,
        messages: Vec<Message>,
        tools: Option<Vec<ToolDefinition>>,
        thinking: ThinkingMode,
    ) -> Result<StreamingResponse>;
}
```

**Key Struct: `ApiClient`**
```rust
#[derive(Clone)]
pub struct ApiClient {
    client: Client,                    // reqwest HTTP client
    config: crate::config::Config,     // Configuration
    base_url: String,                  // API endpoint
    retry_config: RetryConfig,         // Retry policy
    circuit_breaker: Arc<CircuitBreaker>, // Circuit breaker for resilience
}
```

**Key Methods**:
- `new(config) -> Result<Self>`: Creates client with timeout, warns on HTTP to non-local hosts
- `chat(messages, tools, thinking) -> Result<ChatResponse>`: Non-streaming chat completion
- `chat_stream(messages, tools, thinking) -> Result<StreamingResponse>`: Streaming completion
- `completion(prompt, max_tokens, stop) -> Result<CompletionResponse>`: Text completion (for FIM)
- `chat_with_profile(messages, tools, thinking, profile) -> Result<ChatResponse>`: Use alternate model

**Retry Configuration**:
```rust
pub struct RetryConfig {
    pub max_retries: u32,              // Default: 3
    pub initial_delay_ms: u64,         // Default: 1000
    pub max_delay_ms: u64,             // Default: 30000
    pub retryable_status_codes: Vec<u16>, // [429, 500, 502, 503, 504]
}
```

**Retry Logic**:
1. Exponential backoff with jitter (±10%)
2. Honors Retry-After header for 429/503 (capped at 300s)
3. Circuit breaker prevents cascading failures
4. Network timeouts and connection errors are retryable

**Thinking Modes**:
```rust
pub enum ThinkingMode {
    Enabled,           // Full thinking (default)
    Disabled,          // No thinking for faster responses
    Budget(usize),     // Thinking with token budget
}
```

When disabled, injects system message: "CRITICAL INSTRUCTION: DO NOT use <think> blocks..."

---

### 2.2 Streaming Infrastructure

**Key Struct: `StreamingResponse`**
```rust
pub struct StreamingResponse {
    response: reqwest::Response,
    chunk_timeout: Duration,
}
```

**Key Methods**:
- `into_channel() -> mpsc::Receiver<Result<StreamChunk>>`: Returns channel for receiving chunks
- `collect() -> Result<ChatResponse>`: Collects all chunks into complete response

**StreamChunk Enum**:
```rust
pub enum StreamChunk {
    Content(String),        // Text content
    Reasoning(String),      // Thinking/reasoning content
    ToolCall(ToolCall),     // Complete tool call
    Usage(Usage),           // Token usage info
    Done,                   // Stream complete
}
```

**ToolCallAccumulator**: Buffers incremental tool call deltas from SSE streaming
- Handles OpenAI's streaming format (index-based deltas)
- Accumulates arguments across multiple chunks
- Emits complete ToolCall on flush

**SSE Parsing**:
- Parses Server-Sent Events format (`data: {...}`)
- Handles content, reasoning_content, tool_calls, usage, finish_reason
- Flushes buffered tool calls on [DONE] or finish_reason

---

### 2.3 API Types (types.rs)

**Purpose**: Data structures for OpenAI-compatible API requests/responses.

**Key Types**:

**MessageContent** (multimodal support):
```rust
pub enum MessageContent {
    Text(String),                    // Plain text
    Blocks(Vec<ContentBlock>),       // Multimodal (text + images)
}
```

**ContentBlock**:
```rust
pub enum ContentBlock {
    Text { text: String },
    ImageUrl { image_url: ImageUrl },
}
```

**ImageUrl**:
```rust
pub struct ImageUrl {
    pub url: String,        // "data:image/png;base64,..." or URL
    pub detail: Option<String>, // "low", "high", "auto"
}
```

**Message**:
```rust
pub struct Message {
    pub role: String,                    // "system", "user", "assistant", "tool"
    pub content: MessageContent,         // Text or multimodal blocks
    pub reasoning_content: Option<String>, // Model's reasoning
    pub tool_calls: Option<Vec<ToolCall>>, // Tool calls to make
    pub tool_call_id: Option<String>,    // For tool responses
    pub name: Option<String>,            // For function calling
}
```

**ToolCall**:
```rust
pub struct ToolCall {
    pub id: String,
    pub call_type: String,               // "function"
    pub function: ToolFunction,
}
```

**ToolFunction**:
```rust
pub struct ToolFunction {
    pub name: String,
    pub arguments: String,               // JSON string
}
```

**ToolDefinition** (for API schema):
```rust
pub struct ToolDefinition {
    pub def_type: String,                // "function"
    pub function: FunctionDefinition,
}

pub struct FunctionDefinition {
    pub name: String,
    pub description: String,
    pub parameters: serde_json::Value,   // JSON Schema
}
```

**ChatResponse**:
```rust
pub struct ChatResponse {
    pub id: String,
    pub object: String,                  // "chat.completion"
    pub created: u64,                    // Unix timestamp
    pub model: String,
    pub choices: Vec<Choice>,
    pub usage: Usage,
}
```

**Choice**:
```rust
pub struct Choice {
    pub index: usize,
    pub message: Message,
    pub reasoning_content: Option<String>,
    pub finish_reason: Option<String>,   // "stop", "length", "tool_calls"
}
```

**Usage**:
```rust
pub struct Usage {
    pub prompt_tokens: usize,
    pub completion_tokens: usize,
    pub total_tokens: usize,
}
```

**Message Constructors**:
- `Message::system(content)`: System message
- `Message::user(content)`: User message
- `Message::assistant(content)`: Assistant message
- `Message::assistant_with_reasoning(content, reasoning)`: With reasoning
- `Message::tool(content, tool_call_id)`: Tool response
- `Message::user_multimodal(content)`: Multimodal user message

**MessageContent Methods**:
- `text() -> &str`: Extract text portion
- `text_all() -> String`: Concatenate all text blocks
- `image_count() -> usize`: Count image blocks
- `has_images() -> bool`: Check for images
- `strip_images() -> Self`: Remove image blocks
- `with_image(base64_png) -> Self`: Add image to content

---

## 3. MODULE INTERACTIONS

### 3.1 Agent ↔ API Client

```
Agent::run_task()
  ├── ApiClient::chat_stream()  # Streaming request
  │     └── StreamingResponse
  │           └── into_channel()
  │                 └── StreamChunk::Content/ToolCall/...
  ├── Tool execution
  ├── ApiClient::chat()         # Non-streaming fallback
  └── Checkpoint persistence
```

### 3.2 Context Flow

```
Agent messages ──> ContextCompressor::should_compress()
                         │
                         ▼
              estimate_tokens() > threshold?
                         │
                         ▼
              ContextCompressor::compress()
                         │
                         ▼
              ApiClient::chat() with compressed messages
```

### 3.3 Tool Execution Flow

```
Agent::execute_step_internal()
  ├── Parse assistant response
  │     ├── Native tool calls (OpenAI format)
  │     └── XML tool calls (fallback)
  ├── SafetyChecker::validate()
  ├── User confirmation (if needed)
  ├── ToolRegistry::execute()
  │     └── Individual tool execution
  ├── Error analysis (on failure)
  ├── Verification gate (for code changes)
  └── Update checkpoint with ToolCallLog
```

### 3.4 Learning Flow

```
Agent::run_task()
  ├── start_learning_session()
  ├── Execute tools
  │     └── record_tool_outcome() ──> SelfImprovementEngine
  ├── Handle errors
  │     └── record_error_outcome() ──> SelfImprovementEngine
  └── evolve_prompt() <── CognitiveState + SelfImprovementEngine
```

### 3.5 Checkpointing Flow

```
Agent::run_task()
  ├── current_checkpoint = TaskCheckpoint::new()
  ├── Every N tool calls:
  │     └── checkpoint_manager.persist()
  │           └── Serialize to JSON
  ├── On Ctrl+C:
  │     └── Graceful shutdown with checkpoint save
  └── On resume:
        └── Load checkpoint and replay tool calls
```

---

## 4. KEY DESIGN PATTERNS

### 4.1 Resilience Patterns

1. **Circuit Breaker**: Prevents cascading failures when API is down
2. **Retry with Exponential Backoff**: Handles transient errors
3. **Checkpointing**: Enables task resumption after crashes
4. **Cancellation Tokens**: Graceful shutdown on Ctrl+C

### 4.2 Safety Patterns

1. **Execution Modes**: Layered confirmation policy (Normal → AutoEdit → Yolo)
2. **Safety Checker**: Validates tool calls against allowed paths
3. **Verification Gate**: Automatic code validation after changes
4. **Error Analyzer**: Intelligent error suggestions

### 4.3 Extensibility Patterns

1. **Trait-based Design**: `LlmClient` trait enables test mocking
2. **Tool Registry**: Dynamic tool registration
3. **Event Emitter**: Pluggable event system for TUI/observability
4. **Model Profiles**: Support for multiple LLM backends

### 4.4 Performance Patterns

1. **Context Compression**: Token budget management via LLM summarization
2. **Streaming**: Real-time response processing
3. **Message Count Cap**: Hard limit at 512 messages
4. **Image Stripping**: Remove images for non-vision models

---

## 5. COGNITIVE ARCHITECTURE

The agent implements a **PDVR (Plan-Do-Verify-Reflect)** cognitive cycle:

### 5.1 Strategic Layer
- Long-term goals stored in `CognitiveState`
- Episodic memory for lessons learned
- Self-improvement engine for prompt evolution

### 5.2 Tactical Layer
- Task-specific plans
- Tool selection strategies
- Error recovery patterns

### 5.3 Operational Layer
- Individual tool executions
- File operations
- Command execution

### 5.4 State Transitions

```
Planning ──> Executing ──> Verifying ──> Reflecting
    │            │             │              │
    └────────────┴─────────────┴──────────────┘
                    (loop)
```

---

## 6. TESTING INFRASTRUCTURE

The modules include comprehensive tests:

**API Module Tests**:
- Retry configuration
- Exponential backoff calculation
- SSE event parsing
- Tool call accumulation
- Stream chunk processing
- Request/response serialization

**Agent Module Tests**:
- Context compression
- Loop control state transitions
- Tool execution
- Checkpoint management
- Interactive mode commands

---

## 7. OBSERVABILITY

### 7.1 Tracing
- `#[instrument]` macros on key methods
- Span-based tracing for request lifecycle
- Debug logging for API requests (with SELFWARE_DEBUG)

### 7.2 Events
- `AgentEvent` enum for TUI updates
- Real-time status messages
- Tool call/result notifications

### 7.3 Metrics
- Token usage tracking
- Tool call counts
- Iteration counters
- Checkpoint persistence stats

---

## 8. SECURITY CONSIDERATIONS

1. **API Key Handling**: Stored in `RedactedString` to prevent accidental logging
2. **HTTP Warning**: Warns when using HTTP to non-local endpoints
3. **Path Validation**: Safety checker validates file paths against allowed directories
4. **Confirmation Policy**: Layered confirmation based on tool risk level
5. **Circuit Breaker**: Prevents API key exhaustion from retry storms

---

## Summary

The `src/agent/` and `src/api/` modules form a production-ready, resilient, and extensible 
AI agent system. Key strengths include:

1. **Comprehensive Error Handling**: Retry logic, circuit breakers, checkpointing
2. **Safety-First Design**: Multiple execution modes with confirmation policies
3. **Self-Improvement**: Learning from outcomes to evolve prompts and strategies
4. **Multimodal Support**: Text and image handling for vision models
5. **Streaming Architecture**: Real-time response processing with SSE
6. **Extensible Tool System**: Dynamic registration with schema validation
7. **Observability**: Tracing, events, and metrics throughout

The architecture follows Rust best practices with strong typing, error handling via `anyhow`, 
async/await for concurrency, and trait-based abstractions for testability.
