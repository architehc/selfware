# Selfware Repository Analysis: cognitive/, config/, and input/ Modules

## Executive Summary

This document provides a comprehensive analysis of three core modules in the Selfware repository:
- `src/cognitive/` - AI/ML cognitive capabilities and memory systems
- `src/config/` - Configuration management system
- `src/input/` - Terminal input handling with autocomplete and highlighting

---

## 1. src/cognitive/ Module Analysis

### Overview
The cognitive module is the heart of Selfware's AI capabilities, implementing a sophisticated cognitive architecture with a 1M token context window, hierarchical memory systems, and self-referential capabilities for recursive self-improvement.

### Module Structure (19 files)

#### Core Files:

**mod.rs** (44 lines)
- **Purpose**: Module declaration and re-exports
- **Key Exports**:
  - `CognitiveSystem` - Unified cognitive system
  - `HierarchicalMemory` - Three-layer memory architecture
  - `SelfReferenceSystem` - Self-modification capabilities
  - `TokenBudgetAllocator` - Dynamic token management
  - `CognitiveState`, `WorkingMemory`, `EpisodicMemory` - State management

**state.rs** (1,110 lines)
- **Purpose**: Core cognitive state management with PDVR (Plan-Do-Verify-Reflect) cycle
- **Key Structs**:
  - `CognitiveState` - Complete agent cognitive state
    - `strategic_goals: Vec<StrategicGoal>` - Long-term objectives
    - `active_tactical_plan: Option<TacticalPlan>` - Current tactical plan
    - `active_operational_plan: Option<OperationalPlan>` - Current operational plan
    - `working_memory: WorkingMemory` - Immediate context
    - `episodic_memory: EpisodicMemory` - Learned lessons
    - `cycle_phase: CyclePhase` - Current PDVR phase
  - `WorkingMemory` - Task context, hypotheses, and current focus
  - `EpisodicMemory` - Lesson storage with categorization
  - `StrategicGoal`, `TacticalPlan`, `OperationalPlan` - Hierarchical planning
  - `CyclePhase` - Enum: Plan, Do, Verify, Reflect
  - `Lesson`, `LessonCategory` - Learned knowledge storage

**cognitive_system.rs** (2,313 lines)
- **Purpose**: Unified integration of all cognitive components
- **Key Structs**:
  - `CognitiveSystem` - Main orchestrator
    - `memory: Arc<RwLock<HierarchicalMemory>>` - Thread-safe memory access
    - `budget: Arc<RwLock<TokenBudgetAllocator>>` - Token budget management
    - `self_ref: Arc<RwLock<SelfReferenceSystem>>` - Self-reference system
    - `_api_client: Arc<ApiClient>` - LLM API client
  - `LlmContext` - Complete context for LLM prompts
    - `working: WorkingContext` - Conversation context
    - `episodic: Vec<Episode>` - Relevant experiences
    - `semantic: CodeContext` - Codebase context
    - `self_context: Option<SelfImprovementContext>` - Self-modification context
    - `estimated_tokens: usize` - Token count
  - `ContextBuildOptions` - Configuration for context building

**memory_hierarchy.rs** (Partial content retrieved)
- **Purpose**: Three-layer memory architecture for 1M token context
- **Key Constants**:
  - `TOTAL_CONTEXT_TOKENS: usize = 1_000_000`
  - `DEFAULT_WORKING_TOKENS: usize = 100_000`
  - `DEFAULT_EPISODIC_TOKENS: usize = 200_000`
  - `DEFAULT_SEMANTIC_TOKENS: usize = 700_000`
  - `DEFAULT_RESERVE_TOKENS: usize = 100_000`
- **Key Structs**:
  - `HierarchicalMemory` - Unified memory manager
    - `budget: TokenBudget` - Token allocation
    - `working: WorkingMemory` - Layer 1: Immediate context
    - `episodic: EpisodicMemory` - Layer 2: Experiences
    - `semantic: Arc<RwLock<SemanticMemory>>` - Layer 3: Codebase knowledge
    - `usage: MemoryUsage` - Current token usage
    - `metrics: MemoryMetrics` - Performance metrics
  - `TokenBudget` - Budget allocation per layer
  - `MemoryUsage` - Current usage tracking
  - `MemoryMetrics` - Cache hits, misses, evictions, compressions
  - `ContextType` - Enum for retrieval types (Working, Episodic, Semantic, Complete)
  - `RetrievedContext` - Union of retrieved contexts

**self_reference.rs** (2,845 lines)
- **Purpose**: Self-referential context management for recursive self-improvement
- **Key Structs**:
  - `SelfReferenceSystem` - Core self-reference engine
    - `semantic: Arc<RwLock<SemanticMemory>>` - Codebase access
    - `self_model: SelfModel` - Agent's self-model
    - `code_cache: HashMap<String, CachedCode>` - Frequently accessed code
    - `recent_modifications: VecDeque<CodeModification>` - Change history
  - `SelfModel` - The agent's understanding of itself
    - `modules: HashMap<String, ModuleSelfModel>` - Module knowledge
    - `architecture: ArchitectureModel` - System architecture
    - `capabilities: Vec<Capability>` - Known capabilities
    - `limitations: Vec<String>` - Known limitations
    - `recent_changes: Vec<SelfChange>` - Modification history
    - `performance: PerformanceModel` - Performance characteristics
  - `ModuleSelfModel` - Per-module self-model
  - `CodeModification` - Tracked code changes
  - `SelfImprovementContext` - Context for self-modification

**episodic.rs** (1,700 lines)
- **Purpose**: Session-based episodic memory with semantic retrieval
- **Key Structs**:
  - `Episode` - Memory episode
    - `id: String` - Unique identifier
    - `episode_type: EpisodeType` - Type classification
    - `content: String` - Episode content
    - `importance: Importance` - Priority level
    - `embedding: Option<Vec<f32>>` - Semantic vector
    - `timestamp: u64` - Creation time
  - `EpisodeType` - Enum: Conversation, ToolExecution, Error, Success, CodeChange, Learning, Decision
  - `Importance` - Enum: Low, Normal, High, Critical
  - `EpisodicMemory` - Memory storage and retrieval

**token_budget.rs** (943 lines)
- **Purpose**: Dynamic token allocation across memory layers
- **Key Structs**:
  - `TokenBudgetAllocator` - Dynamic budget manager
  - `TaskType` - Enum: Conversation, CodeAnalysis, SelfImprovement, CodeGeneration, Debugging, Refactoring, Learning
  - `AllocationRatios` - Percentage allocation per layer
  - `BudgetStats` - Usage statistics
  - `AdaptationResult` - Budget adjustment results

**rag.rs** (1,598 lines)
- **Purpose**: Local Retrieval-Augmented Generation system
- **Key Structs**:
  - `RagConfig` - RAG configuration
    - `max_context_tokens: usize`
    - `top_k: usize` - Number of results
    - `min_score: f32` - Relevance threshold
    - `include_extensions: Vec<String>` - File types to index
    - `exclude_patterns: Vec<String>` - Patterns to skip
  - `RagSystem` - Core RAG implementation
  - `CodeIndex` - Codebase index
  - `SearchResult` - Retrieved code snippets

**knowledge_graph.rs** (2,309 lines)
- **Purpose**: Codebase knowledge graph with entity relationships
- **Key Structs**:
  - `KnowledgeGraph` - Entity-relationship graph
  - `Entity` - Code entities (modules, functions, structs, etc.)
  - `EntityType` - Enum: Module, Function, Struct, Enum, Trait, Constant, TypeAlias, Impl, Macro, Method, Field, Variant, Parameter, LocalVariable
  - `Relation` - Relationships between entities
  - `RelationType` - Enum: Contains, Calls, Implements, Inherits, Uses, Returns, Parameter, Field, Variant, ImplementsTrait, DependsOn
  - `Pattern` - Detected code patterns
  - `CodeSmell` - Detected code issues

**learning.rs** (1,647 lines)
- **Purpose**: Learning and education mode with explain-as-you-code
- **Key Structs**:
  - `CodeExplanation` - Code explanations
  - `ExplanationLevel` - Enum: Beginner, Intermediate, Advanced, Expert
  - `Concept` - Extracted concepts
  - `Quiz` - Generated quizzes
  - `Lesson` - Structured lessons
  - `Curriculum` - Learning curriculum

**intelligence.rs** (Partial content)
- **Purpose**: Core intelligence and reasoning capabilities

**self_improvement.rs** (Partial content)
- **Purpose**: Self-improvement and meta-learning

**self_edit.rs** (Partial content)
- **Purpose**: Self-modification of source code

**compilation_manager.rs** (Partial content)
- **Purpose**: Safe compilation and testing of modifications

**rsi_orchestrator.rs** (Partial content)
- **Purpose**: Recursive Self-Improvement orchestration

**meta_learning.rs** (Partial content)
- **Purpose**: Meta-learning capabilities (feature-gated)

**metrics.rs** (Partial content)
- **Purpose**: Cognitive metrics tracking (feature-gated)

**load.rs** (Partial content)
- **Purpose**: Cognitive load monitoring

### Interactions with Other Modules

1. **api/** - Uses `ApiClient` for LLM operations
2. **config/** - Uses `Config` for cognitive settings
3. **token_count/** - Uses token estimation functions
4. **vector_store/** - Uses `EmbeddingBackend`, `VectorStore`, `VectorIndex`
5. **agent/** - Cognitive state drives agent behavior

---

## 2. src/config/ Module Analysis

### Overview
The config module provides comprehensive configuration management with TOML file support, type-safe configuration, secret redaction, and resource management.

### Module Structure (3 files)

**mod.rs** (3,780 lines)
- **Purpose**: Main configuration management
- **Key Structs**:
  - `RedactedString` - Secret wrapper that prevents accidental logging
    - Displays `[REDACTED]` in Debug/Display
    - Transparent serialization
    - `expose()` method for access
  - `Config` - Main configuration struct
    - API settings (base URL, model, timeout)
    - Agent behavior (max iterations, context limits)
    - Safety settings (allowed paths, blocked commands)
    - Tool-specific options
  - `ApiConfig` - LLM API configuration
  - `AgentConfig` - Agent behavior settings
  - `SafetyConfig` - Security constraints
  - `ToolConfig` - Tool-specific settings
- **Key Functions**:
  - `load()` - Load from TOML file
  - `save()` - Save to TOML file
  - `validate()` - Validate configuration

**typed.rs** (3,056 lines)
- **Purpose**: Type-safe configuration system
- **Key Structs**:
  - `ConfigValue` - Typed configuration values
    - String, Integer, Float, Boolean
    - Array, Map
    - Duration, Path, Secret
  - `ConfigSchema` - Configuration schema
  - `ConfigField` - Field definition
  - `TypedConfig` - Type-safe config wrapper
- **Features**:
  - Schema validation
  - CLI flag generation
  - Hot reload watching
  - Configuration wizard support

**resources.rs** (365 lines)
- **Purpose**: Resource management configuration
- **Key Structs**:
  - `ResourcesConfig` - Resource settings
    - `gpu: GpuConfig` - GPU monitoring
    - `memory: MemoryConfig` - Memory thresholds
    - `disk: DiskConfig` - Disk management
    - `quotas: ResourceQuotas` - Resource limits
  - `GpuConfig` - GPU temperature, utilization thresholds
  - `MemoryConfig` - Warning/critical/emergency thresholds
  - `DiskConfig` - Usage limits, compression settings
  - `ResourceQuotas` - Maximum resource usage

### Interactions with Other Modules

1. **cognitive/** - Provides configuration for memory, learning
2. **agent/** - Agent behavior configuration
3. **safety/** - Safety constraint configuration
4. **resource/** - Resource management settings

---

## 3. src/input/ Module Analysis

### Overview
The input module provides a modern terminal input system with autocomplete, syntax highlighting, history, and vim/emacs keybindings, built on the reedline library.

### Module Structure (5 files)

**mod.rs** (431 lines)
- **Purpose**: Input system coordinator
- **Key Structs**:
  - `InputConfig` - Input system configuration
    - `mode: InputMode` - Emacs or Vi keybindings
    - `history_path: Option<PathBuf>` - History file location
    - `max_history: usize` - History size limit
    - `syntax_highlight: bool` - Enable highlighting
    - `show_hints: bool` - Show inline hints
    - `tool_names: Vec<String>` - Available tools for completion
    - `commands: Vec<String>` - Available slash commands
  - `InputMode` - Enum: Emacs, Vi
  - `InputSystem` - Main input handler
    - Built on `Reedline` for professional IDE-like experience
    - Integrates completer, highlighter, validator, hinter
- **Key Functions**:
  - `new()` - Create input system
  - `read_line()` - Read user input
  - `add_history()` - Add to history

**command_registry.rs** (862 lines)
- **Purpose**: Unified registry for all slash commands
- **Key Structs**:
  - `CommandEntry` - Registered command
    - `name: &'static str` - Command string (e.g., "/help")
    - `description: &'static str` - Help description
    - `category: CommandCategory` - Command grouping
  - `CommandCategory` - Enum: General, Context, Navigation, Git, Tools, Session, Display
- **Key Constants**:
  - `COMMANDS: &[CommandEntry]` - Complete command registry
    - `/help` - Show help
    - `/status` - Show agent status
    - `/stats` - Show session statistics
    - `/mode` - Switch execution mode
    - `/config` - Show configuration
    - `/cost` - Show token usage
    - `/ctx` - Context management
    - `/cd` - Change directory
    - `/git` - Git operations
    - `/tool` - Tool operations
    - `/quit`, `/exit` - Exit commands
- **Key Functions**:
  - `command_names()` - Get all command names
  - `find_command()` - Lookup by name
  - `commands_by_category()` - Group by category

**completer.rs** (524 lines)
- **Purpose**: Context-aware autocomplete system
- **Key Structs**:
  - `SelfwareCompleter` - Multi-source completer
    - `tool_names: Vec<String>` - Tool name completions
    - `commands: Vec<String>` - Slash command completions
    - `matcher: SkimMatcherV2` - Fuzzy matcher
- **Completion Sources**:
  - Slash commands (/help, /status, etc.)
  - Tool names (file_read, git_status, etc.)
  - File paths
  - Fuzzy matching with scoring
- **Key Functions**:
  - `new()` - Create completer
  - `complete()` - Generate suggestions
  - `complete_commands()` - Command completions
  - `complete_tools()` - Tool name completions
  - `complete_paths()` - File path completions

**highlighter.rs** (383 lines)
- **Purpose**: Syntax highlighting for input
- **Key Structs**:
  - `SelfwareHighlighter` - Input highlighter
    - `command_style: Style` - Amber for commands
    - `path_style: Style` - Sage for paths
    - `tool_style: Style` - Copper for tools
    - `keyword_style: Style` - Garden green for keywords
    - `string_style: Style` - Soil brown for strings
- **Highlighted Elements**:
  - Commands (words starting with "/")
  - File paths (containing "/", ".", "~")
  - Keywords (help, status, quit, etc.)
  - Strings (quoted text)
- **Color Palette**:
  - Amber: #D4A373 (commands)
  - Sage: #8F9779 (paths)
  - Copper: #B87333 (tools)
  - Garden Green: #606C38 (keywords)
  - Soil Brown: #BC6C25 (strings)

**prompt.rs** (333 lines)
- **Purpose**: Workshop prompt with context display
- **Key Structs**:
  - `SelfwarePrompt` - Custom prompt
    - `model: String` - Model name display
    - `step: usize` - Current step number
    - `context_pct: f64` - Context usage percentage
    - `left_style: Style` - Left prompt style
    - `right_style: Style` - Right prompt style
- **Prompt Features**:
  - Fox glyph (🦊) as mascot
  - Model name display
  - Step counter
  - Context usage indicator
  - Right-side status information
- **Key Functions**:
  - `new()` - Create default prompt
  - `with_context()` - Prompt with model/step
  - `with_full_context()` - Prompt with token usage

### Interactions with Other Modules

1. **agent/** - Provides user input to agent
2. **cognitive/** - May use for interactive learning
3. **ui/** - TUI dashboard integration

---

## Key Patterns and Design Decisions

### 1. Cognitive Module
- **Hierarchical Memory**: Three-layer architecture (working, episodic, semantic)
- **Token Budgeting**: Dynamic allocation based on task type
- **Self-Reference**: Recursive self-improvement capability
- **PDVR Cycle**: Structured planning and reflection
- **Feature Gating**: Self-improvement features behind `self-improvement` flag

### 2. Config Module
- **Secret Redaction**: `RedactedString` prevents credential leaks
- **Type Safety**: `ConfigValue` enum for typed configuration
- **Validation**: Schema-based config validation
- **Hot Reload**: Configuration watching for updates

### 3. Input Module
- **Modular Design**: Separate completer, highlighter, prompt
- **Fuzzy Matching**: SkimMatcherV2 for smart completion
- **IDE-like Experience**: Built on reedline with vim/emacs support
- **Organic Colors**: Warm, natural color palette

---

## Module Dependencies

```
cognitive/
  ├── api/ (ApiClient)
  ├── config/ (Config)
  ├── token_count/ (estimation)
  └── vector_store/ (embeddings)

config/
  └── Used by all modules

input/
  ├── command_registry/ (slash commands)
  └── Used by agent/, ui/
```

---

## Summary Statistics

| Module | Files | Total Lines | Key Features |
|--------|-------|-------------|--------------|
| cognitive/ | 19 | ~20,000+ | 1M context, hierarchical memory, self-reference |
| config/ | 3 | ~7,200 | TOML config, type safety, secret redaction |
| input/ | 5 | ~2,500 | Autocomplete, highlighting, vim/emacs |

---

## Notable Implementation Details

1. **Thread Safety**: Extensive use of `Arc<RwLock<T>>` for concurrent access
2. **Async/Await**: Tokio-based async throughout
3. **Error Handling**: `anyhow::Result` for error propagation
4. **Serialization**: Serde for JSON/TOML serialization
5. **Tracing**: Comprehensive logging with `tracing` crate
6. **Feature Flags**: Self-improvement gated behind compile-time flags
