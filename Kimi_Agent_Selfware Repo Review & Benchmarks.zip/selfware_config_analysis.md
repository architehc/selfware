
# Selfware Repository - Comprehensive Configuration & Documentation Analysis

## Executive Summary

**Selfware** is an ambitious, well-architected agentic coding framework for local LLMs. The project demonstrates strong engineering practices with ~5,200 tests, ~82% code coverage, feature-flag modularity, and good separation of concerns. The codebase is approximately 193k lines of Rust code across 184 source files and 34 test files.

**Overall Grade: A-** (Excellent foundation with specific areas for improvement)

---

## 1. Cargo.toml - Project Configuration

### Key Configuration Details

**Package Metadata:**
- **Name:** selfware
- **Version:** 0.1.0
- **Edition:** 2021
- **License:** MIT
- **Rust Version:** 1.91 (MSRV)
- **Authors:** Trebuchet Network
- **Homepage:** https://selfware.me
- **Repository:** https://github.com/architehc/selfware
- **Documentation:** https://docs.rs/selfware

**Keywords & Categories:**
- Keywords: ai, agent, local-first, cli, automation
- Categories: command-line-utilities, development-tools

### Core Dependencies

**Async Runtime & Networking:**
- `tokio` (1.43) - Async runtime with multi-threading, sync, time, fs, process features
- `reqwest` (0.13) - HTTP client with JSON, stream, blocking support
- `futures` (0.3) - Async programming utilities
- `async-trait` (0.1) - Async trait support

**Serialization & Data:**
- `serde` (1.0) - Serialization framework with derive feature
- `serde_json` (1.0) - JSON serialization
- `serde_yaml` (0.9) - YAML workflow definitions
- `toml` (1.0) - TOML configuration parsing
- `bincode` (2.0) - Fast binary serialization with serde support

**CLI & TUI:**
- `clap` (4.4) - Command-line argument parsing with derive feature
- `reedline` (0.46) - Modern readline implementation
- `crossterm` (0.29) - Cross-platform terminal manipulation
- `ratatui` (0.30) - Terminal UI framework
- `colored` (3.1) - Terminal color output
- `nu-ansi-term` (0.50) - ANSI terminal colors
- `unicode-width` (0.2) - Unicode character width calculation

**Security & Cryptography:**
- `git2` (0.20) - Git operations (updated for CVE-2024-24575, CVE-2024-24577)
- `sha2` (0.10) - SHA-2 hashing
- `pbkdf2` (0.12) - Password-based key derivation
- `hmac` (0.12) - HMAC authentication
- `aes-gcm` (0.10) - AES-GCM encryption
- `keyring` (3.2) - System keyring access
- `base64` (0.22) - Base64 encoding
- `hex` (0.4) - Hexadecimal encoding
- `zeroize` (1.8.2) - Secure memory clearing

**Search & Analysis:**
- `regex` (1.11) - Regular expressions
- `glob` (0.3) - Glob pattern matching
- `walkdir` (2.4) - Directory traversal
- `hnsw_rs` (0.3) - HNSW vector search
- `nucleo` (0.5) - Fast fuzzy matcher
- `similar` (2.4) - Diff algorithm
- `syntect` (5.2) - Syntax highlighting
- `pulldown-cmark` (0.13) - Markdown parsing

**Observability:**
- `tracing` (0.1) - Structured logging
- `tracing-subscriber` (0.3) - Log subscriber with env-filter, JSON
- `tracing-appender` (0.2.4) - Log appending
- `opentelemetry` (0.21.0) - Distributed tracing
- `opentelemetry_sdk` (0.21.0) - OpenTelemetry SDK with tokio runtime
- `opentelemetry-otlp` (0.14.0) - OTLP exporter
- `tracing-opentelemetry` (0.22.0) - Tracing integration
- `metrics` (0.21.0) - Metrics collection
- `metrics-exporter-prometheus` (0.12.1) - Prometheus exporter

**Utilities:**
- `anyhow` (1.0) - Error handling
- `thiserror` (2.0) - Custom error types
- `chrono` (0.4) - Date/time with serde support
- `uuid` (1.6) - UUID generation with v4 feature
- `tempfile` (3.9) - Temporary files
- `once_cell` (1.19) - Lazy statics
- `tiktoken-rs` (0.9) - Token counting
- `whoami` (2.1) - User information
- `dirs` (6.0) - Directory paths
- `rand` (0.9) - Random number generation
- `url` (2.0) - URL parsing for SSRF protection
- `ctrlc` (3.0) - Ctrl-C handling
- `parking_lot` (0.12.5) - Synchronization primitives
- `lru` (0.16.3) - LRU cache
- `libloading` (0.9.0) - Dynamic library loading
- `sysinfo` (0.38.3) - System information
- `xcap` (0.3) - Screen capture
- `nvml-wrapper` (0.12.0) - NVIDIA GPU monitoring
- `zstd` (0.13.3) - Zstd compression
- `tokenizers` (0.22.2) - Tokenization with hf-hub, http features

**Platform-Specific:**
- `nix` (0.31) - Unix system calls with signal feature (Unix only)

### Feature Flags

**Default:** None

**Optional Features:**
- `tui` - TUI dashboard mode with animations
- `workflows` - Workflow automation and parallel execution
- `resilience` - Self-healing and graceful degradation
- `execution-modes` - Execution control (dry-run, confirm, yolo)
- `cache` - Response caching layer
- `log-analysis` - Log analysis and diagnostics
- `tokens` - Token counting and management
- `self-improvement` - Recursive self-improvement loop
- `hot-reload` - Dynamic library hot-reload (security-sensitive)
- `extras` - Convenience flag enabling all optional modules
- `integration` - Enables integration tests

### Build Configuration

**Library:**
- Name: selfware
- Path: src/lib.rs

**Binary:**
- Name: selfware
- Path: src/main.rs

**Tests:**
- Unit tests: tests/unit/mod.rs
- Integration tests: tests/integration/mod.rs (requires integration feature)

**Examples:**
- basic_chat - Basic chat example
- run_task - Task execution example
- multi_agent - Multi-agent swarm example
- custom_config - Custom configuration example

**Benchmarks:**
- token_processing - Token processing benchmarks

---

## 2. README.md - Project Overview

### Project Description

Selfware is an **agentic coding harness** for local LLMs that runs entirely on user hardware. It provides:

- **54 built-in tools** for file operations, git, cargo, search, shell, analysis
- **Multi-agent swarm** with up to 16 concurrent agents
- **Evolution engine** for recursive self-improvement
- **TUI dashboard** with real-time telemetry
- **Local-first architecture** - no cloud required

### Key Features

**Core Capabilities:**
1. Interactive chat mode (`selfware chat`)
2. Task execution (`selfware run "task"`)
3. Multi-agent swarm (`selfware multi-chat`)
4. Codebase analysis (`selfware analyze`)
5. Digital garden view (`selfware garden`)
6. TUI dashboard (`selfware --tui`)
7. Evolution engine (`selfware evolve`)

**Cognitive Architecture:**
- **PDVR Cycle:** Plan-Do-Verify-Reflect
- Working memory for current plan and context
- Episodic memory for learning from past sessions

**Safety System:**
- Path validation with allowed/denied paths
- Command filtering for dangerous operations
- Protected branches (prevents force-push to main)
- SSRF protection for web requests
- Multi-layer safety: Request → Path Guardian → Command Sentinel → Protected Groves → Execute

### Supported LLM Backends

- **vLLM** - Fast inference, GPU servers
- **Ollama** - Easy setup, any hardware
- **llama.cpp** - GGUF models, minimal dependencies
- **LM Studio** - GUI for Windows/Mac
- **MLX** - Apple Silicon native
- **SGLang** - High throughput, tool calling

### Hardware Requirements

**Recommended Models (Qwen3.5):**
- 0.8B + 2B: 3-9 GB VRAM+RAM
- 4B: 4.5-14 GB
- 9B: 5.5-19 GB
- 27B: 14-54 GB
- 35B-A3B (MoE): 17-70 GB
- 122B-A10B (MoE): 60-245 GB
- 397B-A17B (MoE): 180-810 GB

**GPU Recommendations:**
- H100/A100 80GB: Qwen3-Coder-Next-FP8 (1M context, 90/100 SAB score)
- RTX 5090 (32GB): Qwen3.5-Coder-35B-A3B Q4_K_M (best value)
- RTX 4090/3090 (24GB): Qwen3.5 27B Q4 or LFM2 24B-A2B 4-bit

### Installation Methods

1. **Prebuilt binaries** (Linux, macOS, Windows)
2. **Cargo:** `cargo install selfware`
3. **Build from source:** `cargo build --release --all-features`
4. **Docker:** Multi-stage build with Dockerfile

### CLI Reference

**Commands:**
- `chat` (c) - Interactive chat
- `multi-chat` (m) - Multi-agent swarm
- `run <task>` (r) - Execute task
- `analyze <path>` (a) - Analyze codebase
- `garden` - Digital garden view
- `journal` (j) - Browse checkpoints
- `resume <id>` - Resume from checkpoint
- `status` - Show workshop stats
- `workflow <file>` (w) - Run YAML workflow
- `init` - Setup wizard
- `evolve` - Run evolution engine (requires self-improvement feature)
- `improve` - Self-improvement pass
- `demo` - Animated demo (requires tui feature)
- `dashboard` - Launch TUI dashboard (requires tui feature)

**Global Flags:**
- `-p <PROMPT>` - Headless mode
- `-C <DIR>` - Set working directory
- `-m <MODE>` - Execution mode (normal, auto-edit, yolo, daemon)
- `-y` - Shortcut for --mode=yolo
- `--tui` - Launch TUI dashboard
- `--theme <THEME>` - Color theme (amber, ocean, minimal, high-contrast)
- `--compact` - Dense output
- `-v, --verbose` - Detailed output
- `--show-tokens` - Display token usage
- `--ascii` - ASCII-only output
- `--no-color` - Disable colors

---

## 3. COMPREHENSIVE_PROJECT_REVIEW.md - Architecture Assessment

### Executive Summary

**Overall Grade: A-**
- Excellent foundation with specific areas for improvement
- Strong safety-first design philosophy
- Good modular architecture
- Comprehensive feature set
- Excellent test coverage (~5,200 tests, ~82% line coverage)

### Architecture Strengths

1. **Modular Design:** Clean separation into agent/, tools/, safety/, cognitive/, orchestration/ modules
2. **Feature Flag System:** Well-designed feature gates (tui, resilience, self-improvement, etc.)
3. **PDVR Cycle:** Thoughtful cognitive architecture (Plan-Do-Verify-Reflect)
4. **Plugin Architecture:** Tool registry pattern allows easy extension
5. **Safety-First Design:** Multi-layer safety with path validation, command filtering, sandboxing

### Architecture Concerns

1. **Module Size Imbalance:** Several files exceed 1,500 lines:
   - src/tools/knowledge.rs: 1,537 lines
   - src/ui/animations.rs: 1,503 lines
   - src/session/local_first.rs: 2,527 lines
   - src/ui/garden.rs: 1,206 lines

2. **Deep Module Nesting:** Some paths are excessively deep (src/orchestration/workflow_dsl/)

3. **Circular Dependencies Risk:** cognitive/ and agent/ have tight coupling

### Priority Recommendations

**P0 (Critical):**
- Fix dead_code suppression globally
- Add fuzz testing for safety

**P1 (High):**
- Split oversized modules
- Implement mock LLM for tests
- Add chaos tests

**P2 (Medium):**
- Performance audit
- Documentation improvements

**P3 (Low):**
- API schema validation
- TUI accessibility

### Security Recommendations

1. **Defense in Depth Audit:**
   - Add fuzz testing for path validation and command parsing
   - Sandbox escape testing for Docker/container escapes
   - Expand secret scanning patterns

2. **Command Allowlist Mode:**
   - Add opt-in allowlist mode for high-security environments
   - Current: Blacklist-based command filtering

3. **Supply Chain Security:**
   - Add cargo audit to CI
   - Add cargo deny check advisories
   - Sign releases with codesign

### Testing Strategy

**Current State:**
- ~5,200 tests
- ~82% line coverage
- Integration tests rely heavily on external LLM

**Recommendations:**
1. Create deterministic mock LLM server for CI
2. Expand contract testing for API boundaries
3. Add property-based tests for tools
4. Add performance regression tests
5. Add chaos engineering tests

### Performance Optimizations

**Recommendations:**
1. Memory Usage Audit:
   - Use object pooling for messages
   - Audit Vec allocations

2. Async Optimization:
   - Use tokio::fs for file operations
   - Wrap blocking git operations in spawn_blocking

3. Compilation Time:
   - Enable lto = "thin" in release profile
   - Consider workspace split for evolution/tui features

---

## 4. CONTRIBUTING.md - Contribution Guidelines

### Development Setup

**Prerequisites:**
- Rust 1.85.0 or later (MSRV)
- Git
- Local LLM backend for testing (optional)

**Building:**
```bash
git clone https://github.com/architehc/selfware.git
cd selfware
cargo build
cargo build --all-features
cargo build --release
```

### Code Style

**Formatting & Linting:**
```bash
cargo fmt
cargo clippy --all-targets --all-features -- -D warnings
```

### Branching Strategy

- `main` - Stable release branch
- `develop` - Integration branch for features
- Feature branches: `feature/your-feature-name`
- Bug fixes: `fix/issue-description`

### Commit Messages

**Conventional Commits Format:**
```
type(scope): description

[optional body]

[optional footer]
```

**Types:**
- `feat` - New feature
- `fix` - Bug fix
- `docs` - Documentation only
- `style` - Code style changes
- `refactor` - Code refactoring
- `test` - Adding or updating tests
- `chore` - Maintenance tasks
- `ci` - CI/CD changes

**Examples:**
- `feat(tools): add file_search tool with regex support`
- `fix(safety): prevent path traversal via symlinks`
- `docs(readme): update installation instructions`

### Pull Request Process

1. Fork the repository
2. Create a feature branch from `main`
3. Make your changes
4. Run tests and linting locally
5. Submit a pull request

**PR Requirements:**
- All tests pass
- Clippy passes with no warnings
- Code is formatted with rustfmt
- Documentation is updated if needed
- Commit messages follow convention

### Testing Guidelines

**Unit Tests:**
- Place in same file as code under `#[cfg(test)] mod tests`

**Integration Tests:**
- Place in `tests/` directory

**Test Fixtures:**
- Place in `tests/e2e-projects/`

### Project Structure

```
src/
├── agent/          # Core agent logic, checkpointing, self-healing
├── api/            # LLM API client with timeout and retry
├── tools/          # 54 built-in tool implementations
├── ui/             # CLI UI components, TUI
├── analysis/       # Code analysis, BM25 search, vector store
├── cognitive/      # PDVR cycle, working/episodic memory
├── config/         # Configuration management
├── devops/         # Container support, process manager
├── observability/  # Telemetry and tracing
├── orchestration/  # Multi-agent swarm, planning, workflows
├── safety/         # Path validation, sandboxing, threat modeling
├── self_healing/   # Error classification, recovery executor
├── session/        # Checkpoint persistence
├── testing/        # Verification gates, contract testing
├── memory.rs       # Memory management
├── tool_parser.rs  # Multi-format XML tool call parser
└── token_count.rs  # Token estimation
```

### Adding New Tools

1. Create struct implementing `Tool` trait
2. Register in `src/tools/mod.rs`
3. Add tests in `tests/unit/test_tools.rs`

### Feature Flags

**Available Flags:**
- `tui` - TUI dashboard mode
- `workflows` - Workflow automation
- `resilience` - Self-healing, error classification
- `execution-modes` - Execution control
- `cache` - Response caching
- `log-analysis` - Log analysis
- `tokens` - Token counting
- `extras` - All optional modules
- `integration` - Integration tests

---

## 5. SECURITY.md - Security Policy

### Supported Versions

- **0.1.x:** ✅ Supported

### Security Features

**Path Validation:**
- All file operations validated against allowed paths
- Symlink traversal attacks detected
- System paths (/etc, /usr, etc.) protected by default

**Command Filtering:**
- Dangerous shell commands blocked (e.g., rm -rf /, mkfs)
- Command injection patterns detected
- Protected branch restrictions for git operations

**Safe Defaults:**
- YOLO mode disabled by default
- Force push to main/master requires explicit configuration
- Sensitive paths (.env, .ssh, .aws) denied by default

### Reporting a Vulnerability

**DO NOT** open a public issue. Instead:
- Email security concerns to maintainers
- Include: Description, steps to reproduce, potential impact, suggested fix

**Response Timeline:**
- Acknowledgment: Within 48 hours
- Initial Assessment: Within 1 week
- Fix Timeline: Depends on severity

---

## 6. CHANGELOG.md - Project Evolution

### Version 0.1.0 (2026-02-13)

**Initial Release:**
- Core agent framework with PDVR cognitive cycle
- 53 built-in tools for file operations, git, cargo, search
- Safety system with path validation and command filtering
- Checkpoint system for task persistence
- Multi-agent collaboration support
- TUI mode with ratatui (feature-gated)
- Garden visualization for codebase health
- Support for multiple LLM backends (vLLM, Ollama, llama.cpp, LM Studio)
- YOLO mode for autonomous operation
- Workflow DSL for complex task automation

**Security:**
- Path traversal protection
- Dangerous command blocking
- Protected paths system
- Git force push prevention

### Unreleased Changes

**Added:**
- TUI dashboard mode with real-time telemetry display
- Event infrastructure for agent-TUI communication (TuiEvent, SharedDashboardState)
- Dependabot configuration for automated dependency updates
- Codecov integration for coverage tracking
- Release notes categorization template
- Docker support with multi-stage build
- Examples directory with 4 usage examples
- 53 new tests for agent module
- 24 new tests for API client
- Self-healing recovery system with ErrorClass classification
- Exponential backoff with jitter for retry actions
- Automatic escalation chains
- Per-pattern retry state tracking
- E2E system test harness with 7 scenarios
- ANSI terminal capture via script for screenshots
- Scored E2E reports with error analysis
- LlmClient trait abstraction for testable API interactions
- Drop implementation for ProcessManager
- Configurable API request timeout (default 120s)
- Swarm access log capped at 10,000 entries
- spawn_blocking wrapper for file search operations

**Changed:**
- CI workflow now runs tests with --all-features
- Switched to taiki-e/install-action for faster cargo tool installation
- Added caching to release workflow builds
- Coverage job now runs on all branches
- Recovery counter now increments before attempt
- handle_error() in SelfHealingEngine now classifies errors

**Fixed:**
- Repository URLs in Cargo.toml and README.md
- Recovery counter bug
- uuid_v4() in self-healing now uses proper UUID
- Unicode width calculation in agent avatar
- partial_cmp unwrap replaced with unwrap_or
- from_utf8_lossy unnecessary allocations
- Substring path matching in contract testing
- ArrayContaining matcher logic

**Security:**
- Updated CI to include security audit job
- Hardened shell command validation with regex-based matching
- Fixed path traversal bypass via canonical path validation
- Added symlink chain validation
- Added detection for base64-encoded command execution
- Added command chaining detection
- Added netcat reverse shell pattern detection
- Added eval with command substitution detection

---

## 7. deny.toml - Dependency Security Configuration

### cargo-deny Configuration

**Purpose:** Security and license compliance for dependencies

**Target Platforms:**
- x86_64-unknown-linux-gnu
- x86_64-apple-darwin
- aarch64-apple-darwin
- x86_64-pc-windows-msvc

**Advisory Database:**
- Source: https://github.com/rustsec/advisory-db
- Path: ~/.cargo/advisory-db

**Ignored Advisories (transitive dependencies without safe upgrade):**
- RUSTSEC-2025-0141: bincode 1.3.3 (pulled by hnsw_rs, syntect)
- RUSTSEC-2024-0320: yaml-rust 0.4.5 (pulled by syntect)
- RUSTSEC-2025-0119: number_prefix 0.4.0 (pulled by indicatif)
- RUSTSEC-2024-0436: paste 1.0.15 (pulled by tokenizers)

**Policy:**
- Unmaintained crates: Treat as errors (all)
- Yanked crates: Deny

**Allowed Licenses:**
- MIT
- Apache-2.0
- Apache-2.0 WITH LLVM-exception
- BSD-2-Clause, BSD-3-Clause
- ISC, Zlib, MPL-2.0
- Unicode-DFS-2016, Unicode-3.0
- OpenSSL, CC0-1.0
- CDLA-Permissive-2.0, Unlicense

**License Confidence Threshold:** 0.8

**Bans:**
- Multiple versions: Warn
- Wildcards: Allow

**Sources:**
- Unknown registry: Warn
- Unknown git: Warn
- Allowed registry: crates.io-index only

---

## 8. .tarpaulin.toml - Test Coverage Configuration

### Coverage Settings

**Fail-under Threshold:** 80% of testable code

**Output Formats:**
- HTML
- Stdout
- XML

**Coverage Types:**
- Line coverage: Enabled
- Branch coverage: Enabled

**Excluded Files (non-testable code):**
- src/main.rs - CLI entry point
- system_tests/* - Test fixtures
- src/ui/* - TUI rendering (requires terminal/display)
- src/agent/interactive.rs - Interactive REPL
- src/cli.rs - CLI argument parsing
- src/input/mod.rs - Terminal input handling
- src/resource/* - System resource monitors
- src/output/* - Terminal output formatting
- src/tools/screen_capture.rs - Screen capture (needs display)
- src/tools/hot_reload.rs - Hot reload (requires dev servers)
- src/evolution/sandbox.rs - Evolution sandbox (requires Docker/chroot)
- src/evolution/tournament.rs - Evolution tournament (multi-process)

---

## 9. Selfware Configuration Files

### selfware.toml (Main Configuration)

**Endpoint Configuration:**
- endpoint: https://crazyshit.ngrok.io/v1 (OpenAI-compatible API)
- model: Qwen/Qwen3-Coder-Next-FP8
- max_tokens: 98304

**Safety Settings:**
- allowed_paths: ["./**", "~/**"]
- denied_paths: ["**/.env", "**/secrets/**", "**/.ssh/**", "**/target/**"]

**Agent Settings:**
- max_iterations: 500
- step_timeout_secs: 600 (10 minutes)
- native_function_calling: true

**Continuous Work:**
- enabled: true
- checkpoint_interval_tools: 10
- checkpoint_interval_secs: 300 (5 minutes)
- auto_recovery: true
- max_recovery_attempts: 3

**Retry Settings:**
- max_retries: 5
- base_delay_ms: 1000
- max_delay_ms: 60000 (1 minute)

**Evolution Settings:**
- prompt_logic: List of source files for prompt construction
- tool_code: List of source files for tool implementations
- cognitive: List of source files for cognitive architecture
- config_keys: ["temperature", "max_tokens", "token_budget"]

### selfware-eval.toml (Evaluation Configuration)

**Purpose:** 5 long-running tasks (~2h each) against ngrok endpoint

**Key Differences from Main Config:**
- max_iterations: 2000
- token_budget: 900000
- native_function_calling: false
- streaming: true
- YOLO mode enabled with 3-hour max
- max_recovery_attempts: 5
- max_retries: 10
- max_delay_ms: 120000 (2 minutes)

### selfware-extended-test.toml (Extended Test Configuration)

**Purpose:** Multi-hour test sessions (up to 4 hours)

**Key Settings:**
- step_timeout_secs: 1800 (30 minutes)
- token_budget: 500000
- YOLO mode: max_hours: 4.0
- allow_git_push: false
- audit_log_path: /tmp/selfware-extended-audit.log

### selfware-longrun.toml (Long-Running Configuration)

**Purpose:** 6+ hour autonomous runs

**Key Settings:**
- max_tokens: 198304
- max_iterations: 2000
- token_budget: 1000000
- YOLO mode: max_hours: 8.0
- status_interval: 50 (print status every 50 ops)

### selfware.example.toml (Example Configuration)

**Purpose:** Template for users to copy and customize

**Default Settings:**
- endpoint: http://localhost:8080/v1
- model: your-model-name-here
- Standard safety, agent, continuous work, and retry settings

---

## 10. Project Architecture Summary

### Module Organization

**Core Modules:**
- **agent/** - Agent loop, checkpointing, execution control
- **api/** - LLM client with timeout, retry, streaming
- **tools/** - 54 tool implementations
- **safety/** - Path validation, command filtering, sandboxing

**Cognitive Modules:**
- **cognitive/** - PDVR cycle, memory hierarchy, RAG
- **memory.rs** - Memory management
- **token_count.rs** - Token estimation

**UI Modules:**
- **ui/** - CLI components, themes, animations
- **ui/tui/** - Full ratatui dashboard

**Orchestration Modules:**
- **orchestration/** - Multi-agent swarm, planning, workflows

**Infrastructure Modules:**
- **config/** - Configuration management
- **observability/** - Tracing, metrics, logging
- **session/** - Checkpoint persistence
- **self_healing/** - Error recovery, resilience
- **evolution/** - Self-improvement engine (feature-gated)

### Key Abstractions

- **Agent:** Main execution loop coordinating LLM calls and tool execution
- **Tool:** Interface for implementing new tools (54 built-in)
- **SafetyChecker:** Validates operations before execution
- **SelfHealingEngine:** Error classification, recovery strategies
- **Config:** Runtime configuration management

### Safety Architecture

**Multi-Layer Safety:**
1. Path Guardian - Path validation
2. Command Sentinel - Command filtering
3. Protected Groves - Protected branches/paths
4. Execution - Final safety check before execution

**Safety Features:**
- Allowed/denied path globs
- Symlink traversal detection
- Command injection detection
- Protected branch restrictions
- SSRF protection

### Testing Architecture

**Test Organization:**
- Unit tests: In-file under #[cfg(test)]
- Integration tests: tests/ directory
- E2E tests: system_tests/projecte2e/
- Property tests: tests/prop_*.rs

**Coverage:**
- ~5,200 tests
- ~82% line coverage
- 80% coverage threshold enforced

---

## 11. Recommendations Summary

### Immediate Actions (P0)

1. **Fix dead_code suppression** - Remove global #![allow(dead_code)] and fix individual warnings
2. **Add fuzz testing** - Use cargo-fuzz for path validation and command parsing

### High Priority (P1)

1. **Split oversized modules** - Files >1,500 lines should be refactored
2. **Implement mock LLM server** - For deterministic CI testing
3. **Add chaos tests** - Verify recovery from panics and failures

### Medium Priority (P2)

1. **Performance audit** - Memory usage, async optimization, compilation time
2. **Documentation improvements** - ADRs, inline docs for complex algorithms

### Low Priority (P3)

1. **API schema validation** - Use schemars for compile-time schema validation
2. **TUI accessibility** - Screen reader support, colorblind-friendly palettes

---

## 12. Conclusion

Selfware is an impressive piece of engineering with a solid foundation. The project demonstrates:

**Strengths:**
- Strong safety-first design philosophy
- Good modular architecture
- Comprehensive feature set (54 tools, multi-agent swarm, evolution engine)
- Excellent test coverage (~5,200 tests, ~82% coverage)
- Active maintenance and development

**Areas for Focus:**
- Code organization (split oversized modules)
- Security hardening (fuzz testing, command allowlists)
- Testing (mock LLM server, chaos tests)
- Documentation (ADRs, inline docs)

**Production Readiness:**
The project is production-ready for its intended use case (local LLM coding assistant). The evolution engine is an experimental but promising feature that needs continued hardening.

**Recommended Next Steps:**
1. Address P0 items immediately
2. Create roadmap for module refactoring
3. Establish security audit cadence (quarterly)
4. Consider forming a security review board for evolution feature

---

*Analysis completed by Code Explorer Agent*
*Files reviewed: 10 configuration/documentation files*
*Repository: https://github.com/architehc/selfware*
