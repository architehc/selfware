# Beginner Level Rust Code Understanding Benchmarks

## Overview
These benchmarks test visual language models' ability to understand basic Rust code patterns, syntax, and concepts. Designed for localhost testing against Qwen3.5 models.

**Difficulty Level:** Beginner (1-4 on a 1-10 scale)
**Target:** Basic Rust comprehension, syntax recognition, and simple analysis

---

## Benchmark 1: Struct and Enum Recognition

### Task Name
Basic Type Definition Analysis

### Description
Test the model's ability to identify and explain Rust struct and enum definitions, including their fields and purposes.

### Sample Code
```rust
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Represents a single key-value entry in the store
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Entry {
    pub key: String,
    pub value: String,
    pub tags: Vec<String>,
    pub metadata: HashMap<String, String>,
}

/// Error types for key-value store operations
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum KvStoreError {
    KeyNotFound(String),
    KeyAlreadyExists(String),
    StorageError(String),
    SerializationError(String),
}
```

### Questions
1. What is the name of the struct defined in this code?
2. How many fields does the `Entry` struct have? List them with their types.
3. What is the purpose of the `#[derive(...)]` attribute on the `Entry` struct?
4. What enum is defined and what are its variants?
5. Which variant of `KvStoreError` would be appropriate when a requested key doesn't exist in the store?

### Expected Output Format
```
1. [Struct name]
2. [Number] fields: [field1: type1], [field2: type2], ...
3. [Explanation of derive macros]
4. [Enum name] with variants: [variant1], [variant2], ...
5. [Correct variant name]
```

### Evaluation Criteria
| Question | Points | Correct Answer |
|----------|--------|----------------|
| 1 | 1 | Entry |
| 2 | 2 | 4 fields: key: String, value: String, tags: Vec<String>, metadata: HashMap<String, String> |
| 3 | 2 | Automatically implements Debug, Clone, Serialize, Deserialize traits |
| 4 | 2 | KvStoreError with 4 variants: KeyNotFound, KeyAlreadyExists, StorageError, SerializationError |
| 5 | 1 | KeyNotFound |
| **Total** | **8** | |

### Scoring
- 8/8: Excellent - Perfect understanding
- 6-7/8: Good - Minor gaps
- 4-5/8: Fair - Some understanding
- <4/8: Needs improvement

### Difficulty Rating
**2/10** - Basic syntax recognition

---

## Benchmark 2: Function Purpose and Behavior

### Task Name
Function Comprehension

### Description
Test the model's ability to understand what functions do based on their implementation, including error handling patterns.

### Sample Code
```rust
impl Entry {
    pub fn new(key: impl Into<String>, value: impl Into<String>) -> Self {
        Self {
            key: key.into(),
            value: value.into(),
            tags: Vec::new(),
            metadata: HashMap::new(),
        }
    }

    pub fn with_tags(mut self, tags: Vec<String>) -> Self {
        self.tags = tags;
        self
    }

    pub fn add_tag(&mut self, tag: impl Into<String>) {
        self.tags.push(tag.into());
    }

    pub fn has_tag(&self, tag: &str) -> bool {
        self.tags.iter().any(|t| t == tag)
    }

    pub fn get_metadata(&self, key: &str) -> Option<&String> {
        self.metadata.get(key)
    }
}
```

### Questions
1. What does the `new` function do? What pattern does it follow?
2. What is the difference between `with_tags` and `add_tag` methods?
3. What does `has_tag` return if the entry has no tags at all?
4. What does `get_metadata` return if the key doesn't exist in metadata?
5. Which methods take `&mut self` vs `&self`? Why?

### Expected Output Format
```
1. [Description of new function and pattern name]
2. [Difference explanation]
3. [Return value for empty tags]
4. [Return value for missing key]
5. Mutable: [list], Immutable: [list]. Reason: [explanation]
```

### Evaluation Criteria
| Question | Points | Correct Answer |
|----------|--------|----------------|
| 1 | 2 | Creates a new Entry; follows the builder/constructor pattern |
| 2 | 2 | `with_tags` replaces all tags (consumes self), `add_tag` appends one tag (mutates) |
| 3 | 1 | false |
| 4 | 1 | None |
| 5 | 2 | &mut self: with_tags, add_tag (need to modify); &self: new, has_tag, get_metadata (read-only) |
| **Total** | **8** | |

### Scoring
- 8/8: Excellent
- 6-7/8: Good
- 4-5/8: Fair
- <4/8: Needs improvement

### Difficulty Rating
**3/10** - Basic function analysis

---

## Benchmark 3: Cargo.toml Dependencies Reading

### Task Name
Dependency Analysis

### Description
Test the model's ability to read and understand Cargo.toml configuration and dependencies.

### Sample Code (Cargo.toml)
```toml
[package]
name = "selfware"
version = "0.1.0"
edition = "2021"
license = "MIT"
description = "Your personal AI workshop"
rust-version = "1.91"

[dependencies]
tokio = { version = "1.43", features = ["rt-multi-thread", "macros", "sync", "time"] }
anyhow = "1.0"
serde = { version = "1.0", features = ["derive"] }
reqwest = { version = "0.13", features = ["json", "stream"] }
clap = { version = "4.4", features = ["derive"] }
tracing = "0.1"
chrono = { version = "0.4", features = ["serde"] }
uuid = { version = "1.6", features = ["v4"] }

[dev-dependencies]
tokio-test = "0.4"
criterion = { version = "0.8", features = ["html_reports"] }

[features]
default = []
tui = []
workflows = []
resilience = []
```

### Questions
1. What is the minimum Rust version required to build this project?
2. Which crate is used for async runtime and what features are enabled?
3. What is the difference between `[dependencies]` and `[dev-dependencies]`?
4. Which crate provides derive macros for serialization?
5. How would you enable the "tui" feature when building this project?
6. Which dependency is used for command-line argument parsing?

### Expected Output Format
```
1. [Rust version]
2. [Crate name] with features: [list]
3. [Explanation of difference]
4. [Crate name]
5. [Build command]
6. [Crate name]
```

### Evaluation Criteria
| Question | Points | Correct Answer |
|----------|--------|----------------|
| 1 | 1 | 1.91 |
| 2 | 2 | tokio with rt-multi-thread, macros, sync, time |
| 3 | 2 | dependencies: required for building/running; dev-dependencies: only for tests/benchmarks |
| 4 | 1 | serde |
| 5 | 2 | `cargo build --features tui` or `cargo build --features selfware/tui` |
| 6 | 1 | clap |
| **Total** | **9** | |

### Scoring
- 9/9: Excellent
- 7-8/9: Good
- 5-6/9: Fair
- <5/9: Needs improvement

### Difficulty Rating
**2/10** - Configuration reading

---

## Benchmark 4: Error Handling with Result and Option

### Task Name
Error Handling Pattern Recognition

### Description
Test the model's understanding of Rust's error handling types (Result, Option) and common patterns.

### Sample Code
```rust
pub type Result<T> = std::result::Result<T, KvStoreError>;

impl KvStore {
    pub fn get(&self, key: &str) -> Result<String> {
        match self.data.get(key) {
            Some(entry) => Ok(entry.value.clone()),
            None => Err(KvStoreError::KeyNotFound(key.to_string())),
        }
    }

    pub fn contains_key(&self, key: &str) -> bool {
        self.data.contains_key(key)
    }

    pub fn remove(&mut self, key: &str) -> Result<String> {
        match self.data.remove(key) {
            Some(entry) => {
                let value = entry.value.clone();
                if let Some(ref path) = self.path {
                    self.save()?;
                }
                Ok(value)
            }
            None => Err(KvStoreError::KeyNotFound(key.to_string())),
        }
    }

    pub fn get_entry(&self, key: &str) -> Result<&Entry> {
        self.data.get(key).ok_or_else(|| {
            KvStoreError::KeyNotFound(key.to_string())
        })
    }
}
```

### Questions
1. What is the return type of `get` and what does each variant represent?
2. What happens in `remove` if `self.path` is `None`?
3. What does the `?` operator do in `self.save()?`?
4. Rewrite `get_entry` using `match` instead of `ok_or_else`.
5. If `contains_key("foo")` returns `true`, what will `get("foo")` return?

### Expected Output Format
```
1. [Return type explanation]
2. [Behavior when path is None]
3. [Explanation of ? operator]
4. ```rust
   [Rewritten code]
   ```
5. [Expected return value]
```

### Evaluation Criteria
| Question | Points | Correct Answer |
|----------|--------|----------------|
| 1 | 2 | Result<String>: Ok contains the value, Err contains KvStoreError |
| 2 | 2 | The save() call is skipped, function continues and returns Ok(value) |
| 3 | 2 | Unwraps Ok or returns Err early from the function |
| 4 | 2 | Correct match-based implementation |
| 5 | 1 | Ok(the_value) or Ok(entry.value.clone()) |
| **Total** | **9** | |

### Scoring
- 9/9: Excellent
- 7-8/9: Good
- 5-6/9: Fair
- <5/9: Needs improvement

### Difficulty Rating
**4/10** - Error handling concepts

---

## Benchmark 5: Basic Code Pattern Identification

### Task Name
Common Rust Pattern Recognition

### Description
Test the model's ability to identify common Rust patterns and idioms in code.

### Sample Code
```rust
#[tokio::main]
async fn main() -> Result<()> {
    let config = Config::load(None)?;
    
    let client = ApiClient::new(&config)?;
    
    let messages = vec![
        Message::system("You are a helpful assistant."),
        Message::user("Hello!"),
    ];
    
    let response = client.chat(messages, None, ThinkingMode::Disabled).await?;
    let answer = &response.choices[0].message.content;
    
    println!("Response: {}", answer);
    
    Ok(())
}

impl Default for KvStore {
    fn default() -> Self {
        Self::new()
    }
}

impl std::fmt::Display for KvStoreError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            KvStoreError::KeyNotFound(key) => write!(f, "Key not found: {}", key),
            KvStoreError::StorageError(msg) => write!(f, "Storage error: {}", msg),
            _ => write!(f, "Unknown error"),
        }
    }
}
```

### Questions
1. What does `#[tokio::main]` do and why is the `main` function marked `async`?
2. What pattern does `impl Default for KvStore` implement? Why is this useful?
3. What trait is being implemented in the second `impl` block and what method does it require?
4. What does the `_` pattern mean in the match arm `_ => write!(f, "Unknown error")`?
5. What would happen if we removed `.await` from `client.chat(...).await?`?

### Expected Output Format
```
1. [Explanation of tokio::main and async main]
2. [Pattern name and usefulness]
3. [Trait name and required method]
4. [Explanation of _ pattern]
5. [Compilation error explanation]
```

### Evaluation Criteria
| Question | Points | Correct Answer |
|----------|--------|----------------|
| 1 | 2 | Sets up tokio runtime; async allows using await inside main |
| 2 | 2 | Default trait; allows KvStore::default() and use with #[derive(Default)] |
| 3 | 2 | Display trait; requires fmt method |
| 4 | 1 | Wildcard pattern that matches any remaining variants |
| 5 | 2 | Compilation error: can't use ? on Future, need to await first |
| **Total** | **9** | |

### Scoring
- 9/9: Excellent
- 7-8/9: Good
- 5-6/9: Fair
- <5/9: Needs improvement

### Difficulty Rating
**3/10** - Pattern recognition

---

## Summary

| Benchmark | Topic | Questions | Total Points | Difficulty |
|-----------|-------|-----------|--------------|------------|
| 1 | Struct/Enum Recognition | 5 | 8 | 2/10 |
| 2 | Function Comprehension | 5 | 8 | 3/10 |
| 3 | Cargo.toml Reading | 6 | 9 | 2/10 |
| 4 | Error Handling | 5 | 9 | 4/10 |
| 5 | Pattern Recognition | 5 | 9 | 3/10 |
| **Total** | | **26** | **43** | |

## Running the Benchmarks

### Prerequisites
- Local Qwen3.5 model running (via vLLM, Ollama, or similar)
- Python test runner script

### Example Test Script
```python
# test_benchmark.py
import requests
import json

def query_model(prompt, model="Qwen/Qwen3.5-Coder"):
    response = requests.post(
        "http://localhost:8000/v1/chat/completions",
        json={
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0
        }
    )
    return response.json()["choices"][0]["message"]["content"]

def run_benchmark(benchmark_num, code, questions):
    prompt = f"""Analyze this Rust code and answer the questions:

```rust
{code}
```

Questions:
{questions}

Provide clear, concise answers."""
    
    return query_model(prompt)

# Run benchmarks
for i, bench in enumerate(benchmarks, 1):
    result = run_benchmark(i, bench["code"], bench["questions"])
    print(f"Benchmark {i} Result:\n{result}\n")
```

## Evaluation Rubric

### Overall Score Interpretation
- **90-100%**: Expert level - Model fully understands beginner Rust
- **70-89%**: Proficient - Good understanding with minor gaps
- **50-69%**: Developing - Basic understanding, needs improvement
- **<50%**: Novice - Significant gaps in Rust comprehension

### Partial Credit Guidelines
- Answers showing correct concept but wrong syntax: 50% credit
- Answers with right idea but incomplete: 75% credit
- Completely wrong answers: 0% credit
