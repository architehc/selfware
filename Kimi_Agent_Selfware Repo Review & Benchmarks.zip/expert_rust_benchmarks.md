# Expert-Level Rust Code Understanding Benchmarks

> **Target Models**: Qwen3.5 (localhost testing)  
> **Difficulty**: Expert (Mastery Level)  
> **Based on**: Selfware Repository Analysis

---

## Benchmark 1: Zero-Cost Abstractions & Optimization Analysis

### Task Name
**ZCA-001: Iterator Optimization Deep Dive**

### Difficulty Rating
**9/10**

### Description
Test the model's ability to identify zero-cost abstraction opportunities, analyze LLVM optimization boundaries, and suggest performance improvements in complex iterator chains.

### Sample Code Snippet

```rust
use rayon::prelude::*;
use std::collections::HashMap;
use std::sync::atomic::{AtomicUsize, Ordering};

/// A data processing pipeline with potential optimization issues
pub struct DataPipeline<T> {
    data: Vec<T>,
    transformers: Vec<Box<dyn Fn(T) -> T + Send + Sync>>,
    filters: Vec<Box<dyn Fn(&T) -> bool + Send + Sync>>,
}

impl<T: Clone + Send + Sync + 'static> DataPipeline<T> {
    pub fn new(data: Vec<T>) -> Self {
        Self {
            data,
            transformers: Vec::new(),
            filters: Vec::new(),
        }
    }

    pub fn add_transform<F>(&mut self, f: F)
    where
        F: Fn(T) -> T + Send + Sync + 'static,
    {
        self.transformers.push(Box::new(f));
    }

    pub fn add_filter<F>(&mut self, f: F)
    where
        F: Fn(&T) -> bool + Send + Sync + 'static,
    {
        self.filters.push(Box::new(f));
    }

    /// Execute the pipeline - CONTAINS OPTIMIZATION ISSUES
    pub fn execute(&self) -> Vec<T> {
        let counter = AtomicUsize::new(0);
        
        self.data
            .iter()
            .cloned()
            .filter(|item| {
                counter.fetch_add(1, Ordering::Relaxed);
                self.filters.iter().all(|f| f(item))
            })
            .map(|item| {
                self.transformers.iter().fold(item, |acc, f| f(acc))
            })
            .collect()
    }

    /// Parallel execution - CONTAINS OPTIMIZATION ISSUES
    pub fn execute_par(&self) -> Vec<T> {
        self.data
            .par_iter()
            .cloned()
            .filter(|item| self.filters.iter().all(|f| f(item)))
            .map(|item| {
                self.transformers.iter().fold(item, |acc, f| f(acc))
            })
            .collect()
    }
}

/// Aggregation with potential allocation issues
pub fn aggregate_results<K, V>(items: &[(K, V)]) -> HashMap<K, Vec<V>>
where
    K: std::hash::Hash + Eq + Clone,
    V: Clone,
{
    let mut result = HashMap::new();
    
    for (k, v) in items {
        result.entry(k.clone()).or_insert_with(Vec::new).push(v.clone());
    }
    
    result
}

/// SIMD-friendly data layout vs cache-friendly layout
#[repr(C)]
pub struct AoS {
    pub x: f64,
    pub y: f64,
    pub z: f64,
    pub w: f64,
}

#[repr(C)]
pub struct SoA {
    pub x: Vec<f64>,
    pub y: Vec<f64>,
    pub z: Vec<f64>,
    pub w: Vec<f64>,
}

impl SoA {
    /// Process with potential vectorization barriers
    pub fn process(&self, output: &mut [f64]) {
        for i in 0..self.x.len().min(output.len()) {
            output[i] = (self.x[i] * self.x[i] 
                + self.y[i] * self.y[i] 
                + self.z[i] * self.z[i]).sqrt();
        }
    }
}
```

### Questions

1. **Identify all zero-cost abstraction violations** in the `execute()` method. What prevents LLVM from optimizing the iterator chain effectively?

2. **Analyze the parallel execution**: Why might `execute_par()` have worse performance than `execute()` for small datasets? What is the specific rayon overhead being introduced?

3. **Memory layout optimization**: Compare `AoS` vs `SoA` for the following access patterns:
   - Sequential access to all fields of each element
   - Random access to single field across elements
   - SIMD vectorized operations

4. **Allocation optimization**: Rewrite `aggregate_results` to minimize allocations using `HashMap::with_capacity` and iterator hints.

5. **SIMD barriers**: Identify what prevents auto-vectorization in `SoA::process()` and suggest fixes using `#[repr(align(32))]` or `std::simd`.

### Expected Output Format

```json
{
  "benchmark_id": "ZCA-001",
  "issues_identified": [
    {
      "location": "execute() line X",
      "issue": "description",
      "optimization": "suggested fix",
      "llvm_barrier": "specific barrier"
    }
  ],
  "simd_analysis": {
    "aos_vs_soa": "explanation",
    "vectorization_barriers": ["list"],
    "fixes": ["suggestions"]
  },
  "optimized_code": "rewritten code snippet"
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Iterator fusion detection | 20 | Identifies that dyn Fn prevents inlining |
| Atomic overhead recognition | 15 | Spots unnecessary AtomicUsize in sequential code |
| Parallel overhead analysis | 15 | Explains rayon thread pool overhead vs benefit |
| Memory layout expertise | 20 | Correctly analyzes AoS vs SoA tradeoffs |
| SIMD barrier identification | 20 | Identifies alignment and loop issues |
| Allocation optimization | 10 | Suggests with_capacity and reserve |

**Scoring**: 
- 90-100: Expert-level understanding
- 70-89: Advanced understanding with minor gaps
- 50-69: Intermediate, misses key optimizations
- <50: Basic understanding

---

## Benchmark 2: Complex Async Architecture with Cancellation

### Task Name
**ASYNC-002: Hierarchical Task Cancellation System**

### Difficulty Rating
**10/10**

### Description
Design and analyze a complex async system with proper cancellation token propagation, graceful shutdown, and resource cleanup across task hierarchies.

### Sample Code Snippet

```rust
use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll};
use tokio::sync::{mpsc, RwLock};
use tokio_util::sync::CancellationToken;

/// A hierarchical task manager with cancellation support
pub struct TaskManager {
    root_token: CancellationToken,
    tasks: Arc<RwLock<Vec<TaskHandle>>>,
    shutdown_tx: mpsc::Sender<ShutdownCommand>,
}

#[derive(Debug, Clone)]
pub struct TaskHandle {
    id: String,
    parent_id: Option<String>,
    token: CancellationToken,
    abort_handle: tokio::task::AbortHandle,
}

#[derive(Debug)]
pub enum ShutdownCommand {
    Graceful { timeout_ms: u64 },
    Immediate,
    Cascade { task_id: String },
}

/// Custom future that handles cancellation properly
pub struct CancellableFuture<F> {
    inner: F,
    token: CancellationToken,
    cleanup: Option<Box<dyn FnOnce() + Send>>,
}

impl<F: Future> Future for CancellableFuture<F> {
    type Output = Option<F::Output>;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        // IMPLEMENTATION HAS ISSUES
        if self.token.is_cancelled() {
            if let Some(cleanup) = self.cleanup.take() {
                cleanup();
            }
            return Poll::Ready(None);
        }

        unsafe {
            let inner = Pin::new_unchecked(&mut self.inner);
            match inner.poll(cx) {
                Poll::Ready(v) => Poll::Ready(Some(v)),
                Poll::Pending => Poll::Pending,
            }
        }
    }
}

/// Resource guard with async cleanup
pub struct AsyncResourceGuard<R> {
    resource: Option<R>,
    cleanup_tx: mpsc::Sender<R>,
}

impl<R> AsyncResourceGuard<R> {
    pub async fn release(mut self) {
        if let Some(resource) = self.resource.take() {
            let _ = self.cleanup_tx.send(resource).await;
        }
    }
}

impl<R> Drop for AsyncResourceGuard<R> {
    fn drop(&mut self) {
        // ISSUE: This is problematic for async resources
        if let Some(resource) = self.resource.take() {
            // Cannot await in drop - what do we do?
        }
    }
}

/// Stream processor with backpressure and cancellation
pub struct StreamProcessor<T> {
    input: mpsc::Receiver<T>,
    output: mpsc::Sender<T>,
    token: CancellationToken,
    buffer_size: usize,
    in_flight: Arc<RwLock<Vec<tokio::task::JoinHandle<()>>>>,
}

impl<T: Send + 'static> StreamProcessor<T> {
    pub async fn run(&mut self) {
        loop {
            tokio::select! {
                biased;
                
                _ = self.token.cancelled() => {
                    // ISSUE: In-flight tasks may be orphaned
                    break;
                }
                
                Some(item) = self.input.recv() => {
                    let output = self.output.clone();
                    let token = self.token.child_token();
                    
                    let handle = tokio::spawn(async move {
                        tokio::select! {
                            _ = token.cancelled() => {}
                            _ = process_and_send(item, output) => {}
                        }
                    });
                    
                    self.in_flight.write().await.push(handle);
                }
                
                else => break,
            }
        }
    }
}

async fn process_and_send<T>(item: T, output: mpsc::Sender<T>) {
    let _ = output.send(item).await;
}

/// Timeout wrapper with proper cleanup
pub struct TimeoutWrapper<F> {
    inner: F,
    timeout: std::time::Duration,
    on_timeout: Box<dyn FnOnce() + Send>,
}

impl<F: Future> Future for TimeoutWrapper<F> {
    type Output = Result<F::Output, TimeoutError>;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        // IMPLEMENTATION MISSING - WHAT ARE THE CHALLENGES?
        todo!("Implement proper timeout with cleanup")
    }
}

#[derive(Debug)]
pub struct TimeoutError;

/// Structured concurrency pattern
pub struct Scope<'scope> {
    token: CancellationToken,
    tasks: Vec<tokio::task::JoinHandle<()>>,
    _marker: std::marker::PhantomData<&'scope ()>,
}

impl<'scope> Scope<'scope> {
    pub fn spawn<F>(&mut self, f: F) 
    where
        F: Future + Send + 'scope,
        F::Output: Send,
    {
        // How do we ensure all tasks complete before scope exits?
    }
}
```

### Questions

1. **Cancellation safety**: The `CancellableFuture` has soundness issues. Identify the `unsafe` block problems and explain how to properly implement cancellation-safe futures using `pin_project`.

2. **Async Drop problem**: The `AsyncResourceGuard` demonstrates the async drop problem. Design a solution using `async_drop` crate patterns or scope guards with cleanup tasks.

3. **Structured concurrency**: Implement proper structured concurrency where all spawned tasks must complete before the scope exits, with proper error propagation.

4. **Orphaned task prevention**: In `StreamProcessor::run()`, in-flight tasks may be orphaned on cancellation. Design a solution that properly awaits all in-flight tasks with a timeout.

5. **Token hierarchy**: Design a cancellation token hierarchy where cancelling a parent cascades to children, but child cancellation doesn't affect siblings or parent.

### Expected Output Format

```json
{
  "benchmark_id": "ASYNC-002",
  "soundness_issues": [
    {
      "location": "CancellableFuture::poll",
      "issue": "Pin projection unsoundness",
      "fix": "Use pin_project! macro",
      "explanation": "detailed explanation"
    }
  ],
  "async_drop_solution": {
    "approach": "description",
    "code": "implementation",
    "tradeoffs": ["list"]
  },
  "structured_concurrency": {
    "implementation": "code",
    "guarantees": ["list of guarantees"]
  },
  "orphaned_task_solution": "explanation and code"
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Pin projection safety | 20 | Identifies unsoundness, suggests pin_project |
| Async drop patterns | 20 | Designs proper async cleanup solution |
| Structured concurrency | 20 | Implements scope-based task management |
| Cancellation propagation | 15 | Designs proper token hierarchy |
| Orphaned task handling | 15 | Prevents task leaks on shutdown |
| Timeout integration | 10 | Proper timeout with cleanup |

---

## Benchmark 3: Custom Allocator & Memory Management

### Task Name
**ALLOC-003: Arena Allocator with Type Erasure**

### Difficulty Rating
**10/10**

### Description
Implement and analyze a custom arena allocator with proper alignment handling, type erasure for heterogeneous data, and integration with Rust's allocator API.

### Sample Code Snippet

```rust
use std::alloc::{AllocError, Allocator, GlobalAlloc, Layout, System};
use std::cell::UnsafeCell;
use std::marker::PhantomData;
use std::mem::{align_of, size_of};
use std::ptr::NonNull;
use std::sync::atomic::{AtomicUsize, Ordering};

/// Arena allocator with bump allocation
pub struct Arena {
    chunks: UnsafeCell<Vec<Chunk>>,
    current: AtomicUsize,
    chunk_size: usize,
}

struct Chunk {
    memory: NonNull<u8>,
    layout: Layout,
    used: AtomicUsize,
}

unsafe impl Send for Arena {}
unsafe impl Sync for Arena {}

impl Arena {
    pub fn new(chunk_size: usize) -> Self {
        Self {
            chunks: UnsafeCell::new(Vec::new()),
            current: AtomicUsize::new(0),
            chunk_size,
        }
    }

    /// Allocate memory - HAS ALIGNMENT ISSUES
    pub fn allocate<T>(&self, value: T) -> &mut T {
        let layout = Layout::new::<T>();
        let size = layout.size();
        let align = layout.align();
        
        let chunks = unsafe { &mut *self.chunks.get() };
        let current_idx = self.current.load(Ordering::Relaxed);
        
        if let Some(chunk) = chunks.get_mut(current_idx) {
            let used = chunk.used.fetch_add(size, Ordering::Relaxed);
            
            // ISSUE: Alignment not handled!
            if used + size <= self.chunk_size {
                let ptr = unsafe { chunk.memory.as_ptr().add(used) };
                let typed = ptr as *mut T;
                unsafe { std::ptr::write(typed, value) };
                return unsafe { &mut *typed };
            }
        }
        
        // Need new chunk - implementation omitted
        panic!("Out of memory")
    }

    /// Reset arena - ISSUE: Destructors not called!
    pub fn reset(&self) {
        let chunks = unsafe { &mut *self.chunks.get() };
        for chunk in chunks.iter_mut() {
            chunk.used.store(0, Ordering::Relaxed);
        }
        self.current.store(0, Ordering::Relaxed);
    }
}

/// Type-erased arena for heterogeneous data
pub struct TypeErasedArena {
    arena: Arena,
    drop_fns: UnsafeCell<Vec<(NonNull<u8>, unsafe fn(*mut ()))>>,
}

impl TypeErasedArena {
    pub fn new(chunk_size: usize) -> Self {
        Self {
            arena: Arena::new(chunk_size),
            drop_fns: UnsafeCell::new(Vec::new()),
        }
    }

    /// Store a value with type erasure - HAS SAFETY ISSUES
    pub fn store<T: 'static>(&self, value: T) -> Handle<T> {
        let ptr = self.arena.allocate(value);
        
        // Store drop function for later cleanup
        unsafe {
            let drop_fns = &mut *self.drop_fns.get();
            drop_fns.push((
                NonNull::new_unchecked(ptr as *mut T as *mut u8),
                drop_erased::<T>,
            ));
        }
        
        Handle {
            ptr: NonNull::new(ptr).unwrap(),
            _marker: PhantomData,
        }
    }

    /// Clear with proper destructor calls
    pub fn clear(&self) {
        unsafe {
            let drop_fns = &mut *self.drop_fns.get();
            for (ptr, drop_fn) in drop_fns.drain(..) {
                drop_fn(ptr.as_ptr() as *mut ());
            }
        }
        self.arena.reset();
    }
}

unsafe fn drop_erased<T>(ptr: *mut ()) {
    std::ptr::drop_in_place(ptr as *mut T);
}

pub struct Handle<T> {
    ptr: NonNull<T>,
    _marker: PhantomData<T>,
}

impl<T> Handle<T> {
    pub fn get(&self) -> &T {
        unsafe { self.ptr.as_ref() }
    }
    
    pub fn get_mut(&mut self) -> &mut T {
        unsafe { self.ptr.as_mut() }
    }
}

/// Custom allocator implementing GlobalAlloc
pub struct TrackingAllocator<A: GlobalAlloc> {
    inner: A,
    allocated: AtomicUsize,
    peak: AtomicUsize,
}

unsafe impl<A: GlobalAlloc> GlobalAlloc for TrackingAllocator<A> {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = self.inner.alloc(layout);
        if !ptr.is_null() {
            let new_size = self.allocated.fetch_add(layout.size(), Ordering::Relaxed) 
                + layout.size();
            // ISSUE: Race condition in peak tracking!
            let current_peak = self.peak.load(Ordering::Relaxed);
            if new_size > current_peak {
                self.peak.store(new_size, Ordering::Relaxed);
            }
        }
        ptr
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        self.allocated.fetch_sub(layout.size(), Ordering::Relaxed);
        self.inner.dealloc(ptr, layout);
    }
}

/// Object pool with custom allocator
pub struct ObjectPool<T, A: Allocator = std::alloc::Global> {
    allocator: A,
    available: Vec<NonNull<T>>,
    _marker: PhantomData<T>,
}

impl<T, A: Allocator> ObjectPool<T, A> {
    /// Get object from pool or allocate new
    pub fn acquire(&mut self) -> Result<PooledObject<T, A>, AllocError> {
        if let Some(ptr) = self.available.pop() {
            Ok(PooledObject {
                ptr,
                pool: self,
                _marker: PhantomData,
            })
        } else {
            // ISSUE: How to allocate with custom allocator?
            todo!("Allocate new object using self.allocator")
        }
    }
}

pub struct PooledObject<'a, T, A: Allocator> {
    ptr: NonNull<T>,
    pool: &'a mut ObjectPool<T, A>,
    _marker: PhantomData<T>,
}

impl<'a, T, A: Allocator> Drop for PooledObject<'a, T, A> {
    fn drop(&mut self) {
        // Return to pool
        self.pool.available.push(self.ptr);
    }
}

/// Scoped arena with lifetime tracking
pub struct ScopedArena<'scope> {
    memory: NonNull<u8>,
    offset: AtomicUsize,
    capacity: usize,
    _marker: PhantomData<&'scope mut ()>,
}

impl<'scope> ScopedArena<'scope> {
    /// Allocate with proper alignment
    pub fn alloc<T>(&self, value: T) -> &'scope mut T {
        let layout = Layout::new::<T>();
        let align_mask = layout.align() - 1;
        
        // ISSUE: This alignment calculation is wrong for non-power-of-2!
        let current = self.offset.load(Ordering::Relaxed);
        let aligned = (current + align_mask) & !align_mask;
        let new_offset = aligned + layout.size();
        
        if new_offset > self.capacity {
            panic!("Arena overflow");
        }
        
        self.offset.store(new_offset, Ordering::Relaxed);
        
        let ptr = unsafe { self.memory.as_ptr().add(aligned) as *mut T };
        unsafe { std::ptr::write(ptr, value) };
        unsafe { &mut *ptr }
    }
}
```

### Questions

1. **Alignment fix**: The `Arena::allocate` method has alignment issues. Write the correct alignment calculation using `Layout::align_to` and explain why the current implementation is unsound.

2. **Drop glue**: Design a solution for calling destructors when resetting the arena. Consider using `Box::into_raw` patterns or a drop list.

3. **Allocator API integration**: Implement `ObjectPool::acquire` using the unstable `Allocator` trait with proper `NonNull` handling.

4. **Peak tracking**: Fix the race condition in `TrackingAllocator` peak tracking using `fetch_max` or compare-exchange loops.

5. **Scoped lifetime**: The `ScopedArena` uses atomic operations unnecessarily for a single-threaded scope. Design a more efficient version using `Cell` and explain the tradeoffs.

### Expected Output Format

```json
{
  "benchmark_id": "ALLOC-003",
  "alignment_fix": {
    "correct_code": "implementation",
    "explanation": "why original was unsound"
  },
  "drop_glue_solution": {
    "approach": "description",
    "implementation": "code",
    "overhead": "analysis"
  },
  "allocator_api": {
    "acquire_implementation": "code",
    "safety_invariants": ["list"]
  },
  "peak_tracking_fix": "code with fetch_max",
  "scoped_arena_optimization": "Cell-based implementation"
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Alignment correctness | 20 | Proper Layout::align_to usage |
| Drop glue design | 20 | Safe destructor calling |
| Allocator API usage | 20 | Correct unstable API usage |
| Race condition fix | 15 | Proper atomic operations |
| Scoped optimization | 15 | Cell vs Atomic tradeoffs |
| Safety documentation | 10 | Documents all unsafe invariants |

---

## Benchmark 4: Safe FFI Wrappers

### Task Name
**FFI-004: Safe Bindings for C Library**

### Difficulty Rating
**9/10**

### Description
Design safe Rust wrappers around a hypothetical C library with complex ownership, thread-safety concerns, and error handling requirements.

### Sample Code Snippet

```rust
use std::ffi::{c_char, c_int, c_void, CStr, CString};
use std::marker::PhantomData;
use std::mem::MaybeUninit;
use std::ptr::NonNull;
use std::sync::atomic::{AtomicBool, Ordering};

// ============================================================================
// Raw FFI Bindings (generated by bindgen)
// ============================================================================

#[repr(C)]
pub struct raw_database_t {
    _opaque: [u8; 0],
}

#[repr(C)]
pub struct raw_query_t {
    _opaque: [u8; 0],
}

#[repr(C)]
pub struct raw_result_t {
    data: *mut c_void,
    len: usize,
    capacity: usize,
    error_code: c_int,
    error_msg: *const c_char,
}

extern "C" {
    // Database operations
    pub fn db_open(path: *const c_char, flags: c_int) -> *mut raw_database_t;
    pub fn db_close(db: *mut raw_database_t);
    pub fn db_is_threadsafe(db: *mut raw_database_t) -> c_int;
    
    // Query operations - db must outlive query
    pub fn query_create(db: *mut raw_database_t, sql: *const c_char) -> *mut raw_query_t;
    pub fn query_destroy(query: *mut raw_query_t);
    pub fn query_execute(query: *mut raw_query_t) -> *mut raw_result_t;
    pub fn query_bind_int(query: *mut raw_query_t, idx: c_int, val: c_int) -> c_int;
    pub fn query_bind_string(query: *mut raw_query_t, idx: c_int, val: *const c_char) -> c_int;
    
    // Result operations - result must be freed, data is valid until result freed
    pub fn result_free(result: *mut raw_result_t);
    pub fn result_get_data(result: *mut raw_result_t) -> *mut c_void;
    pub fn result_get_len(result: *mut raw_result_t) -> usize;
    
    // Callback-based iteration
    pub fn result_iterate(
        result: *mut raw_result_t,
        callback: Option<unsafe extern "C" fn(*const c_void, *mut c_void) -> c_int>,
        userdata: *mut c_void,
    ) -> c_int;
    
    // Async operations
    pub fn db_async_exec(
        db: *mut raw_database_t,
        sql: *const c_char,
        callback: Option<unsafe extern "C" fn(*mut raw_result_t, *mut c_void)>,
        userdata: *mut c_void,
    ) -> c_int;
}

// ============================================================================
// Safe Wrappers (to be designed)
// ============================================================================

/// Thread policy for database
#[derive(Debug, Clone, Copy)]
pub enum ThreadPolicy {
    SingleThreaded,
    MultiThreaded,
}

/// Safe database handle - HAS LIFETIME ISSUES
pub struct Database {
    ptr: NonNull<raw_database_t>,
    threadsafe: bool,
}

impl Database {
    pub fn open(path: &str) -> Result<Self, DbError> {
        let c_path = CString::new(path).map_err(|_| DbError::InvalidPath)?;
        let ptr = unsafe { db_open(c_path.as_ptr(), 0) };
        
        if ptr.is_null() {
            return Err(DbError::OpenFailed);
        }
        
        let threadsafe = unsafe { db_is_threadsafe(ptr) != 0 };
        
        Ok(Self {
            ptr: NonNull::new(ptr).unwrap(),
            threadsafe,
        })
    }
    
    pub fn is_threadsafe(&self) -> bool {
        self.threadsafe
    }
}

impl Drop for Database {
    fn drop(&mut self) {
        unsafe { db_close(self.ptr.as_ptr()) };
    }
}

/// Query with bound parameters - LIFETIME ISSUES WITH DATABASE
pub struct Query<'db> {
    ptr: NonNull<raw_query_t>,
    _marker: PhantomData<&'db Database>,
}

impl<'db> Query<'db> {
    pub fn new(db: &'db Database, sql: &str) -> Result<Self, DbError> {
        let c_sql = CString::new(sql).map_err(|_| DbError::InvalidSql)?;
        let ptr = unsafe { query_create(db.ptr.as_ptr(), c_sql.as_ptr()) };
        
        if ptr.is_null() {
            return Err(DbError::QueryFailed);
        }
        
        Ok(Self {
            ptr: NonNull::new(ptr).unwrap(),
            _marker: PhantomData,
        })
    }
    
    pub fn bind_int(&mut self, idx: i32, val: i32) -> Result<(), DbError> {
        let rc = unsafe { query_bind_int(self.ptr.as_ptr(), idx, val) };
        if rc != 0 {
            return Err(DbError::BindFailed);
        }
        Ok(())
    }
    
    pub fn execute(&mut self) -> Result<ResultSet<'db>, DbError> {
        let raw = unsafe { query_execute(self.ptr.as_ptr()) };
        
        if raw.is_null() {
            return Err(DbError::ExecutionFailed);
        }
        
        Ok(ResultSet {
            ptr: NonNull::new(raw).unwrap(),
            _marker: PhantomData,
        })
    }
}

impl<'db> Drop for Query<'db> {
    fn drop(&mut self) {
        unsafe { query_destroy(self.ptr.as_ptr()) };
    }
}

/// Result set - DATA LIFETIME ISSUES
pub struct ResultSet<'q> {
    ptr: NonNull<raw_result_t>,
    _marker: PhantomData<&'q Query<'q>>,
}

impl<'q> ResultSet<'q> {
    /// ISSUE: This returns a slice with unclear lifetime
    pub fn as_slice(&self) -> &[u8] {
        unsafe {
            let data = result_get_data(self.ptr.as_ptr()) as *const u8;
            let len = result_get_len(self.ptr.as_ptr());
            std::slice::from_raw_parts(data, len)
        }
    }
    
    /// ISSUE: How to safely pass Rust closure to C callback?
    pub fn iterate<F>(&self, mut callback: F) -> Result<(), DbError>
    where
        F: FnMut(&[u8]) -> bool,
    {
        // UNSAFE: Need to handle panic across FFI boundary
        unsafe {
            let result = result_iterate(
                self.ptr.as_ptr(),
                Some(iterate_callback::<F>),
                &mut callback as *mut F as *mut c_void,
            );
            
            if result != 0 {
                return Err(DbError::IterationFailed);
            }
            
            Ok(())
        }
    }
}

unsafe extern "C" fn iterate_callback<F>(
    data: *const c_void,
    userdata: *mut c_void,
) -> c_int
where
    F: FnMut(&[u8]) -> bool,
{
    // ISSUE: Panic safety! What if callback panics?
    let callback = &mut *(userdata as *mut F);
    let slice = std::slice::from_raw_parts(data as *const u8, 0); // Wrong len!
    
    if callback(slice) {
        0 // Continue
    } else {
        1 // Stop
    }
}

impl<'q> Drop for ResultSet<'q> {
    fn drop(&mut self) {
        unsafe { result_free(self.ptr.as_ptr()) };
    }
}

/// Async execution wrapper - THREAD SAFETY ISSUES
pub struct AsyncDatabase {
    db: Database,
    // ISSUE: How to ensure callbacks happen on correct thread?
}

impl AsyncDatabase {
    /// ISSUE: This is fundamentally unsafe - callback may outlive future
    pub async fn exec_async(&self, sql: &str) -> Result<Vec<u8>, DbError> {
        let c_sql = CString::new(sql).map_err(|_| DbError::InvalidSql)?;
        
        // This doesn't work - need proper async design
        todo!("Implement safe async wrapper")
    }
}

#[derive(Debug)]
pub enum DbError {
    InvalidPath,
    OpenFailed,
    InvalidSql,
    QueryFailed,
    BindFailed,
    ExecutionFailed,
    IterationFailed,
    NotThreadSafe,
}

/// Send/Sync implementation - UNSOUND!
unsafe impl Send for Database {}
unsafe impl Sync for Database {}
```

### Questions

1. **Lifetime design**: The current `Query<'db>` and `ResultSet<'q>` have lifetime issues. Design a proper lifetime hierarchy where `ResultSet` borrows from `Query` and `Query` borrows from `Database`.

2. **Send/Sync safety**: The current `Send`/`Sync` impls are unsound. Implement proper conditional `Send`/`Sync` based on `db_is_threadsafe()` result using marker types.

3. **Panic safety**: The `iterate_callback` is not panic-safe. Design a solution using `std::panic::catch_unwind` and explain the "abort on panic" strategy for FFI boundaries.

4. **Async design**: Design a proper async wrapper using `tokio::sync::oneshot` channels that ensures callbacks complete before the future resolves.

5. **Error handling**: The C library returns error codes. Design a rich error type that captures error messages from `raw_result_t.error_msg` with proper lifetime management.

### Expected Output Format

```json
{
  "benchmark_id": "FFI-004",
  "lifetime_hierarchy": {
    "design": "explanation with code",
    "borrow_chain": "Database -> Query -> ResultSet"
  },
  "send_sync": {
    "marker_type": "implementation",
    "conditional_impl": "code"
  },
  "panic_safety": {
    "catch_unwind_usage": "code",
    "abort_strategy": "explanation"
  },
  "async_design": {
    "channel_based": "implementation",
    "safety_guarantees": ["list"]
  },
  "error_type": {
    "rich_error": "implementation",
    "message_lifetime": "explanation"
  }
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Lifetime design | 20 | Proper borrow chain |
| Send/Sync safety | 20 | Conditional impls with markers |
| Panic safety | 20 | catch_unwind + abort strategy |
| Async wrapper | 20 | Channel-based safe design |
| Error handling | 15 | Rich errors with C strings |
| Documentation | 5 | Safety invariants documented |

---

## Benchmark 5: Advanced Type System Tricks

### Task Name
**TYPE-005: Generic Associated Types & Higher-Ranked Bounds**

### Difficulty Rating
**10/10**

### Description
Design and implement advanced type system patterns including GATs, HRTBs, existential types, and type-level programming for a generic streaming data processing framework.

### Sample Code Snippet

```rust
use std::future::Future;
use std::pin::Pin;

// ============================================================================
// Generic Associated Types (GATs)
// ============================================================================

/// Streaming data source with GATs
pub trait DataSource {
    type Item<'a>: 'a
    where
        Self: 'a;
    type Error;
    
    fn next<'a>(&'a mut self) -> impl Future<Output = Result<Option<Self::Item<'a>>, Self::Error>>;
}

/// Data transformation with lifetime-generic output
pub trait Transformer {
    type Input<'a>: 'a;
    type Output<'a>: 'a;
    type Error;
    
    fn transform<'a>(
        &self,
        input: Self::Input<'a>,
    ) -> Result<Self::Output<'a>, Self::Error>;
}

/// ISSUE: This doesn't compile - how to chain transformers?
pub struct ChainedTransformer<A, B> {
    first: A,
    second: B,
}

impl<A, B> Transformer for ChainedTransformer<A, B>
where
    A: Transformer,
    B: Transformer<Input<'static> = A::Output<'static>>, // This is wrong!
{
    type Input<'a> = A::Input<'a>;
    type Output<'a> = B::Output<'a>;
    type Error = A::Error;
    
    fn transform<'a>(
        &self,
        input: Self::Input<'a>,
    ) -> Result<Self::Output<'a>, Self::Error> {
        // How to chain with different lifetimes?
        todo!()
    }
}

// ============================================================================
// Higher-Ranked Trait Bounds (HRTBs)
// ============================================================================

/// Generic callback with HRTB
pub trait Callback<T> {
    fn call<'a>(&self, item: &'a T) -> bool;
}

/// ISSUE: How to store callbacks with HRTB?
pub struct Filter<T> {
    // This doesn't work:
    // predicate: dyn for<'a> Fn(&'a T) -> bool,
    
    // Workaround using trait object:
    predicate: Box<dyn Callback<T>>,
}

/// Better approach using HRTB
pub struct BetterFilter<T> {
    predicate: Box<dyn for<'a> Fn(&'a T) -> bool + Send + Sync>,
}

impl<T> BetterFilter<T> {
    pub fn new<F>(f: F) -> Self
    where
        F: for<'a> Fn(&'a T) -> bool + Send + Sync + 'static,
    {
        Self {
            predicate: Box::new(f),
        }
    }
    
    pub fn apply<'a>(&self, item: &'a T) -> bool {
        (self.predicate)(item)
    }
}

// ============================================================================
// Existential Types (impl Trait in type position)
// ============================================================================

/// Type-erased iterator using existential types
pub struct ErasedIterator<'a, T> {
    inner: Box<dyn Iterator<Item = T> + 'a>,
}

impl<'a, T> ErasedIterator<'a, T> {
    pub fn new<I>(iter: I) -> Self
    where
        I: Iterator<Item = T> + 'a,
    {
        Self {
            inner: Box::new(iter),
        }
    }
}

impl<'a, T> Iterator for ErasedIterator<'a, T> {
    type Item = T;
    
    fn next(&mut self) -> Option<Self::Item> {
        self.inner.next()
    }
}

/// ISSUE: How to return different iterator types from a function?
pub fn create_iterator<T>(
    data: Vec<T>,
    reverse: bool,
) -> impl Iterator<Item = T> {
    if reverse {
        // ERROR: Different types!
        data.into_iter().rev()
    } else {
        data.into_iter()
    }
}

/// Solution using Either or type erasure
pub enum EitherIter<A, B> {
    Left(A),
    Right(B),
}

impl<A, B> Iterator for EitherIter<A, B>
where
    A: Iterator,
    B: Iterator<Item = A::Item>,
{
    type Item = A::Item;
    
    fn next(&mut self) -> Option<Self::Item> {
        match self {
            EitherIter::Left(a) => a.next(),
            EitherIter::Right(b) => b.next(),
        }
    }
}

// ============================================================================
// Type-Level Programming
// ============================================================================

/// Type-level state machine using phantom types
pub struct StateMachine<State> {
    data: String,
    _state: std::marker::PhantomData<State>,
}

pub struct Idle;
pub struct Running;
pub struct Paused;
pub struct Stopped;

impl StateMachine<Idle> {
    pub fn new(data: String) -> Self {
        Self {
            data,
            _state: std::marker::PhantomData,
        }
    }
    
    pub fn start(self) -> StateMachine<Running> {
        StateMachine {
            data: self.data,
            _state: std::marker::PhantomData,
        }
    }
}

impl StateMachine<Running> {
    pub fn pause(self) -> StateMachine<Paused> {
        StateMachine {
            data: self.data,
            _state: std::marker::PhantomData,
        }
    }
    
    pub fn stop(self) -> StateMachine<Stopped> {
        StateMachine {
            data: self.data,
            _state: std::marker::PhantomData,
        }
    }
    
    /// ISSUE: How to prevent calling start() on Running?
    /// (Already prevented by type system!)
}

/// Const generic for fixed-size buffers
pub struct FixedBuffer<T, const N: usize> {
    data: [T; N],
    len: usize,
}

impl<T: Default + Copy, const N: usize> FixedBuffer<T, N> {
    pub fn new() -> Self {
        Self {
            data: [T::default(); N],
            len: 0,
        }
    }
    
    /// ISSUE: How to implement push that fails at compile time if full?
    pub fn push(&mut self, item: T) -> Result<(), T> {
        if self.len >= N {
            return Err(item);
        }
        self.data[self.len] = item;
        self.len += 1;
        Ok(())
    }
}

/// Type-level natural numbers using peano arithmetic
pub struct Z; // Zero
pub struct S<N>(std::marker::PhantomData<N>); // Successor

/// Type-level length tracking
pub struct TypedVec<T, Len> {
    data: Vec<T>,
    _len: std::marker::PhantomData<Len>,
}

impl<T> TypedVec<T, Z> {
    pub fn new() -> Self {
        Self {
            data: Vec::new(),
            _len: std::marker::PhantomData,
        }
    }
}

impl<T, N> TypedVec<T, N> {
    /// ISSUE: How to express that push increases length by 1?
    pub fn push(self, item: T) -> TypedVec<T, S<N>> {
        let mut data = self.data;
        data.push(item);
        TypedVec {
            data,
            _len: std::marker::PhantomData,
        }
    }
}

// ============================================================================
// Async Trait with GATs
// ============================================================================

/// Async trait using RPITIT (Return Position Impl Trait In Trait)
pub trait AsyncProcessor {
    type Item;
    type Error;
    
    async fn process(&mut self, item: Self::Item) -> Result<Self::Item, Self::Error>;
}

/// Manual desugaring for understanding
pub trait AsyncProcessorDesugared {
    type Item;
    type Error;
    type ProcessFuture<'a>: Future<Output = Result<Self::Item, Self::Error>>
    where
        Self: 'a;
    
    fn process(&mut self, item: Self::Item) -> Self::ProcessFuture<'_>;
}

/// ISSUE: How to implement for different types with boxed futures?
pub struct BoxedProcessor<T, E> {
    inner: Box<dyn AsyncProcessor<Item = T, Error = E>>,
}

/// Higher-kinded type workaround
pub trait Hkt<'a> {
    type Applied;
}

impl<'a, T, E> Hkt<'a> for dyn AsyncProcessor<Item = T, Error = E> {
    type Applied = Pin<Box<dyn Future<Output = Result<T, E>> + 'a>>;
}

/// Streaming trait with lending iterator pattern
pub trait LendingIterator {
    type Item<'a>: 'a
    where
        Self: 'a;
    
    fn next<'a>(&'a mut self) -> Option<Self::Item<'a>>;
}

/// ISSUE: How to collect a LendingIterator?
/// (Cannot collect because items borrow from iterator!)
```

### Questions

1. **GAT chaining**: Implement `ChainedTransformer` correctly using GATs with proper lifetime propagation through the chain.

2. **HRTB storage**: Design a `Filter` that can store closures with HRTB using `Box<dyn for<'a> Fn(&'a T) -> bool>` and explain the `for<'a>` syntax.

3. **Existential return types**: Fix `create_iterator` using `EitherIter` or `ErasedIterator` and explain the tradeoffs between static dispatch (Either) and dynamic dispatch (Box).

4. **Const generics**: Implement a `push_const` method on `FixedBuffer` that fails at compile time when full using const assertions.

5. **Type-level programming**: Extend the `TypedVec` to support compile-time length tracking with `append` that adds lengths and `split` that divides them.

6. **Lending iterator**: Explain why `LendingIterator` cannot implement `Iterator` and design a `try_collect` method that works with lending iterators.

### Expected Output Format

```json
{
  "benchmark_id": "TYPE-005",
  "gat_chaining": {
    "implementation": "code",
    "lifetime_propagation": "explanation"
  },
  "hrtb_storage": {
    "filter_impl": "code",
    "for_syntax": "explanation"
  },
  "existential_types": {
    "either_solution": "code",
    "erasure_solution": "code",
    "tradeoffs": "comparison"
  },
  "const_generics": {
    "compile_time_push": "code using const_assert"
  },
  "type_level": {
    "append": "code",
    "split": "code"
  },
  "lending_iterator": {
    "why_not_iterator": "explanation",
    "try_collect": "implementation"
  }
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| GAT chaining | 20 | Proper lifetime propagation |
| HRTB storage | 15 | Correct for<'a> usage |
| Existential types | 15 | Either vs Box tradeoffs |
| Const generics | 15 | Compile-time assertions |
| Type-level programming | 15 | Peano arithmetic usage |
| Lending iterator | 15 | Understanding borrow constraints |
| Async trait | 5 | RPITIT vs desugared |

---

## Testing Instructions for Localhost

### Setup

```bash
# Clone test repository
cd /mnt/okcomputer/output

# Create test project
cargo new --lib rust_vlm_benchmarks
cd rust_vlm_benchmarks

# Add dependencies for testing
cat >> Cargo.toml << 'EOF'
[dependencies]
tokio = { version = "1", features = ["full"] }
tokio-util = { version = "0.7", features = ["full"] }
rayon = "1.8"
pin-project = "1"

[dev-dependencies]
criterion = "0.5"
EOF
```

### Running Against Qwen3.5

```bash
# Start Ollama with Qwen3.5
ollama run qwen3.5:32b

# Or use API
curl http://localhost:11434/api/generate -d '{
  "model": "qwen3.5:32b",
  "prompt": "[PASTE BENCHMARK CODE AND QUESTIONS]"
}'
```

### Evaluation Script

```python
#!/usr/bin/env python3
"""Evaluate Qwen3.5 responses against expert benchmarks."""

import json
import sys
from dataclasses import dataclass
from typing import List, Dict

@dataclass
class Benchmark:
    id: str
    name: str
    max_score: int
    criteria: Dict[str, int]

def evaluate_response(benchmark: Benchmark, response: str) -> dict:
    """Score a model response against benchmark criteria."""
    score = 0
    details = {}
    
    # Parse response for expected sections
    for criterion, points in benchmark.criteria.items():
        if criterion.lower().replace(' ', '_') in response.lower():
            score += points
            details[criterion] = points
        else:
            details[criterion] = 0
    
    return {
        "benchmark_id": benchmark.id,
        "score": score,
        "max_score": benchmark.max_score,
        "percentage": (score / benchmark.max_score) * 100,
        "details": details
    }

BENCHMARKS = [
    Benchmark("ZCA-001", "Zero-Cost Abstractions", 100, {
        "Iterator fusion detection": 20,
        "Atomic overhead recognition": 15,
        "Parallel overhead analysis": 15,
        "Memory layout expertise": 20,
        "SIMD barrier identification": 20,
        "Allocation optimization": 10
    }),
    Benchmark("ASYNC-002", "Async Cancellation", 100, {
        "Pin projection safety": 20,
        "Async drop patterns": 20,
        "Structured concurrency": 20,
        "Cancellation propagation": 15,
        "Orphaned task handling": 15,
        "Timeout integration": 10
    }),
    Benchmark("ALLOC-003", "Custom Allocator", 100, {
        "Alignment correctness": 20,
        "Drop glue design": 20,
        "Allocator API usage": 20,
        "Race condition fix": 15,
        "Scoped optimization": 15,
        "Safety documentation": 10
    }),
    Benchmark("FFI-004", "Safe FFI Wrappers", 100, {
        "Lifetime design": 20,
        "Send/Sync safety": 20,
        "Panic safety": 20,
        "Async wrapper": 20,
        "Error handling": 15,
        "Documentation": 5
    }),
    Benchmark("TYPE-005", "Advanced Type System", 100, {
        "GAT chaining": 20,
        "HRTB storage": 15,
        "Existential types": 15,
        "Const generics": 15,
        "Type-level programming": 15,
        "Lending iterator": 15,
        "Async trait": 5
    })
]

if __name__ == "__main__":
    # Load responses from file
    with open(sys.argv[1]) as f:
        responses = json.load(f)
    
    results = []
    for benchmark in BENCHMARKS:
        response = responses.get(benchmark.id, "")
        result = evaluate_response(benchmark, response)
        results.append(result)
    
    # Print summary
    print("\n" + "="*60)
    print("EXPERT RUST BENCHMARK RESULTS")
    print("="*60)
    
    total_score = sum(r["score"] for r in results)
    total_max = sum(r["max_score"] for r in results)
    
    for r in results:
        print(f"\n{r['benchmark_id']}: {r['percentage']:.1f}% ({r['score']}/{r['max_score']})")
    
    print(f"\n{'='*60}")
    print(f"OVERALL: {(total_score/total_max)*100:.1f}% ({total_score}/{total_max})")
    print(f"{'='*60}")
    
    # Save detailed results
    with open("benchmark_results.json", "w") as f:
        json.dump(results, f, indent=2)
```

---

## Summary

| Benchmark | Focus Area | Difficulty | Key Skills Tested |
|-----------|------------|------------|-------------------|
| ZCA-001 | Zero-cost abstractions | 9/10 | LLVM optimization, SIMD, memory layout |
| ASYNC-002 | Async cancellation | 10/10 | Pin safety, structured concurrency, drop |
| ALLOC-003 | Custom allocators | 10/10 | Allocator API, alignment, drop glue |
| FFI-004 | Safe FFI wrappers | 9/10 | Lifetimes, Send/Sync, panic safety |
| TYPE-005 | Advanced type system | 10/10 | GATs, HRTBs, type-level programming |

**Total Possible Score**: 500 points  
**Expert Threshold**: 400+ points (80%)  
**Advanced Threshold**: 350+ points (70%)
