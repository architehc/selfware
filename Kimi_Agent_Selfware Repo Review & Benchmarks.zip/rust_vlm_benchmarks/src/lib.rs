//! Expert-Level Rust Benchmarks for VLM Testing
//!
//! This crate contains code snippets for testing visual language models'
//! understanding of advanced Rust concepts.

#![allow(dead_code, unused_imports)]

// ============================================================================
// Benchmark 1: Zero-Cost Abstractions & Optimization
// ============================================================================

pub mod zero_cost {
    use rayon::prelude::*;
    use std::collections::HashMap;
    use std::sync::atomic::{AtomicUsize, Ordering};

    /// A data processing pipeline with potential optimization issues
    pub struct DataPipeline<T> {
        data: Vec<T>,
        transformers: Vec<Box<dyn Fn(T) -> T + Send + Sync>>,
        filters: Vec<Box<dyn Fn(&T) -> bool + Send + Sync>>,
    }

    impl<T: Clone + Send + Sync + 'static> DataPipeline<T> {
        pub fn new(data: Vec<T>) -> Self {
            Self {
                data,
                transformers: Vec::new(),
                filters: Vec::new(),
            }
        }

        pub fn add_transform<F>(&mut self, f: F)
        where
            F: Fn(T) -> T + Send + Sync + 'static,
        {
            self.transformers.push(Box::new(f));
        }

        pub fn add_filter<F>(&mut self, f: F)
        where
            F: Fn(&T) -> bool + Send + Sync + 'static,
        {
            self.filters.push(Box::new(f));
        }

        /// Execute the pipeline - CONTAINS OPTIMIZATION ISSUES
        pub fn execute(&self) -> Vec<T> {
            let counter = AtomicUsize::new(0);
            
            self.data
                .iter()
                .cloned()
                .filter(|item| {
                    counter.fetch_add(1, Ordering::Relaxed);
                    self.filters.iter().all(|f| f(item))
                })
                .map(|item| {
                    self.transformers.iter().fold(item, |acc, f| f(acc))
                })
                .collect()
        }

        /// Parallel execution - CONTAINS OPTIMIZATION ISSUES
        pub fn execute_par(&self) -> Vec<T> {
            self.data
                .par_iter()
                .cloned()
                .filter(|item| self.filters.iter().all(|f| f(item)))
                .map(|item| {
                    self.transformers.iter().fold(item, |acc, f| f(acc))
                })
                .collect()
        }
    }

    /// Aggregation with potential allocation issues
    pub fn aggregate_results<K, V>(items: &[(K, V)]) -> HashMap<K, Vec<V>>
    where
        K: std::hash::Hash + Eq + Clone,
        V: Clone,
    {
        let mut result = HashMap::new();
        
        for (k, v) in items {
            result.entry(k.clone()).or_insert_with(Vec::new).push(v.clone());
        }
        
        result
    }

    /// SIMD-friendly data layout vs cache-friendly layout
    #[repr(C)]
    pub struct AoS {
        pub x: f64,
        pub y: f64,
        pub z: f64,
        pub w: f64,
    }

    #[repr(C)]
    pub struct SoA {
        pub x: Vec<f64>,
        pub y: Vec<f64>,
        pub z: Vec<f64>,
        pub w: Vec<f64>,
    }

    impl SoA {
        /// Process with potential vectorization barriers
        pub fn process(&self, output: &mut [f64]) {
            for i in 0..self.x.len().min(output.len()) {
                output[i] = (self.x[i] * self.x[i] 
                    + self.y[i] * self.y[i] 
                    + self.z[i] * self.z[i]).sqrt();
            }
        }
    }
}

// ============================================================================
// Benchmark 2: Async Architecture with Cancellation
// ============================================================================

pub mod async_cancel {
    use std::future::Future;
    use std::pin::Pin;
    use std::sync::Arc;
    use std::task::{Context, Poll};
    use tokio::sync::{mpsc, RwLock};
    use tokio_util::sync::CancellationToken;

    /// A hierarchical task manager with cancellation support
    pub struct TaskManager {
        root_token: CancellationToken,
        tasks: Arc<RwLock<Vec<TaskHandle>>>,
        shutdown_tx: mpsc::Sender<ShutdownCommand>,
    }

    #[derive(Debug, Clone)]
    pub struct TaskHandle {
        id: String,
        parent_id: Option<String>,
        token: CancellationToken,
        abort_handle: tokio::task::AbortHandle,
    }

    #[derive(Debug)]
    pub enum ShutdownCommand {
        Graceful { timeout_ms: u64 },
        Immediate,
        Cascade { task_id: String },
    }

    /// Custom future that handles cancellation properly
    pub struct CancellableFuture<F> {
        inner: F,
        token: CancellationToken,
        cleanup: Option<Box<dyn FnOnce() + Send>>,
    }

    impl<F: Future> Future for CancellableFuture<F> {
        type Output = Option<F::Output>;

        fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // IMPLEMENTATION HAS ISSUES
            if self.token.is_cancelled() {
                if let Some(cleanup) = self.cleanup.take() {
                    cleanup();
                }
                return Poll::Ready(None);
            }

            unsafe {
                let inner = Pin::new_unchecked(&mut self.inner);
                match inner.poll(cx) {
                    Poll::Ready(v) => Poll::Ready(Some(v)),
                    Poll::Pending => Poll::Pending,
                }
            }
        }
    }

    /// Resource guard with async cleanup
    pub struct AsyncResourceGuard<R> {
        resource: Option<R>,
        cleanup_tx: mpsc::Sender<R>,
    }

    impl<R> AsyncResourceGuard<R> {
        pub async fn release(mut self) {
            if let Some(resource) = self.resource.take() {
                let _ = self.cleanup_tx.send(resource).await;
            }
        }
    }

    impl<R> Drop for AsyncResourceGuard<R> {
        fn drop(&mut self) {
            // ISSUE: This is problematic for async resources
            if let Some(resource) = self.resource.take() {
                // Cannot await in drop - what do we do?
                drop(resource);
            }
        }
    }

    /// Stream processor with backpressure and cancellation
    pub struct StreamProcessor<T> {
        input: mpsc::Receiver<T>,
        output: mpsc::Sender<T>,
        token: CancellationToken,
        buffer_size: usize,
        in_flight: Arc<RwLock<Vec<tokio::task::JoinHandle<()>>>>,
    }

    impl<T: Send + 'static> StreamProcessor<T> {
        pub async fn run(&mut self) {
            loop {
                tokio::select! {
                    biased;
                    
                    _ = self.token.cancelled() => {
                        // ISSUE: In-flight tasks may be orphaned
                        break;
                    }
                    
                    Some(item) = self.input.recv() => {
                        let output = self.output.clone();
                        let token = self.token.child_token();
                        
                        let handle = tokio::spawn(async move {
                            tokio::select! {
                                _ = token.cancelled() => {}
                                _ = process_and_send(item, output) => {}
                            }
                        });
                        
                        self.in_flight.write().await.push(handle);
                    }
                    
                    else => break,
                }
            }
        }
    }

    async fn process_and_send<T>(item: T, output: mpsc::Sender<T>) {
        let _ = output.send(item).await;
    }

    /// Timeout wrapper with proper cleanup
    pub struct TimeoutWrapper<F> {
        inner: F,
        timeout: std::time::Duration,
        on_timeout: Box<dyn FnOnce() + Send>,
    }

    impl<F: Future> Future for TimeoutWrapper<F> {
        type Output = Result<F::Output, TimeoutError>;

        fn poll(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Self::Output> {
            // IMPLEMENTATION MISSING - WHAT ARE THE CHALLENGES?
            todo!("Implement proper timeout with cleanup")
        }
    }

    #[derive(Debug)]
    pub struct TimeoutError;

    /// Structured concurrency pattern
    pub struct Scope<'scope> {
        token: CancellationToken,
        tasks: Vec<tokio::task::JoinHandle<()>>,
        _marker: std::marker::PhantomData<&'scope ()>,
    }

    impl<'scope> Scope<'scope> {
        pub fn spawn<F>(&mut self, _f: F) 
        where
            F: Future + Send + 'scope,
            F::Output: Send,
        {
            // How do we ensure all tasks complete before scope exits?
        }
    }
}

// ============================================================================
// Benchmark 3: Custom Allocator & Memory Management
// ============================================================================

pub mod allocator {
    use std::alloc::{AllocError, Allocator, GlobalAlloc, Layout, System};
    use std::cell::UnsafeCell;
    use std::marker::PhantomData;
    use std::mem::{align_of, size_of};
    use std::ptr::NonNull;
    use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};

    /// Arena allocator with bump allocation
    pub struct Arena {
        chunks: UnsafeCell<Vec<Chunk>>,
        current: AtomicUsize,
        chunk_size: usize,
    }

    struct Chunk {
        memory: NonNull<u8>,
        layout: Layout,
        used: AtomicUsize,
    }

    unsafe impl Send for Arena {}
    unsafe impl Sync for Arena {}

    impl Arena {
        pub fn new(chunk_size: usize) -> Self {
            Self {
                chunks: UnsafeCell::new(Vec::new()),
                current: AtomicUsize::new(0),
                chunk_size,
            }
        }

        /// Allocate memory - HAS ALIGNMENT ISSUES
        pub fn allocate<T>(&self, value: T) -> &mut T {
            let layout = Layout::new::<T>();
            let size = layout.size();
            let align = layout.align();
            
            let chunks = unsafe { &mut *self.chunks.get() };
            let current_idx = self.current.load(Ordering::Relaxed);
            
            if let Some(chunk) = chunks.get_mut(current_idx) {
                let used = chunk.used.fetch_add(size, Ordering::Relaxed);
                
                // ISSUE: Alignment not handled!
                if used + size <= self.chunk_size {
                    let ptr = unsafe { chunk.memory.as_ptr().add(used) };
                    let typed = ptr as *mut T;
                    unsafe { std::ptr::write(typed, value) };
                    return unsafe { &mut *typed };
                }
            }
            
            panic!("Out of memory")
        }

        /// Reset arena - ISSUE: Destructors not called!
        pub fn reset(&self) {
            let chunks = unsafe { &mut *self.chunks.get() };
            for chunk in chunks.iter_mut() {
                chunk.used.store(0, Ordering::Relaxed);
            }
            self.current.store(0, Ordering::Relaxed);
        }
    }

    /// Type-erased arena for heterogeneous data
    pub struct TypeErasedArena {
        arena: Arena,
        drop_fns: UnsafeCell<Vec<(NonNull<u8>, unsafe fn(*mut ()))>>,
    }

    impl TypeErasedArena {
        pub fn new(chunk_size: usize) -> Self {
            Self {
                arena: Arena::new(chunk_size),
                drop_fns: UnsafeCell::new(Vec::new()),
            }
        }

        /// Store a value with type erasure - HAS SAFETY ISSUES
        pub fn store<T: 'static>(&self, value: T) -> Handle<T> {
            let ptr = self.arena.allocate(value);
            
            unsafe {
                let drop_fns = &mut *self.drop_fns.get();
                drop_fns.push((
                    NonNull::new_unchecked(ptr as *mut T as *mut u8),
                    drop_erased::<T>,
                ));
            }
            
            Handle {
                ptr: NonNull::new(ptr).unwrap(),
                _marker: PhantomData,
            }
        }

        /// Clear with proper destructor calls
        pub fn clear(&self) {
            unsafe {
                let drop_fns = &mut *self.drop_fns.get();
                for (ptr, drop_fn) in drop_fns.drain(..) {
                    drop_fn(ptr.as_ptr() as *mut ());
                }
            }
            self.arena.reset();
        }
    }

    unsafe fn drop_erased<T>(ptr: *mut ()) {
        std::ptr::drop_in_place(ptr as *mut T);
    }

    pub struct Handle<T> {
        ptr: NonNull<T>,
        _marker: PhantomData<T>,
    }

    impl<T> Handle<T> {
        pub fn get(&self) -> &T {
            unsafe { self.ptr.as_ref() }
        }
        
        pub fn get_mut(&mut self) -> &mut T {
            unsafe { self.ptr.as_mut() }
        }
    }

    /// Custom allocator implementing GlobalAlloc
    pub struct TrackingAllocator<A: GlobalAlloc> {
        inner: A,
        allocated: AtomicUsize,
        peak: AtomicUsize,
    }

    unsafe impl<A: GlobalAlloc> GlobalAlloc for TrackingAllocator<A> {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            let ptr = self.inner.alloc(layout);
            if !ptr.is_null() {
                let new_size = self.allocated.fetch_add(layout.size(), Ordering::Relaxed) 
                    + layout.size();
                // ISSUE: Race condition in peak tracking!
                let current_peak = self.peak.load(Ordering::Relaxed);
                if new_size > current_peak {
                    self.peak.store(new_size, Ordering::Relaxed);
                }
            }
            ptr
        }

        unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
            self.allocated.fetch_sub(layout.size(), Ordering::Relaxed);
            self.inner.dealloc(ptr, layout);
        }
    }

    /// Object pool with custom allocator
    pub struct ObjectPool<T, A: Allocator = std::alloc::Global> {
        allocator: A,
        available: Vec<NonNull<T>>,
        _marker: PhantomData<T>,
    }

    impl<T, A: Allocator> ObjectPool<T, A> {
        /// Get object from pool or allocate new
        pub fn acquire(&mut self) -> Result<PooledObject<T, A>, AllocError> {
            if let Some(ptr) = self.available.pop() {
                Ok(PooledObject {
                    ptr,
                    pool: self,
                    _marker: PhantomData,
                })
            } else {
                // ISSUE: How to allocate with custom allocator?
                todo!("Allocate new object using self.allocator")
            }
        }
    }

    pub struct PooledObject<'a, T, A: Allocator> {
        ptr: NonNull<T>,
        pool: &'a mut ObjectPool<T, A>,
        _marker: PhantomData<T>,
    }

    impl<'a, T, A: Allocator> Drop for PooledObject<'a, T, A> {
        fn drop(&mut self) {
            // Return to pool
            self.pool.available.push(self.ptr);
        }
    }

    /// Scoped arena with lifetime tracking
    pub struct ScopedArena<'scope> {
        memory: NonNull<u8>,
        offset: AtomicUsize,
        capacity: usize,
        _marker: PhantomData<&'scope mut ()>,
    }

    impl<'scope> ScopedArena<'scope> {
        /// Allocate with proper alignment
        pub fn alloc<T>(&self, value: T) -> &'scope mut T {
            let layout = Layout::new::<T>();
            let align_mask = layout.align() - 1;
            
            // ISSUE: This alignment calculation is wrong for non-power-of-2!
            let current = self.offset.load(Ordering::Relaxed);
            let aligned = (current + align_mask) & !align_mask;
            let new_offset = aligned + layout.size();
            
            if new_offset > self.capacity {
                panic!("Arena overflow");
            }
            
            self.offset.store(new_offset, Ordering::Relaxed);
            
            let ptr = unsafe { self.memory.as_ptr().add(aligned) as *mut T };
            unsafe { std::ptr::write(ptr, value) };
            unsafe { &mut *ptr }
        }
    }
}

// ============================================================================
// Benchmark 4: Safe FFI Wrappers
// ============================================================================

pub mod ffi {
    use std::ffi::{c_char, c_int, c_void, CStr, CString};
    use std::marker::PhantomData;
    use std::ptr::NonNull;
    use std::sync::atomic::{AtomicBool, Ordering};

    // Raw FFI Bindings (would be generated by bindgen)
    #[repr(C)]
    pub struct raw_database_t {
        _opaque: [u8; 0],
    }

    #[repr(C)]
    pub struct raw_query_t {
        _opaque: [u8; 0],
    }

    #[repr(C)]
    pub struct raw_result_t {
        data: *mut c_void,
        len: usize,
        capacity: usize,
        error_code: c_int,
        error_msg: *const c_char,
    }

    extern "C" {
        pub fn db_open(path: *const c_char, flags: c_int) -> *mut raw_database_t;
        pub fn db_close(db: *mut raw_database_t);
        pub fn db_is_threadsafe(db: *mut raw_database_t) -> c_int;
        pub fn query_create(db: *mut raw_database_t, sql: *const c_char) -> *mut raw_query_t;
        pub fn query_destroy(query: *mut raw_query_t);
        pub fn query_execute(query: *mut raw_query_t) -> *mut raw_result_t;
        pub fn result_free(result: *mut raw_result_t);
    }

    /// Thread policy for database
    #[derive(Debug, Clone, Copy)]
    pub enum ThreadPolicy {
        SingleThreaded,
        MultiThreaded,
    }

    /// Safe database handle - HAS LIFETIME ISSUES
    pub struct Database {
        ptr: NonNull<raw_database_t>,
        threadsafe: bool,
    }

    impl Database {
        pub fn open(path: &str) -> Result<Self, DbError> {
            let c_path = CString::new(path).map_err(|_| DbError::InvalidPath)?;
            let ptr = unsafe { db_open(c_path.as_ptr(), 0) };
            
            if ptr.is_null() {
                return Err(DbError::OpenFailed);
            }
            
            let threadsafe = unsafe { db_is_threadsafe(ptr) != 0 };
            
            Ok(Self {
                ptr: NonNull::new(ptr).unwrap(),
                threadsafe,
            })
        }
        
        pub fn is_threadsafe(&self) -> bool {
            self.threadsafe
        }
    }

    impl Drop for Database {
        fn drop(&mut self) {
            unsafe { db_close(self.ptr.as_ptr()) };
        }
    }

    /// UNSOUND Send/Sync impls
    unsafe impl Send for Database {}
    unsafe impl Sync for Database {}

    /// Query with bound parameters - LIFETIME ISSUES WITH DATABASE
    pub struct Query<'db> {
        ptr: NonNull<raw_query_t>,
        _marker: PhantomData<&'db Database>,
    }

    impl<'db> Query<'db> {
        pub fn new(db: &'db Database, sql: &str) -> Result<Self, DbError> {
            let c_sql = CString::new(sql).map_err(|_| DbError::InvalidSql)?;
            let ptr = unsafe { query_create(db.ptr.as_ptr(), c_sql.as_ptr()) };
            
            if ptr.is_null() {
                return Err(DbError::QueryFailed);
            }
            
            Ok(Self {
                ptr: NonNull::new(ptr).unwrap(),
                _marker: PhantomData,
            })
        }
        
        pub fn execute(&mut self) -> Result<ResultSet<'db>, DbError> {
            let raw = unsafe { query_execute(self.ptr.as_ptr()) };
            
            if raw.is_null() {
                return Err(DbError::ExecutionFailed);
            }
            
            Ok(ResultSet {
                ptr: NonNull::new(raw).unwrap(),
                _marker: PhantomData,
            })
        }
    }

    impl<'db> Drop for Query<'db> {
        fn drop(&mut self) {
            unsafe { query_destroy(self.ptr.as_ptr()) };
        }
    }

    /// Result set - DATA LIFETIME ISSUES
    pub struct ResultSet<'q> {
        ptr: NonNull<raw_result_t>,
        _marker: PhantomData<&'q Query<'q>>,
    }

    impl<'q> ResultSet<'q> {
        /// ISSUE: This returns a slice with unclear lifetime
        pub fn as_slice(&self) -> &[u8] {
            unsafe {
                let data = self.ptr.as_ref().data as *const u8;
                let len = self.ptr.as_ref().len;
                std::slice::from_raw_parts(data, len)
            }
        }
    }

    impl<'q> Drop for ResultSet<'q> {
        fn drop(&mut self) {
            unsafe { result_free(self.ptr.as_ptr()) };
        }
    }

    #[derive(Debug)]
    pub enum DbError {
        InvalidPath,
        OpenFailed,
        InvalidSql,
        QueryFailed,
        BindFailed,
        ExecutionFailed,
        IterationFailed,
        NotThreadSafe,
    }
}

// ============================================================================
// Benchmark 5: Advanced Type System Tricks
// ============================================================================

pub mod type_system {
    use std::future::Future;
    use std::pin::Pin;

    // Generic Associated Types (GATs)
    pub trait DataSource {
        type Item<'a>: 'a where Self: 'a;
        type Error;
        
        fn next<'a>(&'a mut self) -> impl Future<Output = Result<Option<Self::Item<'a>>, Self::Error>>;
    }

    pub trait Transformer {
        type Input<'a>: 'a;
        type Output<'a>: 'a;
        type Error;
        
        fn transform<'a>(
            &self,
            input: Self::Input<'a>,
        ) -> Result<Self::Output<'a>, Self::Error>;
    }

    /// ISSUE: This doesn't compile - how to chain transformers?
    pub struct ChainedTransformer<A, B> {
        first: A,
        second: B,
    }

    /// Higher-Ranked Trait Bounds (HRTBs)
    pub trait Callback<T> {
        fn call<'a>(&self, item: &'a T) -> bool;
    }

    /// Better approach using HRTB
    pub struct BetterFilter<T> {
        predicate: Box<dyn for<'a> Fn(&'a T) -> bool + Send + Sync>,
    }

    impl<T> BetterFilter<T> {
        pub fn new<F>(f: F) -> Self
        where
            F: for<'a> Fn(&'a T) -> bool + Send + Sync + 'static,
        {
            Self {
                predicate: Box::new(f),
            }
        }
        
        pub fn apply<'a>(&self, item: &'a T) -> bool {
            (self.predicate)(item)
        }
    }

    /// Type-erased iterator using existential types
    pub struct ErasedIterator<'a, T> {
        inner: Box<dyn Iterator<Item = T> + 'a>,
    }

    impl<'a, T> ErasedIterator<'a, T> {
        pub fn new<I>(iter: I) -> Self
        where
            I: Iterator<Item = T> + 'a,
        {
            Self {
                inner: Box::new(iter),
            }
        }
    }

    impl<'a, T> Iterator for ErasedIterator<'a, T> {
        type Item = T;
        
        fn next(&mut self) -> Option<Self::Item> {
            self.inner.next()
        }
    }

    /// Either iterator for different types
    pub enum EitherIter<A, B> {
        Left(A),
        Right(B),
    }

    impl<A, B> Iterator for EitherIter<A, B>
    where
        A: Iterator,
        B: Iterator<Item = A::Item>,
    {
        type Item = A::Item;
        
        fn next(&mut self) -> Option<Self::Item> {
            match self {
                EitherIter::Left(a) => a.next(),
                EitherIter::Right(b) => b.next(),
            }
        }
    }

    // Type-level state machine using phantom types
    pub struct StateMachine<State> {
        data: String,
        _state: std::marker::PhantomData<State>,
    }

    pub struct Idle;
    pub struct Running;
    pub struct Paused;
    pub struct Stopped;

    impl StateMachine<Idle> {
        pub fn new(data: String) -> Self {
            Self {
                data,
                _state: std::marker::PhantomData,
            }
        }
        
        pub fn start(self) -> StateMachine<Running> {
            StateMachine {
                data: self.data,
                _state: std::marker::PhantomData,
            }
        }
    }

    impl StateMachine<Running> {
        pub fn pause(self) -> StateMachine<Paused> {
            StateMachine {
                data: self.data,
                _state: std::marker::PhantomData,
            }
        }
        
        pub fn stop(self) -> StateMachine<Stopped> {
            StateMachine {
                data: self.data,
                _state: std::marker::PhantomData,
            }
        }
    }

    // Const generic for fixed-size buffers
    pub struct FixedBuffer<T, const N: usize> {
        data: [T; N],
        len: usize,
    }

    impl<T: Default + Copy, const N: usize> FixedBuffer<T, N> {
        pub fn new() -> Self {
            Self {
                data: [T::default(); N],
                len: 0,
            }
        }
        
        /// ISSUE: How to implement push that fails at compile time if full?
        pub fn push(&mut self, item: T) -> Result<(), T> {
            if self.len >= N {
                return Err(item);
            }
            self.data[self.len] = item;
            self.len += 1;
            Ok(())
        }
    }

    // Type-level natural numbers using peano arithmetic
    pub struct Z; // Zero
    pub struct S<N>(std::marker::PhantomData<N>); // Successor

    /// Type-level length tracking
    pub struct TypedVec<T, Len> {
        data: Vec<T>,
        _len: std::marker::PhantomData<Len>,
    }

    impl<T> TypedVec<T, Z> {
        pub fn new() -> Self {
            Self {
                data: Vec::new(),
                _len: std::marker::PhantomData,
            }
        }
    }

    impl<T, N> TypedVec<T, N> {
        /// ISSUE: How to express that push increases length by 1?
        pub fn push(self, item: T) -> TypedVec<T, S<N>> {
            let mut data = self.data;
            data.push(item);
            TypedVec {
                data,
                _len: std::marker::PhantomData,
            }
        }
    }

    /// Async trait using RPITIT
    pub trait AsyncProcessor {
        type Item;
        type Error;
        
        async fn process(&mut self, item: Self::Item) -> Result<Self::Item, Self::Error>;
    }

    /// Manual desugaring for understanding
    pub trait AsyncProcessorDesugared {
        type Item;
        type Error;
        type ProcessFuture<'a>: Future<Output = Result<Self::Item, Self::Error>>
        where
            Self: 'a;
        
        fn process(&mut self, item: Self::Item) -> Self::ProcessFuture<'_>;
    }

    /// Streaming trait with lending iterator pattern
    pub trait LendingIterator {
        type Item<'a>: 'a where Self: 'a;
        
        fn next<'a>(&'a mut self) -> Option<Self::Item<'a>>;
    }

    /// ISSUE: How to collect a LendingIterator?
    /// (Cannot collect because items borrow from iterator!)
}
