#!/usr/bin/env python3
"""
Benchmark Runner for Rust VLM Testing

This script runs the 5 benchmarks against a local Qwen3.5 model
and evaluates the responses.

Usage:
    python run_benchmarks.py --model-url http://localhost:8000/v1
    python run_benchmarks.py --benchmark pr_code_review --save-responses
"""

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, Optional

try:
    import requests
except ImportError:
    print("Error: requests package required. Install with: pip install requests")
    sys.exit(1)


class BenchmarkRunner:
    """Runner for Rust VLM benchmarks."""

    def __init__(self, model_url: str, model_name: str = "Qwen3.5-32B"):
        self.model_url = model_url.rstrip("/")
        self.model_name = model_name
        self.chat_endpoint = f"{self.model_url}/chat/completions"
        
        # Load prompts
        prompts_path = Path(__file__).parent / "benchmark_prompts.json"
        with open(prompts_path) as f:
            data = json.load(f)
            self.benchmarks = data["benchmarks"]
            self.config = data.get("testing_config", {})

    def run_benchmark(
        self,
        benchmark_name: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None
    ) -> Dict:
        """Run a single benchmark and return the response."""
        if benchmark_name not in self.benchmarks:
            raise ValueError(f"Unknown benchmark: {benchmark_name}")
        
        benchmark = self.benchmarks[benchmark_name]
        prompt = benchmark["prompt"]
        
        # Use config defaults if not specified
        temp = temperature or self.config.get("temperature", 0.2)
        tokens = max_tokens or self.config.get("max_tokens", 4096)
        
        print(f"\n{'='*60}")
        print(f"Running benchmark: {benchmark['name']}")
        print(f"Difficulty: {benchmark['difficulty']}/10")
        print(f"{'='*60}")
        
        start_time = time.time()
        
        try:
            response = requests.post(
                self.chat_endpoint,
                json={
                    "model": self.model_name,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": temp,
                    "max_tokens": tokens
                },
                timeout=300  # 5 minute timeout
            )
            response.raise_for_status()
            
            elapsed = time.time() - start_time
            result = response.json()
            content = result["choices"][0]["message"]["content"]
            
            print(f"Completed in {elapsed:.1f}s")
            print(f"Tokens used: {result.get('usage', {}).get('total_tokens', 'N/A')}")
            
            return {
                "benchmark": benchmark_name,
                "response": content,
                "elapsed_seconds": elapsed,
                "tokens_used": result.get("usage", {}),
                "success": True
            }
            
        except requests.exceptions.RequestException as e:
            elapsed = time.time() - start_time
            print(f"Error after {elapsed:.1f}s: {e}")
            return {
                "benchmark": benchmark_name,
                "error": str(e),
                "elapsed_seconds": elapsed,
                "success": False
            }

    def run_all_benchmarks(
        self,
        save_responses: bool = True,
        responses_dir: Path = Path("./responses")
    ) -> Dict:
        """Run all benchmarks and return results."""
        results = []
        
        if save_responses:
            responses_dir.mkdir(exist_ok=True)
        
        for benchmark_name in self.benchmarks:
            result = self.run_benchmark(benchmark_name)
            results.append(result)
            
            if save_responses and result["success"]:
                response_file = responses_dir / f"{benchmark_name}.txt"
                response_file.write_text(result["response"])
                print(f"Saved response to {response_file}")
        
        return {
            "results": results,
            "total_benchmarks": len(results),
            "successful": sum(1 for r in results if r["success"]),
            "failed": sum(1 for r in results if not r["success"]),
            "total_time": sum(r["elapsed_seconds"] for r in results)
        }


def main():
    parser = argparse.ArgumentParser(
        description="Run Rust VLM benchmarks against a local model"
    )
    parser.add_argument(
        "--model-url",
        default="http://localhost:8000/v1",
        help="URL of the model API endpoint"
    )
    parser.add_argument(
        "--model-name",
        default="Qwen3.5-32B",
        help="Name of the model to use"
    )
    parser.add_argument(
        "--benchmark",
        choices=["pr_code_review", "feature_implementation", "debugging_issue",
                 "performance_optimization", "edition_migration", "all"],
        default="all",
        help="Which benchmark to run"
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.2,
        help="Sampling temperature"
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=4096,
        help="Maximum tokens to generate"
    )
    parser.add_argument(
        "--save-responses",
        action="store_true",
        default=True,
        help="Save responses to files"
    )
    parser.add_argument(
        "--responses-dir",
        type=Path,
        default=Path("./responses"),
        help="Directory to save responses"
    )
    parser.add_argument(
        "--output",
        "-o",
        type=Path,
        help="Output file for results (JSON)"
    )
    
    args = parser.parse_args()
    
    runner = BenchmarkRunner(args.model_url, args.model_name)
    
    if args.benchmark == "all":
        results = runner.run_all_benchmarks(
            save_responses=args.save_responses,
            responses_dir=args.responses_dir
        )
    else:
        result = runner.run_benchmark(
            args.benchmark,
            temperature=args.temperature,
            max_tokens=args.max_tokens
        )
        results = {"results": [result]}
        
        if args.save_responses and result["success"]:
            args.responses_dir.mkdir(exist_ok=True)
            response_file = args.responses_dir / f"{args.benchmark}.txt"
            response_file.write_text(result["response"])
            print(f"Saved response to {response_file}")
    
    # Output results
    if args.output:
        with open(args.output, "w") as f:
            json.dump(results, f, indent=2)
        print(f"\nResults saved to {args.output}")
    else:
        print("\n" + "="*60)
        print("SUMMARY")
        print("="*60)
        if "total_benchmarks" in results:
            print(f"Total benchmarks: {results['total_benchmarks']}")
            print(f"Successful: {results['successful']}")
            print(f"Failed: {results['failed']}")
            print(f"Total time: {results['total_time']:.1f}s")
        else:
            print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
