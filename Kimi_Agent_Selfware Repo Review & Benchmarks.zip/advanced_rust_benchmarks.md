# Advanced Rust Code Understanding Benchmarks
## For Visual Language Models (Qwen3.5 Testing)

**Based on Selfware Repository Analysis**

---

## Overview

These advanced benchmarks test expert-level Rust code comprehension, architectural design, and debugging skills. Each benchmark is designed for localhost testing against Qwen3.5 models with evaluation criteria and scoring rubrics.

**Benchmark Categories:**
1. Complex Generic Constraints & Trait Bounds (Difficulty: 9/10)
2. Architectural Improvements (Difficulty: 8/10)
3. Complex Pattern Implementation (Difficulty: 9/10)
4. Unsafe Code Bug Detection (Difficulty: 10/10)
5. Macro & Procedural Macro Design (Difficulty: 9/10)

---

## Benchmark 1: Generic Constraint Analysis

### Task Name: "Hierarchical Memory System Trait Bounds"

### Description
Analyze a complex generic system with multiple trait bounds, associated types, and lifetime constraints from the selfware cognitive module. Identify constraint violations, suggest improvements, and explain the type system interactions.

### Sample Code

```rust
use std::sync::{Arc, RwLock};
use std::collections::HashMap;
use serde::{Serialize, Deserialize};

/// Token-budget aware memory layer trait
pub trait MemoryLayer<B: BudgetPolicy>: Sized + Send + Sync {
    type Item: Clone + Serialize + for<'de> Deserialize<'de>;
    type Iterator<'a>: Iterator<Item = &'a Self::Item>
    where
        Self: 'a,
        Self::Item: 'a;

    fn budget_policy(&self) -> &B;
    fn iter<'a>(&'a self) -> Self::Iterator<'a>;
    fn estimate_tokens(item: &Self::Item) -> usize;
}

/// Budget allocation policy trait
pub trait BudgetPolicy: Clone + Send + Sync + 'static {
    fn max_tokens(&self) -> usize;
    fn allocate(&self, requested: usize) -> usize;
}

/// Hierarchical memory with three layers
pub struct HierarchicalMemory<W, E, S, B>
where
    W: MemoryLayer<B>,
    E: MemoryLayer<B, Item = W::Item>,
    S: MemoryLayer<B, Item = W::Item>,
    B: BudgetPolicy,
{
    working: W,
    episodic: Arc<RwLock<E>>,
    semantic: Arc<RwLock<S>>,
    budget: B,
    token_usage: HashMap<String, usize>,
}

impl<W, E, S, B> HierarchicalMemory<W, E, S, B>
where
    W: MemoryLayer<B>,
    E: MemoryLayer<B, Item = W::Item>,
    S: MemoryLayer<B, Item = W::Item>,
    B: BudgetPolicy,
{
    pub fn new(working: W, episodic: E, semantic: S, budget: B) -> Self {
        Self {
            working,
            episodic: Arc::new(RwLock::new(episodic)),
            semantic: Arc::new(RwLock::new(semantic)),
            budget,
            token_usage: HashMap::new(),
        }
    }

    /// Transfer items from working to episodic memory
    pub fn consolidate(&mut self) -> Result<usize, MemoryError> {
        let mut transferred = 0;
        let mut tokens = 0;

        for item in self.working.iter() {
            let item_tokens = W::estimate_tokens(item);
            if tokens + item_tokens > self.budget.allocate(tokens + item_tokens) {
                break;
            }
            
            // Attempt to write to episodic memory
            let mut episodic = self.episodic.write().map_err(|_| MemoryError::LockPoisoned)?;
            
            // BUG: This doesn't actually insert - trait doesn't have insert method!
            tokens += item_tokens;
            transferred += 1;
        }

        Ok(transferred)
    }
}

#[derive(Debug)]
pub enum MemoryError {
    LockPoisoned,
    BudgetExceeded,
    SerializationFailed,
}

// Concrete implementations
#[derive(Clone)]
pub struct FixedBudget {
    max: usize,
}

impl BudgetPolicy for FixedBudget {
    fn max_tokens(&self) -> usize {
        self.max
    }
    
    fn allocate(&self, requested: usize) -> usize {
        requested.min(self.max)
    }
}

pub struct WorkingMemoryLayer<T, B> {
    items: Vec<T>,
    budget: B,
}

impl<T, B> MemoryLayer<B> for WorkingMemoryLayer<T, B>
where
    T: Clone + Serialize + for<'de> Deserialize<'de> + Send + Sync,
    B: BudgetPolicy,
{
    type Item = T;
    type Iterator<'a> = std::slice::Iter<'a, T>
    where
        T: 'a;

    fn budget_policy(&self) -> &B {
        &self.budget
    }

    fn iter<'a>(&'a self) -> Self::Iterator<'a> {
        self.items.iter()
    }

    fn estimate_tokens(item: &T) -> usize {
        // Simplified estimation
        std::mem::size_of_val(item) / 4
    }
}
```

### Questions

1. **Constraint Analysis**: Identify all trait bounds on `HierarchicalMemory` and explain why each is necessary. What would happen if we removed `E: MemoryLayer<B, Item = W::Item>`?

2. **Lifetime Issues**: The `MemoryLayer::Iterator<'a>` has a where clause `Self: 'a, Self::Item: 'a`. Explain why both constraints are needed and what would break without each.

3. **Bug Detection**: The `consolidate()` method has a commented bug. Identify the actual design flaw and explain why the code cannot work as intended.

4. **GAT Complexity**: The `Iterator` associated type uses a Generic Associated Type (GAT). Rewrite this using a simpler approach (boxed iterator) and discuss the trade-offs.

5. **Variance**: Explain the variance of `HierarchicalMemory` with respect to each type parameter. Is it covariant, contravariant, or invariant for `W`, `E`, `S`, and `B`?

### Expected Output Format

```json
{
  "benchmark_id": "generic_constraints_001",
  "question_responses": {
    "q1": {
      "bounds_identified": ["list of bounds"],
      "necessity_explanation": "explanation",
      "removal_impact": "what breaks if E bound removed"
    },
    "q2": {
      "self_constraint_purpose": "explanation",
      "item_constraint_purpose": "explanation",
      "failure_scenarios": ["scenario1", "scenario2"]
    },
    "q3": {
      "design_flaw": "description of flaw",
      "why_it_fails": "technical explanation",
      "fix_suggestion": "code or approach to fix"
    },
    "q4": {
      "rewritten_code": "simplified version",
      "trade_offs": {
        "performance": "impact",
        "ergonomics": "impact",
        "flexibility": "impact"
      }
    },
    "q5": {
      "variance_analysis": {
        "W": "variance + explanation",
        "E": "variance + explanation",
        "S": "variance + explanation",
        "B": "variance + explanation"
      }
    }
  }
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Q1 - All bounds identified | 15 | Correctly identifies all 4+ trait bounds |
| Q1 - Necessity explained | 10 | Clear explanation of why each bound exists |
| Q2 - Lifetime understanding | 15 | Correct explanation of both constraints |
| Q3 - Bug identified | 15 | Correctly identifies the missing insert capability |
| Q4 - GAT rewrite | 15 | Working simplified code with trade-offs |
| Q5 - Variance correct | 15 | All four variances correctly identified |
| Code quality | 15 | Clear, well-structured responses |
| **Total** | **100** | |

### Scoring Rubric

- **90-100**: Expert level - Deep understanding of advanced type system features
- **80-89**: Proficient - Good understanding with minor gaps
- **70-79**: Competent - Basic understanding, some misconceptions
- **60-69**: Developing - Significant gaps in understanding
- **<60**: Novice - Fundamental misunderstandings

### Difficulty Rating
**9/10** - Tests advanced Rust type system knowledge including GATs, lifetime constraints, variance, and trait bound reasoning.

---

## Benchmark 2: Architectural Improvements

### Task Name: "Token Budget System Refactoring"

### Description
Analyze a token budget management system and propose architectural improvements. The current implementation has coupling, extensibility, and testing issues. Design a more maintainable architecture.

### Sample Code (Current Implementation)

```rust
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::RwLock;
use std::collections::HashMap;

/// Monolithic token tracker with multiple responsibilities
pub struct TokenTracker {
    prompt_tokens: AtomicUsize,
    completion_tokens: AtomicUsize,
    api_calls: AtomicUsize,
    step_usage: RwLock<Vec<StepUsage>>,
    budget_limits: HashMap<String, usize>,
    cost_per_1k_prompt: f64,
    cost_per_1k_completion: f64,
    model_name: String,
}

#[derive(Clone, Debug)]
pub struct StepUsage {
    pub step: usize,
    pub prompt: usize,
    pub completion: usize,
    pub tool_name: Option<String>,
}

impl TokenTracker {
    pub fn new(model: &str) -> Self {
        let (prompt_cost, completion_cost) = match model {
            "gpt-4" => (0.03, 0.06),
            "gpt-3.5-turbo" => (0.0015, 0.002),
            "claude-3-opus" => (0.015, 0.075),
            _ => (0.001, 0.002),
        };

        Self {
            prompt_tokens: AtomicUsize::new(0),
            completion_tokens: AtomicUsize::new(0),
            api_calls: AtomicUsize::new(0),
            step_usage: RwLock::new(Vec::new()),
            budget_limits: HashMap::new(),
            cost_per_1k_prompt: prompt_cost,
            cost_per_1k_completion: completion_cost,
            model_name: model.to_string(),
        }
    }

    pub fn record_usage(&self, prompt: usize, completion: usize) {
        self.prompt_tokens.fetch_add(prompt, Ordering::Relaxed);
        self.completion_tokens.fetch_add(completion, Ordering::Relaxed);
        self.api_calls.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_step(&self, step: usize, prompt: usize, completion: usize, tool_name: Option<String>) {
        if let Ok(mut usage) = self.step_usage.write() {
            usage.push(StepUsage {
                step,
                prompt,
                completion,
                tool_name,
            });
        }
    }

    pub fn estimate_cost(&self) -> f64 {
        let prompt = self.prompt_tokens.load(Ordering::Relaxed) as f64;
        let completion = self.completion_tokens.load(Ordering::Relaxed) as f64;
        
        (prompt / 1000.0) * self.cost_per_1k_prompt +
        (completion / 1000.0) * self.cost_per_1k_completion
    }

    pub fn check_budget(&self, budget_name: &str) -> bool {
        let limit = self.budget_limits.get(budget_name).copied().unwrap_or(usize::MAX);
        let total = self.prompt_tokens.load(Ordering::Relaxed) +
                    self.completion_tokens.load(Ordering::Relaxed);
        total < limit
    }

    pub fn summary(&self) -> TokenSummary {
        TokenSummary {
            prompt_tokens: self.prompt_tokens.load(Ordering::Relaxed),
            completion_tokens: self.completion_tokens.load(Ordering::Relaxed),
            total_tokens: self.total_tokens(),
            api_calls: self.api_calls.load(Ordering::Relaxed),
            estimated_cost: self.estimate_cost(),
        }
    }

    fn total_tokens(&self) -> usize {
        self.prompt_tokens.load(Ordering::Relaxed) +
        self.completion_tokens.load(Ordering::Relaxed)
    }
}

#[derive(Debug, Clone)]
pub struct TokenSummary {
    pub prompt_tokens: usize,
    pub completion_tokens: usize,
    pub total_tokens: usize,
    pub api_calls: usize,
    pub estimated_cost: f64,
}
```

### Tasks

1. **Identify Issues**: List at least 5 architectural/design issues in the current implementation. Consider SRP, OCP, testing, and extensibility.

2. **Propose New Architecture**: Design a refactored system using appropriate patterns (Strategy, Observer, Builder, etc.). Provide:
   - Component diagram (textual description)
   - Trait definitions
   - Key struct definitions

3. **Implementation**: Write the core refactored code implementing your design.

4. **Migration Strategy**: Describe how to migrate from the old system to the new one without breaking existing code.

5. **Testing Improvements**: Explain how your design improves testability and provide example test code.

### Expected Output Format

```json
{
  "benchmark_id": "architectural_improvements_001",
  "issues_identified": [
    {
      "issue": "description",
      "location": "where in code",
      "impact": "why it's problematic"
    }
  ],
  "proposed_architecture": {
    "diagram": "textual component diagram",
    "traits": ["trait definitions"],
    "structs": ["key struct definitions"]
  },
  "implementation": "refactored code",
  "migration_strategy": "step-by-step migration plan",
  "testing_improvements": {
    "explanation": "how testability improved",
    "example_tests": "test code"
  }
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Issue identification (5+ issues) | 20 | Identifies real architectural problems |
| Architecture design | 25 | Well-structured, appropriate patterns |
| Implementation quality | 25 | Clean, idiomatic Rust code |
| Migration strategy | 15 | Practical, non-breaking approach |
| Testing improvements | 15 | Demonstrates improved testability |
| **Total** | **100** | |

### Scoring Rubric

- **90-100**: Excellent architecture - Production-ready design with proper patterns
- **80-89**: Good architecture - Solid design with minor issues
- **70-79**: Adequate - Basic improvements suggested, some gaps
- **60-69**: Limited - Superficial changes, misses key issues
- **<60**: Poor - Doesn't address core problems

### Difficulty Rating
**8/10** - Tests architectural thinking, design pattern knowledge, and refactoring skills.

---

## Benchmark 3: Complex Pattern Implementation

### Task Name: "Agent State Machine with Actor Pattern"

### Description
Implement a robust agent state machine using the Actor pattern with message passing. The system should handle concurrent state transitions, backpressure, and graceful shutdown. This is based on the selfware agent execution model.

### Requirements

Implement the following components:

1. **State Machine**: Agent states (Idle, Planning, Executing, Verifying, Reflecting, Paused, ShuttingDown)
2. **Actor System**: Message-based communication with proper mailboxes
3. **State Transitions**: Valid transitions only (e.g., Idle → Planning, Executing → Verifying)
4. **Concurrent Handling**: Multiple concurrent tool executions
5. **Backpressure**: Handle message queue overflow gracefully
6. **Graceful Shutdown**: Complete current step before stopping

### Provided Interfaces

```rust
use std::collections::VecDeque;
use std::sync::Arc;
use tokio::sync::{mpsc, oneshot, RwLock};
use anyhow::Result;

/// Tool execution result
#[derive(Debug, Clone)]
pub struct ToolResult {
    pub tool_name: String,
    pub success: bool,
    pub output: String,
    pub execution_time_ms: u64,
}

/// Tool to be executed
#[derive(Debug, Clone)]
pub struct ToolCall {
    pub id: String,
    pub name: String,
    pub arguments: serde_json::Value,
}

/// Messages that can be sent to the agent actor
#[derive(Debug)]
pub enum AgentMessage {
    /// Start processing a new task
    StartTask { task: String, respond_to: oneshot::Sender<TaskId> },
    /// Execute a tool
    ExecuteTool { call: ToolCall, respond_to: oneshot::Sender<Result<ToolResult>> },
    /// Get current state
    GetState { respond_to: oneshot::Sender<AgentState> },
    /// Pause execution
    Pause { respond_to: oneshot::Sender<Result<()>> },
    /// Resume execution
    Resume { respond_to: oneshot::Sender<Result<()>> },
    /// Graceful shutdown
    Shutdown { respond_to: oneshot::Sender<Result<()>> },
    /// Cancel current task
    CancelTask { task_id: TaskId, respond_to: oneshot::Sender<Result<()>> },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct TaskId(pub u64);

/// Agent states following PDVR cycle
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AgentState {
    Idle,
    Planning,
    Executing,
    Verifying,
    Reflecting,
    Paused,
    ShuttingDown,
    Error,
}

/// Actor handle for external interaction
#[derive(Debug, Clone)]
pub struct AgentHandle {
    sender: mpsc::Sender<AgentMessage>,
}

impl AgentHandle {
    pub async fn start_task(&self, task: String) -> Result<TaskId> {
        let (tx, rx) = oneshot::channel();
        self.sender.send(AgentMessage::StartTask { task, respond_to: tx }).await?;
        Ok(rx.await?)
    }

    pub async fn execute_tool(&self, call: ToolCall) -> Result<ToolResult> {
        let (tx, rx) = oneshot::channel();
        self.sender.send(AgentMessage::ExecuteTool { call, respond_to: tx }).await?;
        rx.await?
    }

    pub async fn get_state(&self) -> Result<AgentState> {
        let (tx, rx) = oneshot::channel();
        self.sender.send(AgentMessage::GetState { respond_to: tx }).await?;
        Ok(rx.await?)
    }

    pub async fn shutdown(&self) -> Result<()> {
        let (tx, rx) = oneshot::channel();
        self.sender.send(AgentMessage::Shutdown { respond_to: tx }).await?;
        rx.await?
    }
}
```

### Tasks

1. **Implement State Machine**: Define valid state transitions and implement the state machine logic.

2. **Implement Actor**: Create the `AgentActor` struct that processes messages and manages state.

3. **Handle Concurrency**: Implement concurrent tool execution with proper synchronization.

4. **Backpressure**: Implement queue size limits and overflow handling.

5. **Graceful Shutdown**: Ensure current operations complete before shutting down.

6. **Error Handling**: Properly handle and propagate errors through the actor system.

### Expected Output Format

```rust
// Your implementation should include:

// 1. State transition validation
pub struct StateMachine { ... }

// 2. Actor implementation
pub struct AgentActor { ... }

impl AgentActor {
    pub fn new(mailbox_size: usize) -> (Self, AgentHandle) { ... }
    pub async fn run(mut self) { ... }
}

// 3. Example usage
#[tokio::main]
async fn main() -> Result<()> {
    // Demonstrate the actor system
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| State machine correctness | 20 | All valid transitions work, invalid blocked |
| Actor implementation | 20 | Proper message handling, no deadlocks |
| Concurrency handling | 20 | Safe concurrent tool execution |
| Backpressure | 15 | Queue limits, graceful overflow handling |
| Graceful shutdown | 15 | Completes in-flight work before stopping |
| Error handling | 10 | Proper error propagation, no panics |
| **Total** | **100** | |

### Scoring Rubric

- **90-100**: Production quality - Robust, handles edge cases, well-tested patterns
- **80-89**: Solid implementation - Good actor pattern, minor edge case issues
- **70-79**: Functional - Works for main cases, some concurrency issues
- **60-69**: Basic - Core functionality works, significant gaps
- **<60**: Incomplete - Major functionality missing or broken

### Difficulty Rating
**9/10** - Tests advanced async Rust, actor pattern implementation, state machines, and concurrent programming.

---

## Benchmark 4: Unsafe Code Bug Detection

### Task Name: "Safety Scanner Memory Safety Issues"

### Description
Analyze unsafe Rust code from a security scanner and identify all memory safety issues, undefined behavior risks, and logic bugs. Explain each issue and provide fixes.

### Sample Code

```rust
use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_int};
use std::slice;
use std::ptr;
use std::mem;

/// Security scanner for detecting secrets in memory
pub struct SecurityScanner {
    /// Pattern database (externally allocated)
    patterns: *const Pattern,
    pattern_count: usize,
    /// Scan buffer (reused across scans)
    buffer: *mut u8,
    buffer_capacity: usize,
}

#[repr(C)]
pub struct Pattern {
    pub regex_ptr: *const c_char,
    pub severity: c_int,
    pub name: *const c_char,
}

#[derive(Debug)]
pub struct ScanResult {
    pub pattern_name: String,
    pub severity: i32,
    pub position: usize,
    pub matched_text: String,
}

impl SecurityScanner {
    /// Create new scanner with externally-provided patterns
    /// 
    /// # Safety
    /// patterns must be valid for the lifetime of the scanner
    pub unsafe fn new(patterns: *const Pattern, count: usize) -> Self {
        let buffer = libc::malloc(4096) as *mut u8;
        
        Self {
            patterns,
            pattern_count: count,
            buffer,
            buffer_capacity: 4096,
        }
    }

    /// Scan content for secrets
    pub fn scan(&mut self, content: &[u8]) -> Vec<ScanResult> {
        let mut results = Vec::new();
        
        // Resize buffer if needed
        if content.len() > self.buffer_capacity {
            // BUG 1: Potential memory leak - old buffer not freed
            self.buffer = unsafe {
                libc::realloc(self.buffer as *mut _, content.len()) as *mut u8
            };
            self.buffer_capacity = content.len();
        }
        
        // Copy content to buffer
        unsafe {
            ptr::copy_nonoverlapping(
                content.as_ptr(),
                self.buffer,
                content.len()
            );
        }
        
        // Scan with each pattern
        for i in 0..self.pattern_count {
            let pattern = unsafe { &*self.patterns.add(i) };
            
            // BUG 2: No null check before dereferencing
            let regex_str = unsafe {
                CStr::from_ptr(pattern.regex_ptr)
                    .to_string_lossy()
                    .into_owned()
            };
            
            // BUG 3: Creating slice from raw pointer without length validation
            let buffer_slice = unsafe {
                slice::from_raw_parts(self.buffer, self.buffer_capacity)
            };
            
            // Simulate pattern matching
            if let Some(pos) = self.find_pattern(buffer_slice, &regex_str) {
                // BUG 4: Unbounded string creation - potential panic
                let matched = unsafe {
                    let start = self.buffer.add(pos);
                    let len = regex_str.len().min(100);
                    let slice = slice::from_raw_parts(start, len);
                    String::from_utf8_unchecked(slice.to_vec())
                };
                
                results.push(ScanResult {
                    pattern_name: unsafe {
                        CStr::from_ptr(pattern.name)
                            .to_string_lossy()
                            .into_owned()
                    },
                    severity: pattern.severity,
                    position: pos,
                    matched_text: matched,
                });
            }
        }
        
        results
    }

    fn find_pattern(&self, content: &[u8], pattern: &str) -> Option<usize> {
        // Simplified pattern matching
        content.windows(pattern.len())
            .position(|window| window == pattern.as_bytes())
    }

    /// Get raw buffer pointer (for FFI)
    pub fn buffer_ptr(&self) -> *const u8 {
        self.buffer
    }

    /// Set buffer capacity directly (for performance tuning)
    /// 
    /// # Safety
    /// Caller must ensure buffer is properly allocated
    pub unsafe fn set_capacity(&mut self, new_capacity: usize) {
        // BUG 5: No synchronization, can race with scan()
        self.buffer_capacity = new_capacity;
    }
}

impl Drop for SecurityScanner {
    fn drop(&mut self) {
        unsafe {
            // BUG 6: Double-free risk if buffer was reallocated
            libc::free(self.buffer as *mut _);
            
            // BUG 7: patterns is not owned by us, but we're not documenting this
        }
    }
}

/// FFI-exported function for C integration
/// 
/// # Safety
/// All pointers must be valid
#[no_mangle]
pub unsafe extern "C" fn scanner_create(
    patterns: *const Pattern,
    count: c_int,
) -> *mut SecurityScanner {
    // BUG 8: No validation of count parameter
    let scanner = SecurityScanner::new(patterns, count as usize);
    
    // BUG 9: Leaking Box - no corresponding free function provided
    Box::into_raw(Box::new(scanner))
}

/// Export scan results to C
/// 
/// # Safety
/// scanner must be valid, results_out must point to valid memory
#[no_mangle]
pub unsafe extern "C" fn scanner_scan(
    scanner: *mut SecurityScanner,
    content: *const c_char,
    results_out: *mut *mut ScanResult,
    count_out: *mut c_int,
) -> c_int {
    // BUG 10: No null checks
    let scanner = &mut *scanner;
    let content_str = CStr::from_ptr(content).to_bytes();
    
    let results = scanner.scan(content_str);
    
    // BUG 11: Memory leak - results allocated but never freed
    let results_ptr = libc::malloc(
        results.len() * mem::size_of::<ScanResult>()
    ) as *mut ScanResult;
    
    ptr::copy_nonoverlapping(
        results.as_ptr(),
        results_ptr,
        results.len()
    );
    
    *results_out = results_ptr;
    *count_out = results.len() as c_int;
    
    0 // success
}

/// Thread-local scanner storage
thread_local! {
    static THREAD_SCANNER: *mut SecurityScanner = ptr::null_mut();
}

/// Set thread-local scanner
/// 
/// # Safety
/// scanner must be valid for the lifetime of the thread
pub unsafe fn set_thread_scanner(scanner: *mut SecurityScanner) {
    // BUG 12: No synchronization, data race on thread-local
    THREAD_SCANNER.with(|s| {
        *s = scanner;
    });
}

/// Get thread-local scanner
pub fn get_thread_scanner() -> Option<*mut SecurityScanner> {
    unsafe {
        THREAD_SCANNER.with(|s| {
            if s.is_null() {
                None
            } else {
                Some(*s)
            }
        })
    }
}
```

### Tasks

1. **Identify All Bugs**: Find and catalog all memory safety issues, UB risks, and logic bugs. Number each bug clearly.

2. **Classify Severity**: For each bug, classify as:
   - Memory Safety (MS)
   - Undefined Behavior (UB)
   - Logic Error (LE)
   - Resource Leak (RL)

3. **Explain Impact**: Describe what could go wrong in production for each bug.

4. **Provide Fixes**: Show corrected code for each bug.

5. **Safe Abstraction**: Design a safe Rust API that wraps this functionality without `unsafe` in the public interface.

### Expected Output Format

```json
{
  "benchmark_id": "unsafe_bug_detection_001",
  "bugs_found": [
    {
      "id": 1,
      "location": "line X",
      "type": "MS/UB/LE/RL",
      "description": "what the bug is",
      "impact": "what could go wrong",
      "fix": "corrected code"
    }
  ],
  "safe_abstraction": {
    "design": "description of safe API",
    "implementation": "safe wrapper code"
  }
}
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Bugs identified (12+) | 30 | Finds all or most issues |
| Correct classification | 15 | Accurate MS/UB/LE/RL labeling |
| Impact explanation | 15 | Clear, accurate impact descriptions |
| Fix quality | 20 | Correct, idiomatic fixes |
| Safe abstraction | 20 | Well-designed safe wrapper |
| **Total** | **100** | |

### Scoring Rubric

- **90-100**: Expert - Finds all bugs, excellent fixes, perfect safe abstraction
- **80-89**: Advanced - Finds most bugs, good fixes, solid abstraction
- **70-79**: Competent - Finds major bugs, adequate fixes
- **60-69**: Developing - Finds some bugs, fixes have issues
- **<60**: Novice - Misses most bugs, incorrect fixes

### Difficulty Rating
**10/10** - Tests deep understanding of unsafe Rust, memory safety, FFI, and undefined behavior.

---

## Benchmark 5: Macro & Procedural Macro Design

### Task Name: "Cognitive System Derive Macros"

### Description
Design and implement declarative and procedural macros for the cognitive system. Create macros that reduce boilerplate for state management, memory operations, and PDVR cycle implementations.

### Part A: Declarative Macros (macro_rules!)

Create the following macros:

1. **`cognitive_state!`**: Define a cognitive state struct with PDVR cycle support
2. **`memory_layer!`**: Create a memory layer implementation
3. **`pdvr_transition!`**: Define valid state transitions

### Part B: Procedural Macros (proc_macro)

Create derive macros:

1. **`#[derive(CognitiveState)]`**: Auto-implement state management traits
2. **`#[derive(MemoryBudget)]`**: Auto-implement token budget estimation
3. **`#[pdvr_cycle]`**: Attribute macro for PDVR cycle methods

### Sample Code to Enhance

```rust
use serde::{Serialize, Deserialize};

/// Current manual implementation - lots of boilerplate!
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CognitiveState {
    pub cycle_phase: CyclePhase,
    pub working_memory: WorkingMemory,
    pub episodic_memory: EpisodicMemory,
    pub strategic_goals: Vec<StrategicGoal>,
    pub iteration_count: u32,
}

impl CognitiveState {
    pub fn new() -> Self {
        Self {
            cycle_phase: CyclePhase::Plan,
            working_memory: WorkingMemory::default(),
            episodic_memory: EpisodicMemory::default(),
            strategic_goals: Vec::new(),
            iteration_count: 0,
        }
    }

    pub fn transition_to(&mut self, new_phase: CyclePhase) -> Result<(), StateError> {
        let valid = match (&self.cycle_phase, &new_phase) {
            (CyclePhase::Plan, CyclePhase::Do) => true,
            (CyclePhase::Do, CyclePhase::Verify) => true,
            (CyclePhase::Verify, CyclePhase::Reflect) => true,
            (CyclePhase::Reflect, CyclePhase::Plan) => true,
            (CyclePhase::Reflect, CyclePhase::Do) => true,
            _ => false,
        };
        
        if valid {
            self.cycle_phase = new_phase;
            self.iteration_count += 1;
            Ok(())
        } else {
            Err(StateError::InvalidTransition)
        }
    }
}

impl Default for CognitiveState {
    fn default() -> Self {
        Self::new()
    }
}

// Manual token estimation - repetitive!
impl TokenEstimable for CognitiveState {
    fn estimate_tokens(&self) -> usize {
        let mut total = 0;
        total += self.cycle_phase.estimate_tokens();
        total += self.working_memory.estimate_tokens();
        total += self.episodic_memory.estimate_tokens();
        for goal in &self.strategic_goals {
            total += goal.estimate_tokens();
        }
        total += 4; // iteration_count
        total
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum CyclePhase {
    Plan,
    Do,
    Verify,
    Reflect,
}

impl TokenEstimable for CyclePhase {
    fn estimate_tokens(&self) -> usize {
        match self {
            CyclePhase::Plan => 1,
            CyclePhase::Do => 1,
            CyclePhase::Verify => 1,
            CyclePhase::Reflect => 1,
        }
    }
}

pub trait TokenEstimable {
    fn estimate_tokens(&self) -> usize;
}

#[derive(Debug)]
pub enum StateError {
    InvalidTransition,
}

// More boilerplate for WorkingMemory, EpisodicMemory, etc.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct WorkingMemory {
    pub context: String,
    pub hypotheses: Vec<String>,
}

impl TokenEstimable for WorkingMemory {
    fn estimate_tokens(&self) -> usize {
        self.context.len() / 4 + self.hypotheses.iter().map(|h| h.len() / 4).sum::<usize>()
    }
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct EpisodicMemory {
    pub episodes: Vec<Episode>,
}

impl TokenEstimable for EpisodicMemory {
    fn estimate_tokens(&self) -> usize {
        self.episodes.len() * 10
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Episode {
    pub content: String,
    pub timestamp: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StrategicGoal {
    pub description: String,
    pub priority: u8,
}

impl TokenEstimable for StrategicGoal {
    fn estimate_tokens(&self) -> usize {
        self.description.len() / 4 + 1
    }
}
```

### Tasks

1. **Declarative Macros**: Implement `cognitive_state!`, `memory_layer!`, and `pdvr_transition!` macros.

2. **Procedural Macro - CognitiveState**: Create `#[derive(CognitiveState)]` that:
   - Generates `new()` with default initialization
   - Implements `Default`
   - Generates `transition_to()` with compile-time transition validation

3. **Procedural Macro - MemoryBudget**: Create `#[derive(MemoryBudget)]` that:
   - Implements `TokenEstimable`
   - Auto-sums field token estimates
   - Handles enums with variant weights

4. **Attribute Macro - pdvr_cycle**: Create `#[pdvr_cycle]` that:
   - Validates method follows PDVR pattern
   - Auto-generates transition guards
   - Adds instrumentation

5. **Usage Examples**: Show how the macros reduce boilerplate with before/after comparison.

### Expected Output Format

```rust
// 1. Declarative macros
#[macro_export]
macro_rules! cognitive_state {
    // Your implementation
}

#[macro_export]
macro_rules! memory_layer {
    // Your implementation
}

#[macro_export]
macro_rules! pdvr_transition {
    // Your implementation
}

// 2. Procedural macros (in separate crate)
// cognitive_derive/src/lib.rs
use proc_macro::TokenStream;

#[proc_macro_derive(CognitiveState)]
pub fn derive_cognitive_state(input: TokenStream) -> TokenStream {
    // Your implementation
}

#[proc_macro_derive(MemoryBudget)]
pub fn derive_memory_budget(input: TokenStream) -> TokenStream {
    // Your implementation
}

#[proc_macro_attribute]
pub fn pdvr_cycle(args: TokenStream, input: TokenStream) -> TokenStream {
    // Your implementation
}

// 3. Usage examples showing reduced boilerplate
```

### Evaluation Criteria

| Criterion | Points | Description |
|-----------|--------|-------------|
| Declarative macros (3) | 20 | Working, useful macros |
| CognitiveState derive | 20 | Correct, feature-complete |
| MemoryBudget derive | 20 | Correct token estimation |
| pdvr_cycle attribute | 20 | Proper validation, instrumentation |
| Usage examples | 10 | Clear before/after comparison |
| Code quality | 10 | Clean, well-documented macros |
| **Total** | **100** | |

### Scoring Rubric

- **90-100**: Macro expert - All macros work, advanced features, excellent ergonomics
- **80-89**: Proficient - All macros work, minor limitations
- **70-79**: Competent - Most macros work, some features missing
- **60-69**: Developing - Basic macros work, significant gaps
- **<60**: Novice - Macros don't work or are incomplete

### Difficulty Rating
**9/10** - Tests deep macro knowledge, proc-macro implementation, and code generation skills.

---

## Running the Benchmarks

### Localhost Setup for Qwen3.5

1. **Environment Requirements**:
   ```bash
   # Rust toolchain
   rustup default stable
   rustup component add clippy rustfmt
   
   # For proc-macro benchmarks
   cargo new --lib cognitive_derive
   ```

2. **Model Configuration**:
   ```toml
   # selfware.toml
   endpoint = "http://localhost:8080/v1"
   model = "Qwen/Qwen3.5-Coder-32B"
   max_tokens = 32768
   temperature = 0.2  # Lower for consistent results
   ```

3. **Evaluation Script**:
   ```bash
   #!/bin/bash
   # run_benchmark.sh
   
   BENCHMARK=$1
   MODEL="qwen3.5-coder-32b"
   
   echo "Running benchmark: $BENCHMARK"
   echo "Model: $MODEL"
   
   # Send to local LLM endpoint
   curl -X POST http://localhost:8080/v1/chat/completions \
     -H "Content-Type: application/json" \
     -d @"benchmarks/$BENCHMARK/prompt.json" \
     > "results/$BENCHMARK-$MODEL.json"
   
   # Run evaluation
   cargo run --bin evaluate -- "results/$BENCHMARK-$MODEL.json"
   ```

### Evaluation Automation

```rust
// evaluate.rs - Automated benchmark scoring
use serde_json::Value;
use std::fs;

fn evaluate_benchmark(response_path: &str, rubric: &Rubric) -> Score {
    let response: Value = serde_json::from_str(
        &fs::read_to_string(response_path).unwrap()
    ).unwrap();
    
    let mut score = Score::default();
    
    for criterion in &rubric.criteria {
        let points = evaluate_criterion(&response, criterion);
        score.add(criterion.id.clone(), points, criterion.max_points);
    }
    
    score
}

fn main() {
    let benchmarks = vec![
        ("generic_constraints", load_rubric("generic_constraints")),
        ("architectural_improvements", load_rubric("architectural")),
        ("complex_patterns", load_rubric("patterns")),
        ("unsafe_bugs", load_rubric("unsafe")),
        ("macros", load_rubric("macros")),
    ];
    
    for (name, rubric) in benchmarks {
        let score = evaluate_benchmark(
            &format!("results/{}-qwen3.5.json", name),
            &rubric
        );
        
        println!("{}: {}/100", name, score.total);
        println!("  Breakdown: {:?}", score.breakdown);
    }
}
```

---

## Summary

| Benchmark | Difficulty | Focus Area | Key Skills Tested |
|-----------|------------|------------|-------------------|
| 1. Generic Constraints | 9/10 | Type System | GATs, lifetimes, variance, trait bounds |
| 2. Architectural Improvements | 8/10 | Design Patterns | SRP, OCP, refactoring, testing |
| 3. Complex Patterns | 9/10 | Async/Concurrency | Actor pattern, state machines, backpressure |
| 4. Unsafe Bug Detection | 10/10 | Memory Safety | UB identification, FFI safety, safe abstractions |
| 5. Macro Design | 9/10 | Metaprogramming | Declarative macros, proc-macros, code generation |

**Total Benchmark Suite Difficulty: 9/10**

These benchmarks comprehensively test expert-level Rust skills relevant to real-world systems programming, particularly for AI agent frameworks like Selfware.
