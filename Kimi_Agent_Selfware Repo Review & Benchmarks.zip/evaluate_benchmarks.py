#!/usr/bin/env python3
"""
Benchmark Evaluation Script for Rust VLM Testing

This script evaluates visual language model responses against the 5 benchmarks
for Rust code understanding.

Usage:
    python evaluate_benchmarks.py --benchmark pr_code_review --response-file response.txt
    python evaluate_benchmarks.py --all --responses-dir ./responses/
"""

import argparse
import json
import re
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
from pathlib import Path


@dataclass
class EvaluationResult:
    benchmark_name: str
    total_score: int
    max_score: int
    criteria_scores: Dict[str, Tuple[int, int]]  # criterion -> (score, max)
    feedback: List[str]
    passed: bool


class BenchmarkEvaluator:
    """Evaluator for Rust VLM benchmarks."""

    def __init__(self):
        self.evaluators = {
            "pr_code_review": self._eval_pr_code_review,
            "feature_implementation": self._eval_feature_implementation,
            "debugging_issue": self._eval_debugging_issue,
            "performance_optimization": self._eval_performance_optimization,
            "edition_migration": self._eval_edition_migration,
        }

    def evaluate(self, benchmark_name: str, response: str) -> EvaluationResult:
        """Evaluate a response for a specific benchmark."""
        if benchmark_name not in self.evaluators:
            raise ValueError(f"Unknown benchmark: {benchmark_name}")
        return self.evaluators[benchmark_name](response)

    def _eval_pr_code_review(self, response: str) -> EvaluationResult:
        """Evaluate PR code review benchmark."""
        scores = {}
        feedback = []
        
        # Check for sleep() issue detection (30 points)
        sleep_patterns = [
            r"sleep.*10ms",
            r"thread::sleep",
            r"performance.*degradation",
            r"hot path",
        ]
        sleep_detected = any(re.search(p, response, re.I) for p in sleep_patterns)
        scores["critical_issue_detection"] = (30 if sleep_detected else 0, 30)
        if not sleep_detected:
            feedback.append("MISSING: Did not identify the critical sleep() performance issue")
        
        # Check for encode() parameter change (15 points)
        encode_patterns = [
            r"encode.*true",
            r"special tokens",
            r"parameter.*changed",
        ]
        encode_detected = any(re.search(p, response, re.I) for p in encode_patterns)
        scores["encode_detection"] = (15 if encode_detected else 0, 15)
        if not encode_detected:
            feedback.append("MISSING: Did not identify encode() parameter change")
        
        # Check for heuristic factor change (10 points)
        heuristic_patterns = [
            r"factor.*3.*2",
            r"heuristic.*change",
            r"33%.*higher",
        ]
        heuristic_detected = any(re.search(p, response, re.I) for p in heuristic_patterns)
        scores["heuristic_detection"] = (10 if heuristic_detected else 0, 10)
        
        # Check for severity assessment (20 points)
        severity_patterns = [
            r"high.*severity",
            r"critical",
            r"medium.*severity",
            r"low.*severity",
        ]
        severity_count = sum(1 for p in severity_patterns if re.search(p, response, re.I))
        scores["severity_assessment"] = (min(severity_count * 7, 20), 20)
        
        # Check for actionable suggestions (15 points)
        suggestion_patterns = [
            r"remove.*sleep",
            r"revert",
            r"document",
            r"suggestion",
        ]
        suggestion_count = sum(1 for p in suggestion_patterns if re.search(p, response, re.I))
        scores["actionable_suggestions"] = (min(suggestion_count * 5, 15), 15)
        
        # Check for false positives (10 points - deducted for incorrect issues)
        false_positive_indicators = [
            r"memory.*leak",
            r"deadlock",
            r"undefined.*behavior",
        ]
        false_positives = sum(1 for p in false_positive_indicators if re.search(p, response, re.I))
        scores["false_positive_rate"] = (max(0, 10 - false_positives * 5), 10)
        
        total = sum(s[0] for s in scores.values())
        max_total = sum(s[1] for s in scores.values())
        
        return EvaluationResult(
            benchmark_name="pr_code_review",
            total_score=total,
            max_score=max_total,
            criteria_scores=scores,
            feedback=feedback,
            passed=total >= 70
        )

    def _eval_feature_implementation(self, response: str) -> EvaluationResult:
        """Evaluate feature implementation benchmark."""
        scores = {}
        feedback = []
        
        # Check for token bucket implementation (30 points)
        token_bucket_patterns = [
            r"token.*bucket",
            r"tokens.*-\=.*1",
            r"rate_per_sec",
            r"elapsed.*rate",
        ]
        token_bucket = sum(1 for p in token_bucket_patterns if re.search(p, response, re.I))
        scores["token_bucket_impl"] = (min(token_bucket * 10, 30), 30)
        if token_bucket < 2:
            feedback.append("MISSING: Token bucket algorithm not properly implemented")
        
        # Check for pattern consistency (20 points)
        pattern_patterns = [
            r"Arc<Mutex>",
            r"Arc<RwLock>",
            r"tokio::sync",
            r"tracing::",
        ]
        patterns = sum(1 for p in pattern_patterns if re.search(p, response))
        scores["pattern_consistency"] = (min(patterns * 7, 20), 20)
        
        # Check for integration quality (15 points)
        integration_patterns = [
            r"ApiClient",
            r"rate_limiter",
            r"impl.*new",
            r"async.*fn",
        ]
        integration = sum(1 for p in integration_patterns if re.search(p, response))
        scores["integration_quality"] = (min(integration * 5, 15), 15)
        
        # Check for configuration support (10 points)
        config_patterns = [
            r"RateLimitConfig",
            r"requests_per_minute",
            r"burst_size",
            r"Default",
        ]
        config = sum(1 for p in config_patterns if re.search(p, response))
        scores["configuration_support"] = (min(config * 4, 10), 10)
        
        # Check for test coverage (15 points)
        test_patterns = [
            r"#\[cfg\(test\)\]",
            r"#\[tokio::test\]",
            r"assert!",
            r"async fn test_",
        ]
        tests = sum(1 for p in test_patterns if re.search(p, response))
        scores["test_coverage"] = (min(tests * 5, 15), 15)
        
        # Check for documentation (10 points)
        doc_patterns = [
            r"///",
            r"//!",
            r"#\[derive\(Debug",
        ]
        docs = sum(1 for p in doc_patterns if re.search(p, response))
        scores["documentation"] = (min(docs * 5, 10), 10)
        
        total = sum(s[0] for s in scores.values())
        max_total = sum(s[1] for s in scores.values())
        
        return EvaluationResult(
            benchmark_name="feature_implementation",
            total_score=total,
            max_score=max_total,
            criteria_scores=scores,
            feedback=feedback,
            passed=total >= 70
        )

    def _eval_debugging_issue(self, response: str) -> EvaluationResult:
        """Evaluate debugging issue benchmark."""
        scores = {}
        feedback = []
        
        # Check for RefCell identification (30 points)
        refcell_patterns = [
            r"RefCell",
            r"borrow.*across.*await",
            r"already mutably borrowed",
            r"interior mutability",
        ]
        refcell = sum(1 for p in refcell_patterns if re.search(p, response, re.I))
        scores["refcell_identification"] = (min(refcell * 10, 30), 30)
        if refcell < 2:
            feedback.append("MISSING: Did not correctly identify RefCell as the root cause")
        
        # Check for explanation quality (20 points)
        explanation_patterns = [
            r"async.*suspend",
            r"await.*point",
            r"runtime",
            r"borrow.*held",
        ]
        explanation = sum(1 for p in explanation_patterns if re.search(p, response, re.I))
        scores["explanation_quality"] = (min(explanation * 7, 20), 20)
        
        # Check for fix correctness (25 points)
        fix_patterns = [
            r"RwLock",
            r"Mutex",
            r"tokio::sync",
            r"Arc",
        ]
        fix = sum(1 for p in fix_patterns if re.search(p, response))
        scores["fix_correctness"] = (min(fix * 8, 25), 25)
        
        # Check for alternative solutions (15 points)
        alternative_patterns = [
            r"alternative",
            r"or",
            r"simpler",
            r"local.*cache",
        ]
        alternative = sum(1 for p in alternative_patterns if re.search(p, response, re.I))
        scores["alternative_solutions"] = (min(alternative * 7, 15), 15)
        
        # Check for prevention advice (10 points)
        prevention_patterns = [
            r"never.*RefCell.*async",
            r"avoid",
            r"prevention",
            r"best practice",
        ]
        prevention = sum(1 for p in prevention_patterns if re.search(p, response, re.I))
        scores["prevention_advice"] = (min(prevention * 5, 10), 10)
        
        total = sum(s[0] for s in scores.values())
        max_total = sum(s[1] for s in scores.values())
        
        return EvaluationResult(
            benchmark_name="debugging_issue",
            total_score=total,
            max_score=max_total,
            criteria_scores=scores,
            feedback=feedback,
            passed=total >= 70
        )

    def _eval_performance_optimization(self, response: str) -> EvaluationResult:
        """Evaluate performance optimization benchmark."""
        scores = {}
        feedback = []
        
        # Check for bottleneck identification (25 points)
        bottleneck_patterns = [
            r"regex.*scan",
            r"allocation",
            r"to_string",
            r"O\(n\^2\)",
            r"multiple.*pass",
        ]
        bottleneck = sum(1 for p in bottleneck_patterns if re.search(p, response, re.I))
        scores["bottleneck_identification"] = (min(bottleneck * 7, 25), 25)
        if bottleneck < 2:
            feedback.append("MISSING: Did not identify key performance bottlenecks")
        
        # Check for optimization quality (30 points)
        optimization_patterns = [
            r"single.pass",
            r"span",
            r"TextSpan",
            r"with_capacity",
            r"combined.*regex",
        ]
        optimization = sum(1 for p in optimization_patterns if re.search(p, response, re.I))
        scores["optimization_quality"] = (min(optimization * 8, 30), 30)
        
        # Check for code correctness (20 points)
        correctness_patterns = [
            r"fn parse_tool_calls",
            r"impl",
            r"struct.*Span",
            r"Iterator",
        ]
        correctness = sum(1 for p in correctness_patterns if re.search(p, response))
        scores["code_correctness"] = (min(correctness * 7, 20), 20)
        
        # Check for trade-off analysis (15 points)
        tradeoff_patterns = [
            r"trade.off",
            r"complexity",
            r"maintain",
            r"pros.*cons",
        ]
        tradeoff = sum(1 for p in tradeoff_patterns if re.search(p, response, re.I))
        scores["tradeoff_analysis"] = (min(tradeoff * 7, 15), 15)
        
        # Check for quantitative estimates (10 points)
        estimate_patterns = [
            r"\d+%",
            r"\d+x.*faster",
            r"\d+ms",
            r"\d+MB",
        ]
        estimate = sum(1 for p in estimate_patterns if re.search(p, response))
        scores["quantitative_estimates"] = (min(estimate * 4, 10), 10)
        
        total = sum(s[0] for s in scores.values())
        max_total = sum(s[1] for s in scores.values())
        
        return EvaluationResult(
            benchmark_name="performance_optimization",
            total_score=total,
            max_score=max_total,
            criteria_scores=scores,
            feedback=feedback,
            passed=total >= 70
        )

    def _eval_edition_migration(self, response: str) -> EvaluationResult:
        """Evaluate edition migration benchmark."""
        scores = {}
        feedback = []
        
        # Check for Cargo.toml updates (15 points)
        cargo_patterns = [
            r"edition.*=.*\"2024\"",
            r"rust.version.*=.*\"1\.80",
            r"thiserror.*=.*\"2\.0",
            r"tokio.*=.*\"1\.40",
        ]
        cargo = sum(1 for p in cargo_patterns if re.search(p, response))
        scores["cargo_updates"] = (min(cargo * 5, 15), 15)
        if cargo < 2:
            feedback.append("MISSING: Did not properly update Cargo.toml")
        
        # Check for Rust 2024 adaptation (30 points)
        edition_patterns = [
            r"async.*trait",
            r"native.*async",
            r"impl.*Future",
            r"gen.*keyword",
            r"reserved",
        ]
        edition = sum(1 for p in edition_patterns if re.search(p, response, re.I))
        scores["rust_2024_adaptation"] = (min(edition * 8, 30), 30)
        
        # Check for dependency migration (25 points)
        dependency_patterns = [
            r"async_trait",
            r"remove.*async_trait",
            r"breaking.*change",
            r"transparent",
        ]
        dependency = sum(1 for p in dependency_patterns if re.search(p, response, re.I))
        scores["dependency_migration"] = (min(dependency * 8, 25), 25)
        
        # Check for code quality (15 points)
        quality_patterns = [
            r"pub.*fn",
            r"#\[derive",
            r"use ",
        ]
        quality = sum(1 for p in quality_patterns if re.search(p, response))
        scores["code_quality"] = (min(quality * 5, 15), 15)
        
        # Check for documentation (15 points)
        doc_patterns = [
            r"migration.*note",
            r"checklist",
            r"breaking.*change",
            r"potential.*issue",
        ]
        doc = sum(1 for p in doc_patterns if re.search(p, response, re.I))
        scores["documentation"] = (min(doc * 5, 15), 15)
        
        total = sum(s[0] for s in scores.values())
        max_total = sum(s[1] for s in scores.values())
        
        return EvaluationResult(
            benchmark_name="edition_migration",
            total_score=total,
            max_score=max_total,
            criteria_scores=scores,
            feedback=feedback,
            passed=total >= 70
        )


def print_result(result: EvaluationResult, verbose: bool = False):
    """Print evaluation result in a formatted way."""
    print(f"\n{'='*60}")
    print(f"Benchmark: {result.benchmark_name}")
    print(f"{'='*60}")
    print(f"Score: {result.total_score}/{result.max_score} ({100*result.total_score/result.max_score:.1f}%)")
    print(f"Status: {'PASS' if result.passed else 'FAIL'}")
    
    if verbose:
        print(f"\nCriteria Breakdown:")
        for criterion, (score, max_score) in result.criteria_scores.items():
            print(f"  {criterion}: {score}/{max_score}")
    
    if result.feedback:
        print(f"\nFeedback:")
        for msg in result.feedback:
            print(f"  - {msg}")


def main():
    parser = argparse.ArgumentParser(
        description="Evaluate Rust VLM benchmark responses"
    )
    parser.add_argument(
        "--benchmark",
        choices=["pr_code_review", "feature_implementation", "debugging_issue", 
                 "performance_optimization", "edition_migration", "all"],
        default="all",
        help="Which benchmark to evaluate"
    )
    parser.add_argument(
        "--response-file",
        type=Path,
        help="File containing the model response"
    )
    parser.add_argument(
        "--responses-dir",
        type=Path,
        default=Path("./responses"),
        help="Directory containing response files"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Print detailed scoring breakdown"
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON"
    )
    
    args = parser.parse_args()
    
    evaluator = BenchmarkEvaluator()
    results = []
    
    if args.benchmark == "all":
        benchmarks = ["pr_code_review", "feature_implementation", "debugging_issue",
                      "performance_optimization", "edition_migration"]
    else:
        benchmarks = [args.benchmark]
    
    for benchmark_name in benchmarks:
        response_file = args.responses_dir / f"{benchmark_name}.txt"
        
        if args.response_file:
            response_file = args.response_file
        
        if not response_file.exists():
            print(f"Warning: Response file not found: {response_file}")
            continue
        
        response = response_file.read_text()
        result = evaluator.evaluate(benchmark_name, response)
        results.append(result)
        
        if not args.json:
            print_result(result, args.verbose)
    
    if args.json:
        import json as json_module
        output = {
            "results": [
                {
                    "benchmark": r.benchmark_name,
                    "score": r.total_score,
                    "max_score": r.max_score,
                    "percentage": round(100 * r.total_score / r.max_score, 1),
                    "passed": r.passed,
                    "criteria": {k: {"score": v[0], "max": v[1]} 
                                for k, v in r.criteria_scores.items()},
                    "feedback": r.feedback
                }
                for r in results
            ],
            "summary": {
                "total_benchmarks": len(results),
                "passed": sum(1 for r in results if r.passed),
                "failed": sum(1 for r in results if not r.passed),
                "average_score": round(
                    sum(r.total_score for r in results) / 
                    sum(r.max_score for r in results) * 100, 1
                ) if results else 0
            }
        }
        print(json_module.dumps(output, indent=2))
    else:
        # Print summary
        if len(results) > 1:
            print(f"\n{'='*60}")
            print("SUMMARY")
            print(f"{'='*60}")
            total_score = sum(r.total_score for r in results)
            total_max = sum(r.max_score for r in results)
            passed = sum(1 for r in results if r.passed)
            print(f"Total Score: {total_score}/{total_max} ({100*total_score/total_max:.1f}%)")
            print(f"Benchmarks Passed: {passed}/{len(results)}")


if __name__ == "__main__":
    main()
