# Beginner Rust Benchmark Evaluation Guide

## Overview
This guide explains how to evaluate model responses for the beginner Rust code understanding benchmarks.

## Evaluation Types

### 1. Exact Match
- Answer must match the expected answer exactly (case-insensitive)
- Used for: Single word/phrase answers (struct names, variant names, simple values)
- Examples: "Entry", "KeyNotFound", "false", "1.91"

### 2. Contains All
- Answer must contain all key elements from expected answer
- Order doesn't matter
- Used for: Lists, multiple facts, descriptions
- Example: For "4 fields: key: String, value: String...", answer must mention all 4 field names

### 3. Contains Key Terms
- Answer must contain specific technical terms
- Additional context is acceptable
- Used for: Explanations, conceptual questions
- Key terms are marked in **bold** below

## Question-by-Question Scoring Guide

### Benchmark 1: Struct and Enum Recognition (8 points)

| Q | Points | Key Terms to Look For | Partial Credit |
|---|--------|----------------------|----------------|
| 1 | 1 | "Entry" | None - exact match |
| 2 | 2 | **key**, **value**, **tags**, **metadata** | 1 pt if 2-3 fields correct |
| 3 | 2 | **derive**, **Debug**, **Clone**, **Serialize**, **Deserialize**, **automatically implements** | 1 pt if mentions derive but wrong traits |
| 4 | 2 | **KvStoreError**, **KeyNotFound**, **KeyAlreadyExists**, **StorageError**, **SerializationError** | 1 pt if 2-3 variants correct |
| 5 | 1 | **KeyNotFound** | None - exact match |

### Benchmark 2: Function Comprehension (8 points)

| Q | Points | Key Terms to Look For | Partial Credit |
|---|--------|----------------------|----------------|
| 1 | 2 | **creates**, **new Entry**, **constructor** or **builder** | 1 pt if mentions creates but wrong pattern |
| 2 | 2 | **replaces** vs **appends**, **consumes self** vs **mutates** | 1 pt if mentions difference but unclear |
| 3 | 1 | **false** | None - exact match |
| 4 | 1 | **None** | None - exact match |
| 5 | 2 | **&mut self**: with_tags, add_tag; **&self**: has_tag, get_metadata; **modify** vs **read-only** | 1 pt if partially correct |

### Benchmark 3: Cargo.toml Dependencies (9 points)

| Q | Points | Key Terms to Look For | Partial Credit |
|---|--------|----------------------|----------------|
| 1 | 1 | **1.91** | None - exact match |
| 2 | 2 | **tokio**, **rt-multi-thread**, **macros**, **sync**, **time** | 1 pt if mentions tokio but wrong features |
| 3 | 2 | **building/running** vs **tests/benchmarks**, **required** vs **development only** | 1 pt if mentions tests but unclear |
| 4 | 1 | **serde** | None - exact match |
| 5 | 2 | **cargo build --features tui** or similar | 1 pt if mentions --features |
| 6 | 1 | **clap** | None - exact match |

### Benchmark 4: Error Handling (9 points)

| Q | Points | Key Terms to Look For | Partial Credit |
|---|--------|----------------------|----------------|
| 1 | 2 | **Result<String>**, **Ok** (value), **Err** (error) | 1 pt if mentions Result but wrong details |
| 2 | 2 | **save skipped**, **continues**, **returns Ok** | 1 pt if mentions skips save |
| 3 | 2 | **unwraps**, **returns Err early**, **propagates error** | 1 pt if mentions early return |
| 4 | 2 | Valid **match** syntax with **Some** and **None** arms | 1 pt if mentions match but syntax wrong |
| 5 | 1 | **Ok**, **value** | None - exact match |

### Benchmark 5: Pattern Recognition (9 points)

| Q | Points | Key Terms to Look For | Partial Credit |
|---|--------|----------------------|----------------|
| 1 | 2 | **tokio runtime**, **async**, **await** | 1 pt if mentions one concept |
| 2 | 2 | **Default trait**, **KvStore::default()**, **#[derive(Default)]** | 1 pt if mentions Default |
| 3 | 2 | **Display trait**, **fmt method** | 1 pt if mentions Display |
| 4 | 1 | **wildcard**, **matches any**, **remaining variants** | None - exact match |
| 5 | 2 | **compilation error**, **Future**, **need await** | 1 pt if mentions error |

## Automated Evaluation Script

```python
import re

def evaluate_exact_match(response, expected):
    """Case-insensitive exact match."""
    return response.strip().lower() == expected.strip().lower()

def evaluate_contains_all(response, expected_elements):
    """Check if response contains all expected elements."""
    response_lower = response.lower()
    matches = sum(1 for elem in expected_elements if elem.lower() in response_lower)
    return matches / len(expected_elements)

def evaluate_contains_key_terms(response, key_terms):
    """Check if response contains key technical terms."""
    response_lower = response.lower()
    matches = sum(1 for term in key_terms if term.lower() in response_lower)
    return matches / len(key_terms)

def score_benchmark(response_text, benchmark):
    """Score a complete benchmark response."""
    # Parse numbered answers from response
    answers = parse_numbered_answers(response_text)
    
    total_score = 0
    max_score = sum(q['points'] for q in benchmark['questions'])
    
    for question in benchmark['questions']:
        qid = question['id']
        if qid not in answers:
            continue
            
        answer = answers[qid]
        expected = question['expected_answer']
        eval_type = question['evaluation_type']
        
        if eval_type == 'exact_match':
            score = 1.0 if evaluate_exact_match(answer, expected) else 0.0
        elif eval_type == 'contains_all':
            elements = expected.replace(',', ' ').split()
            score = evaluate_contains_all(answer, elements)
        elif eval_type == 'contains_key_terms':
            # Extract key terms from expected answer
            key_terms = extract_key_terms(expected)
            score = evaluate_contains_key_terms(answer, key_terms)
        
        total_score += score * question['points']
    
    return total_score, max_score
```

## Manual Review Guidelines

When automated scoring is ambiguous:

1. **Accept answers that show understanding** even if wording differs
2. **Award partial credit** for partially correct answers
3. **Reject answers that are clearly wrong** even if they contain key terms

### Examples of Acceptable Variations

**Q: What does `new` function do?**
- ✅ "Creates a new Entry instance" 
- ✅ "Constructs an Entry with the given key and value"
- ✅ "Initializes a new Entry struct"

**Q: What is the `?` operator?**
- ✅ "Propagates errors"
- ✅ "Returns early if there's an error"
- ✅ "Unwraps Ok or returns Err"

### Examples of Unacceptable Answers

**Q: What does `new` function do?**
- ❌ "It makes things" (too vague)
- ❌ "Returns a String" (wrong return type)

**Q: What is the `?` operator?**
- ❌ "It's a question mark" (no technical understanding)
- ❌ "It panics on error" (wrong - that's `.unwrap()`)

## Score Interpretation

| Percentage | Level | Description |
|------------|-------|-------------|
| 90-100% | Expert | Full understanding of beginner concepts |
| 70-89% | Proficient | Good understanding, minor gaps |
| 50-69% | Developing | Basic understanding, needs work |
| <50% | Novice | Significant gaps in comprehension |

## Reporting Results

When reporting benchmark results, include:

1. **Raw scores** per benchmark
2. **Percentage scores** per benchmark  
3. **Overall percentage** across all benchmarks
4. **Question-level breakdown** showing which concepts were missed
5. **Common error patterns** observed

Example Report:
```
Benchmark Results Summary
=========================
Model: Qwen3.5-Coder
Endpoint: http://localhost:8000/v1

Scores:
- Benchmark 1 (Struct/Enum): 8/8 (100%)
- Benchmark 2 (Functions): 7/8 (87.5%)
- Benchmark 3 (Cargo.toml): 9/9 (100%)
- Benchmark 4 (Error Handling): 7/9 (77.8%)
- Benchmark 5 (Patterns): 8/9 (88.9%)

Overall: 39/43 (90.7%) - Expert Level

Areas for Improvement:
- Question 4.2: Understanding of conditional behavior
- Question 4.4: Code rewriting with match expressions
```
