#!/usr/bin/env python3
"""
Intermediate Rust Code Understanding Benchmark Runner

This script evaluates visual language model responses against expected outputs
for the intermediate Rust code understanding benchmarks.

Usage:
    python benchmark_runner.py --benchmark trait_analysis --response response.json
    python benchmark_runner.py --all-responses results_dir/
"""

import json
import argparse
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Any
from pathlib import Path


@dataclass
class EvaluationResult:
    """Result of evaluating a single benchmark"""
    benchmark_name: str
    total_points: int
    max_points: int
    criteria_scores: Dict[str, int]
    feedback: List[str]
    passed: bool


class BenchmarkEvaluator:
    """Evaluates model responses for Rust code understanding benchmarks"""
    
    def __init__(self):
        self.benchmarks = {
            "trait_hierarchy_analysis": self._eval_trait_analysis,
            "lifetime_bug_detection": self._eval_lifetime_bugs,
            "refactor_poor_structure": self._eval_refactoring,
            "module_import_analysis": self._eval_module_analysis,
            "concurrency_pattern_analysis": self._eval_concurrency,
        }
    
    def evaluate(self, benchmark_name: str, response: Dict[str, Any]) -> EvaluationResult:
        """Evaluate a response for a specific benchmark"""
        if benchmark_name not in self.benchmarks:
            raise ValueError(f"Unknown benchmark: {benchmark_name}")
        
        return self.benchmarks[benchmark_name](response)
    
    def _eval_trait_analysis(self, response: Dict) -> EvaluationResult:
        """Evaluate trait hierarchy analysis benchmark"""
        scores = {}
        feedback = []
        
        # Q1: Blanket implementations
        q1 = response.get("question_1", {})
        blanket_score = 0
        if "blanket" in str(q1).lower() and "pipeline" in str(q1).lower():
            blanket_score += 1
        if "processor" in str(q1).lower():
            blanket_score += 1
        scores["blanket_impls"] = min(blanket_score, 2)
        if blanket_score < 2:
            feedback.append("Missing or incorrect blanket implementation identification")
        
        # Q2: Associated types
        q2 = response.get("question_2", {})
        assoc_score = 0
        if "error" in str(q2).lower():
            assoc_score += 1
        if "std::error::error" in str(q2).lower() or "error trait" in str(q2).lower():
            assoc_score += 1
        scores["associated_types"] = min(assoc_score, 2)
        
        # Q3: Generic bounds
        q3 = response.get("question_3", {})
        bounds_score = 0
        if "source<i" in str(q3).lower() or "si: source" in str(q3).lower():
            bounds_score += 1
        if "e" in str(q3).lower() and ("unify" in str(q3).lower() or "error" in str(q3).lower()):
            bounds_score += 1
        scores["generic_bounds"] = min(bounds_score, 2)
        
        # Q4: Chaining mechanism
        q4 = response.get("question_4", {})
        chain_score = 0
        if "phantom" in str(q4).lower():
            chain_score += 1
        if "sequential" in str(q4).lower() or "combine" in str(q4).lower():
            chain_score += 1
        scores["chaining"] = min(chain_score, 2)
        
        # Q5: Error handling
        q5 = response.get("question_5", {})
        error_score = 0
        if "first" in str(q5).lower() and "second" in str(q5).lower():
            error_score += 1
        if "source" in str(q5).lower() and "transform" in str(q5).lower():
            error_score += 1
        scores["error_handling"] = min(error_score, 2)
        
        total = sum(scores.values())
        return EvaluationResult(
            benchmark_name="trait_hierarchy_analysis",
            total_points=total,
            max_points=10,
            criteria_scores=scores,
            feedback=feedback,
            passed=total >= 7
        )
    
    def _eval_lifetime_bugs(self, response: Dict) -> EvaluationResult:
        """Evaluate lifetime bug detection benchmark"""
        scores = {}
        feedback = []
        
        response_str = json.dumps(response).lower()
        
        # Issue identification
        issues_found = 0
        if "configbuilder" in response_str and ("temp_data" in response_str or "dropped" in response_str):
            issues_found += 1
        if "parse_config" in response_str and ("dropped" in response_str or "reference" in response_str):
            issues_found += 1
        if "validator" in response_str and "lifetime" in response_str:
            issues_found += 1
        scores["issue_identification"] = min(issues_found, 3)
        
        # Error message accuracy
        error_score = 0
        error_patterns = [
            "cannot return value referencing",
            "does not live long enough",
            "borrowed value",
        ]
        for pattern in error_patterns:
            if pattern in response_str:
                error_score += 1
        scores["error_messages"] = min(error_score, 2)
        
        # Explanation quality
        expl_score = 0
        if "reference" in response_str and ("dropped" in response_str or "scope" in response_str):
            expl_score += 1
        if "self-referential" in response_str or "owned" in response_str:
            expl_score += 1
        scores["explanations"] = min(expl_score, 2)
        
        # Fix quality
        fix_score = 0
        if "owned" in response_str or "string" in response_str or "to_string" in response_str:
            fix_score += 1
        if "clone" in response_str or "rc" in response_str or "arc" in response_str:
            fix_score += 1
        scores["fixes"] = min(fix_score, 2)
        
        # Code quality
        quality_score = 1 if "#derive" in response_str or "new()" in response_str else 0
        scores["code_quality"] = quality_score
        
        total = sum(scores.values())
        return EvaluationResult(
            benchmark_name="lifetime_bug_detection",
            total_points=total,
            max_points=10,
            criteria_scores=scores,
            feedback=feedback,
            passed=total >= 7
        )
    
    def _eval_refactoring(self, response: Dict) -> EvaluationResult:
        """Evaluate code refactoring benchmark"""
        scores = {}
        response_str = json.dumps(response).lower()
        
        # Error enum design
        error_score = 0
        error_variants = ["emptyusername", "invalidemail", "invalidage", "notfound", "parseerror"]
        for variant in error_variants:
            if variant in response_str.replace("_", ""):
                error_score += 1
        scores["error_enum"] = min(error_score, 2)
        
        # Builder pattern
        builder_score = 0
        if "userbuilder" in response_str or "builder" in response_str:
            builder_score += 1
        if "build()" in response_str or ".build(" in response_str:
            builder_score += 1
        scores["builder_pattern"] = min(builder_score, 2)
        
        # Type safety
        type_score = 0
        if "enum" in response_str and ("status" in response_str or "userstatus" in response_str):
            type_score += 1
        if "u8" in response_str:
            type_score += 1
        scores["type_safety"] = min(type_score, 2)
        
        # No panics
        panic_score = 2
        panic_patterns = ["panic!", ".unwrap()", ".expect("]
        for pattern in panic_patterns:
            if pattern in response_str:
                panic_score -= 1
        scores["no_panics"] = max(panic_score, 0)
        
        # API improvements
        api_score = 0
        if "result<" in response_str:
            api_score += 1
        if "option<" in response_str:
            api_score += 1
        scores["api_improvements"] = min(api_score, 2)
        
        total = sum(scores.values())
        return EvaluationResult(
            benchmark_name="refactor_poor_structure",
            total_points=total,
            max_points=10,
            criteria_scores=scores,
            feedback=[],
            passed=total >= 7
        )
    
    def _eval_module_analysis(self, response: Dict) -> EvaluationResult:
        """Evaluate module hierarchy analysis benchmark"""
        scores = {}
        response_str = json.dumps(response).lower()
        
        # Visibility analysis
        vis_score = 0
        visibility_terms = ["public", "private", "pub(", "crate"]
        for term in visibility_terms:
            if term in response_str:
                vis_score += 1
                break
        if "accessible" in response_str or "access" in response_str:
            vis_score += 1
        scores["visibility"] = min(vis_score, 2)
        
        # Import paths
        import_score = 0
        if "selfware::" in response_str or "crate::" in response_str:
            import_score += 1
        if "prelude" in response_str:
            import_score += 1
        scores["import_paths"] = min(import_score, 2)
        
        # Feature gates
        feature_score = 0
        if "feature" in response_str and ("cfg" in response_str or "gate" in response_str):
            feature_score += 1
        if "tui" in response_str and "ui" in response_str:
            feature_score += 1
        scores["feature_gates"] = min(feature_score, 2)
        
        # Re-exports
        reexp_score = 0
        if "re-export" in response_str or "reexport" in response_str:
            reexp_score += 1
        if "convenience" in response_str or "simplify" in response_str:
            reexp_score += 1
        scores["re_exports"] = min(reexp_score, 2)
        
        # Dependencies
        dep_score = 0
        if "depend" in response_str or "chain" in response_str:
            dep_score += 1
        if "executor" in response_str or "tools" in response_str:
            dep_score += 1
        scores["dependencies"] = min(dep_score, 2)
        
        total = sum(scores.values())
        return EvaluationResult(
            benchmark_name="module_import_analysis",
            total_points=total,
            max_points=10,
            criteria_scores=scores,
            feedback=[],
            passed=total >= 6
        )
    
    def _eval_concurrency(self, response: Dict) -> EvaluationResult:
        """Evaluate concurrency pattern analysis benchmark"""
        scores = {}
        response_str = json.dumps(response).lower()
        
        # Synchronization primitives
        prim_score = 0
        primitives = ["rwlock", "mutex", "channel", "notify", "semaphore"]
        for prim in primitives:
            if prim in response_str:
                prim_score += 1
        scores["primitives"] = min(prim_score, 2)
        
        # Deadlock analysis
        deadlock_score = 0
        if "deadlock" in response_str:
            deadlock_score += 1
        if "ratelimiter" in response_str and ("mutex" in response_str or "lock" in response_str):
            deadlock_score += 1
        scores["deadlock"] = min(deadlock_score, 2)
        
        # Performance issues
        perf_score = 0
        if "granularity" in response_str or "critical section" in response_str:
            perf_score += 1
        if "atomic" in response_str or "atomics" in response_str:
            perf_score += 1
        scores["performance"] = min(perf_score, 2)
        
        # Pattern identification
        pattern_score = 0
        patterns = ["producer-consumer", "worker pool", "shared state", "rate limit"]
        for pattern in patterns:
            if pattern.replace("-", " ") in response_str or pattern.replace("-", "") in response_str:
                pattern_score += 1
        scores["patterns"] = min(pattern_score, 2)
        
        # Improvements
        improve_score = 0
        if "tokio::time" in response_str or "interval" in response_str:
            improve_score += 1
        if "select!" in response_str or "cancellation" in response_str:
            improve_score += 1
        scores["improvements"] = min(improve_score, 2)
        
        total = sum(scores.values())
        return EvaluationResult(
            benchmark_name="concurrency_pattern_analysis",
            total_points=total,
            max_points=10,
            criteria_scores=scores,
            feedback=[],
            passed=total >= 7
        )


def format_result(result: EvaluationResult) -> str:
    """Format evaluation result for display"""
    lines = [
        f"\n{'='*60}",
        f"Benchmark: {result.benchmark_name}",
        f"{'='*60}",
        f"Score: {result.total_points}/{result.max_points} ({result.total_points/result.max_points*100:.1f}%)",
        f"Status: {'PASS' if result.passed else 'FAIL'}",
        f"\nCriteria Breakdown:",
    ]
    
    for criterion, score in result.criteria_scores.items():
        lines.append(f"  {criterion}: {score} points")
    
    if result.feedback:
        lines.append(f"\nFeedback:")
        for fb in result.feedback:
            lines.append(f"  - {fb}")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description="Evaluate Rust code understanding benchmark responses"
    )
    parser.add_argument(
        "--benchmark",
        choices=[
            "trait_hierarchy_analysis",
            "lifetime_bug_detection",
            "refactor_poor_structure",
            "module_import_analysis",
            "concurrency_pattern_analysis",
        ],
        help="Benchmark to evaluate"
    )
    parser.add_argument(
        "--response",
        type=str,
        help="Path to JSON response file"
    )
    parser.add_argument(
        "--all-responses",
        type=str,
        help="Directory containing all response JSON files"
    )
    parser.add_argument(
        "--output",
        type=str,
        default="benchmark_results.json",
        help="Output file for results"
    )
    
    args = parser.parse_args()
    
    evaluator = BenchmarkEvaluator()
    results = []
    
    if args.all_responses:
        # Process all response files in directory
        response_dir = Path(args.all_responses)
        for response_file in response_dir.glob("*.json"):
            # Extract benchmark name from filename
            benchmark_name = response_file.stem.replace("_response", "")
            if benchmark_name in evaluator.benchmarks:
                with open(response_file) as f:
                    response = json.load(f)
                result = evaluator.evaluate(benchmark_name, response)
                results.append(result)
                print(format_result(result))
    
    elif args.benchmark and args.response:
        # Process single response
        with open(args.response) as f:
            response = json.load(f)
        result = evaluator.evaluate(args.benchmark, response)
        results.append(result)
        print(format_result(result))
    
    else:
        parser.print_help()
        return
    
    # Save results
    output_data = {
        "results": [
            {
                "benchmark": r.benchmark_name,
                "score": r.total_points,
                "max_score": r.max_points,
                "percentage": r.total_points / r.max_points * 100,
                "passed": r.passed,
                "criteria": r.criteria_scores,
            }
            for r in results
        ],
        "summary": {
            "total_benchmarks": len(results),
            "passed": sum(1 for r in results if r.passed),
            "failed": sum(1 for r in results if not r.passed),
            "average_score": sum(r.total_points for r in results) / sum(r.max_points for r in results) * 100 if results else 0,
        }
    }
    
    with open(args.output, 'w') as f:
        json.dump(output_data, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"Summary: {output_data['summary']['passed']}/{output_data['summary']['total_benchmarks']} benchmarks passed")
    print(f"Average Score: {output_data['summary']['average_score']:.1f}%")
    print(f"Results saved to: {args.output}")


if __name__ == "__main__":
    main()
