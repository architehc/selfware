# Selfware AI Framework - Stability & Long-Running Systems Review

**Repository:** https://github.com/architehc/selfware/  
**Review Focus:** Long-lasting runs, stability, fault tolerance, production reliability

---

## Executive Summary

**Stability Score: 7.5/10**

The Selfware framework has **strong foundations for long-running operation** with comprehensive checkpointing, circuit breakers, memory management, and self-healing capabilities. However, several critical issues must be addressed for true 24/7 reliability.

| Component | Score | Status |
|-----------|-------|--------|
| Checkpointing | 8/10 | ✅ Solid implementation |
| Circuit Breakers | 8/10 | ✅ Proper state machine |
| Memory Management | 7/10 | ⚠️ Good but needs hard limits |
| Self-Healing | 7/10 | ⚠️ Good infrastructure, gaps in feedback loops |
| Resource Monitoring | 7/10 | ⚠️ Monitoring exists, enforcement limited |
| Async Stability | 7/10 | ⚠️ Some blocking I/O in async paths |

---

## 1. CHECKPOINTING & STATE PERSISTENCE (Score: 8/10)

### What's Working Well

**File:** `src/session/checkpoint.rs` (1000+ lines)

```rust
/// Envelope that wraps a checkpoint with an integrity checksum.
#[derive(Debug, Serialize, Deserialize)]
struct CheckpointEnvelope {
    sha256: String,  // HMAC-SHA-256 for integrity
    payload: serde_json::Value,
}
```

**Strengths:**
- ✅ **HMAC-SHA-256 integrity protection** - Prevents tampering and corruption
- ✅ **Differential checkpoints** - Only saves changes, reducing I/O
- ✅ **Versioned format** - Supports migration between versions
- ✅ **Git state capture** - Saves branch, commit, dirty status for reproducibility
- ✅ **Atomic writes** - Uses temp file + rename pattern

**Delta Compression:**
```rust
pub fn compute_delta(&self, base: &TaskCheckpoint) -> Option<CheckpointDelta> {
    // Only capture appended elements
    let new_messages = self.messages[base.messages.len()..].to_vec();
    let new_tool_calls = self.tool_calls[base.tool_calls.len()..].to_vec();
    // ... reduces checkpoint size significantly
}
```

### Critical Issues

**Issue 1: No Checkpoint Cleanup Strategy**
- Checkpoints accumulate indefinitely
- No automatic pruning based on age or count
- **Risk:** Disk exhaustion on long-running systems

**Fix:**
```rust
impl CheckpointManager {
    pub async fn prune_old_checkpoints(&self, max_age: Duration, max_count: usize) -> Result<()> {
        let mut checkpoints = self.list_checkpoints().await?;
        checkpoints.sort_by(|a, b| b.updated_at.cmp(&a.updated_at));
        
        for (i, cp) in checkpoints.iter().enumerate().skip(max_count) {
            if cp.age() > max_age {
                self.delete_checkpoint(&cp.task_id).await?;
            }
        }
        Ok(())
    }
}
```

**Issue 2: Checkpoint Corruption Recovery**
- If latest checkpoint is corrupt, no automatic fallback to earlier checkpoint
- **Risk:** Complete task loss on corruption

**Fix:** Maintain checkpoint chain with automatic rollback:
```rust
pub async fn load_latest_valid(&self, task_id: &str) -> Result<TaskCheckpoint> {
    let checkpoints = self.list_checkpoints(task_id).await?;
    for cp in checkpoints sorted by version desc {
        match self.load(&cp.id).await {
            Ok(valid) => return Ok(valid),
            Err(e) => warn!("Checkpoint {} corrupt: {}", cp.id, e),
        }
    }
    bail!("No valid checkpoint found")
}
```

---

## 2. CIRCUIT BREAKERS (Score: 8/10)

### What's Working Well

**File:** `src/supervision/circuit_breaker.rs`

```rust
pub struct CircuitBreaker {
    state: AtomicU32,  // 0=Closed, 1=Open, 2=HalfOpen
    failure_count: AtomicU32,
    success_count: AtomicU32,
    config: CircuitBreakerConfig,
    last_failure_time: RwLock<Option<Instant>>,
    last_state_change: RwLock<Instant>,
}
```

**Strengths:**
- ✅ **Proper state machine** - Closed → Open → HalfOpen → Closed
- ✅ **Configurable thresholds** - failure_threshold, success_threshold, reset_timeout
- ✅ **Atomic counters** - Thread-safe operation tracking
- ✅ **Async/await compatible** - Full async support

### Minor Issues

**Issue: No Metrics Export**
- Circuit breaker state changes not exported for monitoring
- **Fix:** Add Prometheus metrics:
```rust
async fn transition_to(&self, new_state: CircuitState) {
    metrics::counter!("circuit_breaker.transitions", 1, 
        "old_state" => old_state.to_string(),
        "new_state" => new_state.to_string()
    );
}
```

---

## 3. MEMORY MANAGEMENT (Score: 7/10)

### What's Working Well

**File:** `src/memory.rs`

```rust
const MAX_MEMORY_ENTRIES: usize = 10_000;
const MAX_MEMORY_TOKENS: usize = 500_000;

pub fn add_message(&mut self, msg: &Message) {
    // Entry count eviction
    if self.entries.len() >= MAX_MEMORY_ENTRIES {
        let remove_count = MAX_MEMORY_ENTRIES / 4;
        self.entries.drain(..remove_count);
    }
    
    // Token budget eviction
    while self.total_estimated_tokens() + new_tokens > MAX_MEMORY_TOKENS {
        self.entries.remove(0);
    }
}
```

**Strengths:**
- ✅ **Bounded memory growth** - Hard limits on entries and tokens
- ✅ **Dual eviction strategy** - Count-based and token-based
- ✅ **Context window awareness** - is_near_limit() at 85% threshold

### Critical Issues

**Issue 1: Unbounded pending_messages**
```rust
// src/agent/mod.rs:100
pub(crate) const MAX_PENDING_MESSAGES: usize = 100;

// But in add_message() - no enforcement found!
pub fn queue_message(&mut self, message: String) {
    self.pending_messages.push_back(message);  // No limit check!
}
```

**Fix:**
```rust
pub fn queue_message(&mut self, message: String) {
    if self.pending_messages.len() >= MAX_PENDING_MESSAGES {
        warn!("Pending message queue full, dropping oldest");
        self.pending_messages.pop_front();
    }
    self.pending_messages.push_back(message);
}
```

**Issue 2: No Process Memory Limits**
- MemoryManager tracks system memory but doesn't limit process memory
- **Risk:** OOM killer on Linux

**Fix:** Add cgroup integration or memory allocator hooks

---

## 4. SELF-HEALING (Score: 7/10)

### What's Working Well

**File:** `src/self_healing.rs`

```rust
pub struct ErrorLearner {
    errors: RwLock<VecDeque<ErrorOccurrence>>,
    patterns: RwLock<HashMap<String, ErrorPattern>>,
    recovery_history: RwLock<HashMap<String, Vec<RecoveryResult>>>,
    config: SelfHealingConfig,
}
```

**Strengths:**
- ✅ **Pattern detection** - Groups errors by type:context
- ✅ **Recovery success tracking** - Calculates success rates per pattern
- ✅ **Exponential backoff with jitter** - Prevents thundering herd
- ✅ **Bounded history** - 100 execution history entries max

### Critical Issues

**Issue 1: NO FEEDBACK LOOP** (Critical)
- RecoveryExecutor tracks outcomes but never reports back to ErrorLearner
- `record_recovery()` exists but is never called
- **Impact:** System never learns which strategies work

**Fix:** Connect executor to learner:
```rust
// In RecoveryExecutor::execute_internal()
if let Some(learner) = &self.error_learner {
    learner.record_recovery(pattern_key, &strategy.name, execution.success);
}
```

**Issue 2: No Pattern Persistence**
- All patterns lost on restart
- **Impact:** Each session starts from scratch

**Fix:** Add serialization:
```rust
impl ErrorLearner {
    pub fn persist(&self, path: &Path) -> Result<()> {
        let patterns = self.patterns.read().unwrap();
        fs::write(path, serde_json::to_string(&*patterns)?)?;
        Ok(())
    }
}
```

---

## 5. RESOURCE MONITORING (Score: 7/10)

### What's Working Well

**File:** `src/resource/memory.rs`

```rust
pub async fn monitor(&self) {
    let mut interval = tokio::time::interval(Duration::from_secs(
        self.config.monitor_interval_seconds
    ));
    
    loop {
        interval.tick().await;
        if let Ok(usage) = self.get_usage().await {
            if usage.percent > self.config.emergency_threshold {
                self.trigger_emergency_cleanup().await;
            }
        }
    }
}
```

**Strengths:**
- ✅ **Continuous monitoring** - Async loop with configurable interval
- ✅ **Tiered thresholds** - Warning, critical, emergency levels
- ✅ **Action channel** - Async message passing for cleanup actions

### Issues

**Issue: Soft Limits Only**
- Actions are advisory, not enforced
- No hard memory caps

**Fix:** Add hard limits:
```rust
pub async fn enforce_hard_limit(&self, max_bytes: u64) {
    if self.allocated.load(Ordering::Relaxed) > max_bytes {
        panic!("Hard memory limit exceeded - terminating to prevent OOM");
    }
}
```

---

## 6. ASYNC RUNTIME STABILITY (Score: 7/10)

### Issues Found

**Issue 1: Blocking I/O in Async Context**
```rust
// src/agent/mod.rs - Agent::new()
let content = tokio::fs::read_to_string(&global_memory_path).await?;  // ✅ Good

// But elsewhere (from PRODUCTION_READINESS_REVIEW):
// src/cognitive/rag.rs:397-482 - Uses synchronous WalkDir in async context
```

**Fix:** Use `tokio::task::spawn_blocking` for CPU-intensive or blocking operations:
```rust
let entries = tokio::task::spawn_blocking(|| {
    WalkDir::new(path).into_iter().collect::<Vec<_>>()
}).await?;
```

**Issue 2: Potential Deadlock in Intelligence Module**
```rust
// src/cognitive/intelligence.rs:1178-1189
// Multiple write locks acquired simultaneously
let mut write1 = lock1.write().unwrap();
let mut write2 = lock2.write().unwrap();  // Potential deadlock!
```

**Fix:** Use lock ordering or `parking_lot::deadlock` detection.

---

## 7. RECOMMENDATIONS FOR 24/7 OPERATION

### Critical (Fix Immediately)

1. **Fix feedback loop in self-healing** - Connect RecoveryExecutor to ErrorLearner
2. **Add pattern persistence** - Save learned patterns to disk
3. **Enforce MAX_PENDING_MESSAGES** - Add bounds checking
4. **Add checkpoint cleanup** - Prune old checkpoints automatically

### High Priority (Fix Before Production)

5. **Add hard resource limits** - Enforce memory caps
6. **Fix blocking I/O** - Use spawn_blocking for WalkDir
7. **Add deadlock detection** - Use parking_lot or custom detection
8. **Implement checkpoint fallback** - Load earlier checkpoint on corruption

### Medium Priority (Enhancement)

9. **Add metrics export** - Prometheus/OpenTelemetry integration
10. **Add health check endpoint** - For load balancer integration
11. **Implement graceful shutdown** - Proper cleanup on SIGTERM
12. **Add memory allocator hooks** - Track actual heap usage

---

## Summary

The Selfware framework has **excellent stability infrastructure** but needs:

1. **Close the feedback loop** - Most critical for self-improvement
2. **Add persistence** - Learned patterns must survive restarts
3. **Enforce bounds** - All queues and buffers need hard limits
4. **Clean up resources** - Automatic pruning of old data

**Estimated time to 24/7 stability: 2-3 weeks** with focused effort on critical issues.

The foundation is solid - these are fixable issues that would make the system production-ready for long-running operation.
