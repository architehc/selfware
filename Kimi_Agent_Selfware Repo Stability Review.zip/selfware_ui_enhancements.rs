//! Selfware UI Enhancement Examples
//!
//! These are example implementations of the recommendations from the UI/UX review.
//! These can be integrated into the existing codebase to make the UI "really cool".

// ============================================================================
// 1. Enhanced Animation System
// ============================================================================

use std::time::{Duration, Instant};

/// Typewriter animation for assistant responses
pub struct TypewriterAnimation {
    text: String,
    chars_per_second: f32,
    cursor_char: char,
}

impl TypewriterAnimation {
    pub fn new(text: impl Into<String>) -> Self {
        Self {
            text: text.into(),
            chars_per_second: 50.0, // Natural typing speed
            cursor_char: '▋',
        }
    }

    pub fn with_speed(mut self, chars_per_second: f32) -> Self {
        self.chars_per_second = chars_per_second.max(1.0);
        self
    }

    /// Get the frame at a given time offset
    pub fn frame_at(&self, elapsed: Duration) -> String {
        let chars_to_show = (elapsed.as_secs_f32() * self.chars_per_second) as usize;
        let visible = &self.text[..chars_to_show.min(self.text.len())];
        
        // Blink cursor every 500ms
        let show_cursor = (elapsed.as_millis() / 500) % 2 == 0;
        if show_cursor && chars_to_show < self.text.len() {
            format!("{}{}", visible, self.cursor_char)
        } else {
            visible.to_string()
        }
    }

    /// Check if animation is complete
    pub fn is_complete(&self, elapsed: Duration) -> bool {
        let chars_to_show = (elapsed.as_secs_f32() * self.chars_per_second) as usize;
        chars_to_show >= self.text.len()
    }
}

/// Celebration animation for task completion
pub struct CelebrationAnimation {
    frames: Vec<Vec<String>>,
    current_frame: usize,
}

impl CelebrationAnimation {
    pub fn new() -> Self {
        let frames = vec![
            // Frame 1: Initial spark
            vec![
                "           ".to_string(),
                "     ✦     ".to_string(),
                "           ".to_string(),
            ],
            // Frame 2: Expanding
            vec![
                "           ".to_string(),
                "    ✦ ✦    ".to_string(),
                "           ".to_string(),
            ],
            // Frame 3: Full bloom
            vec![
                "  ✦     ✦  ".to_string(),
                "     ✦     ".to_string(),
                "  ✦     ✦  ".to_string(),
            ],
            // Frame 4: Success message
            vec![
                "  ✦ ✦ ✦ ✦  ".to_string(),
                "  ✦ ✔ ✦ ✦  ".to_string(),
                "  ✦ ✦ ✦ ✦  ".to_string(),
            ],
        ];

        Self {
            frames,
            current_frame: 0,
        }
    }

    pub fn next_frame(&mut self) -> &[String] {
        let frame = &self.frames[self.current_frame];
        self.current_frame = (self.current_frame + 1).min(self.frames.len() - 1);
        frame
    }

    pub fn is_complete(&self) -> bool {
        self.current_frame >= self.frames.len() - 1
    }

    pub fn reset(&mut self) {
        self.current_frame = 0;
    }
}

// ============================================================================
// 2. Achievement System
// ============================================================================

use std::collections::HashSet;
use std::sync::{Arc, Mutex};

/// Achievement types for gamification
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Achievement {
    FirstSprout,      // Complete first task
    GreenThumb,       // Complete 10 tasks
    MasterGardener,   // Complete 100 tasks
    NightOwl,         // Work after midnight
    EarlyBird,        // Work before 6am
    BugHunter,        // Fix a bug
    CodeArchaeologist, // Edit a file older than 1 year
    SpeedDemon,       // Complete task in under 30 seconds
    Perfectionist,    // Run clippy with no warnings
    TeamPlayer,       // Share a journal entry
}

impl Achievement {
    pub fn icon(&self) -> &'static str {
        match self {
            Achievement::FirstSprout => "🌱",
            Achievement::GreenThumb => "🌿",
            Achievement::MasterGardener => "🌳",
            Achievement::NightOwl => "🦉",
            Achievement::EarlyBird => "🐦",
            Achievement::BugHunter => "🐛",
            Achievement::CodeArchaeologist => "🏛️",
            Achievement::SpeedDemon => "⚡",
            Achievement::Perfectionist => "✨",
            Achievement::TeamPlayer => "🤝",
        }
    }

    pub fn title(&self) -> &'static str {
        match self {
            Achievement::FirstSprout => "First Sprout",
            Achievement::GreenThumb => "Green Thumb",
            Achievement::MasterGardener => "Master Gardener",
            Achievement::NightOwl => "Night Owl",
            Achievement::EarlyBird => "Early Bird",
            Achievement::BugHunter => "Bug Hunter",
            Achievement::CodeArchaeologist => "Code Archaeologist",
            Achievement::SpeedDemon => "Speed Demon",
            Achievement::Perfectionist => "Perfectionist",
            Achievement::TeamPlayer => "Team Player",
        }
    }

    pub fn description(&self) -> &'static str {
        match self {
            Achievement::FirstSprout => "Complete your first task in the workshop",
            Achievement::GreenThumb => "Complete 10 tasks",
            Achievement::MasterGardener => "Complete 100 tasks",
            Achievement::NightOwl => "Work on a task after midnight",
            Achievement::EarlyBird => "Work on a task before 6am",
            Achievement::BugHunter => "Fix a bug in your code",
            Achievement::CodeArchaeologist => "Edit a file that hasn't been touched in over a year",
            Achievement::SpeedDemon => "Complete a task in under 30 seconds",
            Achievement::Perfectionist => "Run clippy with zero warnings",
            Achievement::TeamPlayer => "Share a journal entry with your team",
        }
    }

    pub fn rarity(&self) -> Rarity {
        match self {
            Achievement::FirstSprout => Rarity::Common,
            Achievement::GreenThumb => Rarity::Common,
            Achievement::BugHunter => Rarity::Common,
            Achievement::NightOwl => Rarity::Uncommon,
            Achievement::EarlyBird => Rarity::Uncommon,
            Achievement::SpeedDemon => Rarity::Uncommon,
            Achievement::CodeArchaeologist => Rarity::Rare,
            Achievement::Perfectionist => Rarity::Rare,
            Achievement::MasterGardener => Rarity::Epic,
            Achievement::TeamPlayer => Rarity::Epic,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Rarity {
    Common,
    Uncommon,
    Rare,
    Epic,
    Legendary,
}

impl Rarity {
    pub fn color(&self) -> (u8, u8, u8) {
        match self {
            Rarity::Common => (128, 128, 128),    // Gray
            Rarity::Uncommon => (144, 190, 109),  // Green
            Rarity::Rare => (100, 149, 237),      // Blue
            Rarity::Epic => (184, 115, 51),       // Copper/Orange
            Rarity::Legendary => (255, 215, 0),   // Gold
        }
    }
}

/// Achievement tracker
pub struct AchievementTracker {
    unlocked: Arc<Mutex<HashSet<Achievement>>>,
    total_tasks: Arc<Mutex<usize>>,
}

impl AchievementTracker {
    pub fn new() -> Self {
        Self {
            unlocked: Arc::new(Mutex::new(HashSet::new())),
            total_tasks: Arc::new(Mutex::new(0)),
        }
    }

    /// Check and unlock achievements based on current state
    pub fn check_achievements(&self, context: &AchievementContext) -> Vec<Achievement> {
        let mut newly_unlocked = Vec::new();
        let mut unlocked = self.unlocked.lock().unwrap();

        // Check FirstSprout
        if context.tasks_completed >= 1 && !unlocked.contains(&Achievement::FirstSprout) {
            unlocked.insert(Achievement::FirstSprout);
            newly_unlocked.push(Achievement::FirstSprout);
        }

        // Check GreenThumb
        if context.tasks_completed >= 10 && !unlocked.contains(&Achievement::GreenThumb) {
            unlocked.insert(Achievement::GreenThumb);
            newly_unlocked.push(Achievement::GreenThumb);
        }

        // Check MasterGardener
        if context.tasks_completed >= 100 && !unlocked.contains(&Achievement::MasterGardener) {
            unlocked.insert(Achievement::MasterGardener);
            newly_unlocked.push(Achievement::MasterGardener);
        }

        // Check NightOwl
        if context.hour >= 0 && context.hour < 6 && !unlocked.contains(&Achievement::NightOwl) {
            unlocked.insert(Achievement::NightOwl);
            newly_unlocked.push(Achievement::NightOwl);
        }

        // Check EarlyBird
        if context.hour >= 5 && context.hour < 9 && !unlocked.contains(&Achievement::EarlyBird) {
            unlocked.insert(Achievement::EarlyBird);
            newly_unlocked.push(Achievement::EarlyBird);
        }

        // Check SpeedDemon
        if context.task_duration_secs < 30 && !unlocked.contains(&Achievement::SpeedDemon) {
            unlocked.insert(Achievement::SpeedDemon);
            newly_unlocked.push(Achievement::SpeedDemon);
        }

        newly_unlocked
    }

    /// Render achievement unlock notification
    pub fn render_achievement_unlock(achievement: Achievement) -> String {
        let (r, g, b) = achievement.rarity().color();
        format!(
            "\n  {} Achievement Unlocked!\n  {} {}\n  {}\n",
            "🏆",
            achievement.icon(),
            achievement.title(),
            achievement.description()
        )
    }

    /// Get all unlocked achievements
    pub fn unlocked_achievements(&self) -> Vec<Achievement> {
        self.unlocked.lock().unwrap().iter().copied().collect()
    }

    /// Get progress toward next achievement
    pub fn progress_toward(&self, achievement: Achievement) -> (usize, usize) {
        let total = *self.total_tasks.lock().unwrap();
        match achievement {
            Achievement::FirstSprout => (total.min(1), 1),
            Achievement::GreenThumb => (total.min(10), 10),
            Achievement::MasterGardener => (total.min(100), 100),
            _ => (0, 1), // Binary achievements
        }
    }
}

pub struct AchievementContext {
    pub tasks_completed: usize,
    pub hour: u32,
    pub task_duration_secs: u64,
    pub clippy_warnings: usize,
    pub file_age_days: u64,
}

// ============================================================================
// 3. Enhanced Keyboard Navigation (Vim Mode)
// ============================================================================

use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};

/// Vim-style navigation mode
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum NavigationMode {
    #[default]
    Normal,
    Insert,
    Visual,
    Command,
}

/// Enhanced key handler with vim support
pub struct KeyHandler {
    mode: NavigationMode,
    command_buffer: String,
}

impl KeyHandler {
    pub fn new() -> Self {
        Self {
            mode: NavigationMode::Normal,
            command_buffer: String::new(),
        }
    }

    pub fn handle_key(&mut self, key: KeyEvent) -> Action {
        match self.mode {
            NavigationMode::Normal => self.handle_normal_key(key),
            NavigationMode::Insert => self.handle_insert_key(key),
            NavigationMode::Visual => self.handle_visual_key(key),
            NavigationMode::Command => self.handle_command_key(key),
        }
    }

    fn handle_normal_key(&mut self, key: KeyEvent) -> Action {
        match (key.code, key.modifiers) {
            // Navigation
            (KeyCode::Char('h'), KeyModifiers::NONE) => Action::MoveLeft,
            (KeyCode::Char('j'), KeyModifiers::NONE) => Action::MoveDown,
            (KeyCode::Char('k'), KeyModifiers::NONE) => Action::MoveUp,
            (KeyCode::Char('l'), KeyModifiers::NONE) => Action::MoveRight,
            
            // Mode switching
            (KeyCode::Char('i'), KeyModifiers::NONE) => {
                self.mode = NavigationMode::Insert;
                Action::EnterInsertMode
            }
            (KeyCode::Char('v'), KeyModifiers::NONE) => {
                self.mode = NavigationMode::Visual;
                Action::EnterVisualMode
            }
            (KeyCode::Char(':'), KeyModifiers::NONE) => {
                self.mode = NavigationMode::Command;
                Action::EnterCommandMode
            }
            
            // Actions
            (KeyCode::Char('q'), KeyModifiers::NONE) => Action::Quit,
            (KeyCode::Char('w'), KeyModifiers::NONE) => Action::Save,
            (KeyCode::Char('e'), KeyModifiers::NONE) => Action::OpenFile,
            (KeyCode::Char('g'), KeyModifiers::NONE) => Action::GotoTop,
            (KeyCode::Char('G'), KeyModifiers::SHIFT) => Action::GotoBottom,
            
            // Pane navigation
            (KeyCode::Char('w'), KeyModifiers::CONTROL) => Action::NextPane,
            (KeyCode::Char('W'), KeyModifiers::CONTROL | KeyModifiers::SHIFT) => Action::PrevPane,
            
            _ => Action::None,
        }
    }

    fn handle_insert_key(&mut self, key: KeyEvent) -> Action {
        match (key.code, key.modifiers) {
            (KeyCode::Esc, KeyModifiers::NONE) => {
                self.mode = NavigationMode::Normal;
                Action::EnterNormalMode
            }
            (KeyCode::Char(c), KeyModifiers::NONE) => Action::InsertChar(c),
            (KeyCode::Backspace, KeyModifiers::NONE) => Action::Backspace,
            (KeyCode::Enter, KeyModifiers::NONE) => Action::Submit,
            _ => Action::None,
        }
    }

    fn handle_visual_key(&mut self, key: KeyEvent) -> Action {
        match (key.code, key.modifiers) {
            (KeyCode::Esc, KeyModifiers::NONE) => {
                self.mode = NavigationMode::Normal;
                Action::EnterNormalMode
            }
            (KeyCode::Char('y'), KeyModifiers::NONE) => Action::Yank,
            (KeyCode::Char('d'), KeyModifiers::NONE) => Action::Delete,
            _ => Action::None,
        }
    }

    fn handle_command_key(&mut self, key: KeyEvent) -> Action {
        match (key.code, key.modifiers) {
            (KeyCode::Esc, KeyModifiers::NONE) => {
                self.command_buffer.clear();
                self.mode = NavigationMode::Normal;
                Action::EnterNormalMode
            }
            (KeyCode::Enter, KeyModifiers::NONE) => {
                let cmd = std::mem::take(&mut self.command_buffer);
                self.mode = NavigationMode::Normal;
                Action::ExecuteCommand(cmd)
            }
            (KeyCode::Char(c), KeyModifiers::NONE) => {
                self.command_buffer.push(c);
                Action::None
            }
            (KeyCode::Backspace, KeyModifiers::NONE) => {
                self.command_buffer.pop();
                Action::None
            }
            _ => Action::None,
        }
    }

    pub fn current_mode(&self) -> NavigationMode {
        self.mode
    }

    pub fn command_buffer(&self) -> &str {
        &self.command_buffer
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum Action {
    None,
    MoveLeft,
    MoveRight,
    MoveUp,
    MoveDown,
    MoveTo(usize, usize),
    EnterInsertMode,
    EnterNormalMode,
    EnterVisualMode,
    EnterCommandMode,
    InsertChar(char),
    Backspace,
    Submit,
    Quit,
    Save,
    OpenFile,
    GotoTop,
    GotoBottom,
    NextPane,
    PrevPane,
    Yank,
    Delete,
    ExecuteCommand(String),
}

// ============================================================================
// 4. Smart Suggestions
// ============================================================================

/// Smart suggestion system
pub struct SmartSuggestions {
    suggestions: Vec<Suggestion>,
}

#[derive(Debug, Clone)]
pub struct Suggestion {
    pub trigger: &'static str,
    pub command: &'static str,
    pub description: &'static str,
    pub icon: &'static str,
}

impl SmartSuggestions {
    pub fn new() -> Self {
        let suggestions = vec![
            Suggestion {
                trigger: "fix",
                command: "/fix",
                description: "Fix issues in a file",
                icon: "🔧",
            },
            Suggestion {
                trigger: "test",
                command: "/test",
                description: "Run tests matching a pattern",
                icon: "🧪",
            },
            Suggestion {
                trigger: "doc",
                command: "/doc",
                description: "Generate documentation",
                icon: "📚",
            },
            Suggestion {
                trigger: "refactor",
                command: "/refactor",
                description: "Refactor code",
                icon: "✨",
            },
            Suggestion {
                trigger: "explain",
                command: "/explain",
                description: "Explain code",
                icon: "💡",
            },
            Suggestion {
                trigger: "review",
                command: "/review",
                description: "Review code",
                icon: "👀",
            },
            Suggestion {
                trigger: "garden",
                command: "/garden",
                description: "View digital garden",
                icon: "🌱",
            },
            Suggestion {
                trigger: "journal",
                command: "/journal",
                description: "Browse journal entries",
                icon: "📓",
            },
        ];

        Self { suggestions }
    }

    /// Get suggestions for input
    pub fn suggest(&self, input: &str) -> Vec<&Suggestion> {
        let input_lower = input.to_lowercase();
        self.suggestions
            .iter()
            .filter(|s| {
                s.trigger.starts_with(&input_lower) || 
                s.command.starts_with(&input_lower) ||
                s.description.to_lowercase().contains(&input_lower)
            })
            .collect()
    }

    /// Render suggestions
    pub fn render_suggestions(&self, input: &str) -> String {
        let suggestions = self.suggest(input);
        if suggestions.is_empty() {
            return String::new();
        }

        let mut output = "\n  Suggestions:\n".to_string();
        for suggestion in suggestions.iter().take(3) {
            output.push_str(&format!(
                "    {} {} {} - {}\n",
                suggestion.icon,
                suggestion.command,
                "·",
                suggestion.description
            ));
        }
        output
    }
}

// ============================================================================
// 5. Contextual Help
// ============================================================================

use crate::ui::tui::app::AppState;

/// Contextual help system
pub struct ContextualHelp;

impl ContextualHelp {
    /// Get help text for current state
    pub fn for_state(state: &AppState) -> &'static str {
        match state {
            AppState::Chatting => "Type a message and press Enter • Ctrl+P: Commands • ?: Help • q: Quit",
            AppState::RunningTask => "Space: Pause • Ctrl+C: Cancel • z: Toggle zoom",
            AppState::Palette => "Type to search • ↑↓: Navigate • Enter: Select • Esc: Close",
            AppState::FileBrowser => "↑↓: Navigate • Enter: Open • Esc: Back • /: Search",
            AppState::Help => "↑↓: Scroll • q: Close help",
            AppState::Confirming(_) => "y: Confirm • n: Cancel",
        }
    }

    /// Get keyboard shortcuts for current state
    pub fn shortcuts_for_state(state: &AppState) -> Vec<(&'static str, &'static str)> {
        match state {
            AppState::Chatting => vec![
                ("Enter", "Send message"),
                ("Ctrl+P", "Command palette"),
                ("Ctrl+D", "Toggle dashboard"),
                ("Ctrl+G", "Toggle garden view"),
                ("Tab", "Next pane"),
                ("?", "Show help"),
                ("q", "Quit"),
            ],
            AppState::Palette => vec![
                ("↑↓", "Navigate"),
                ("Enter", "Select"),
                ("Esc", "Close"),
            ],
            _ => vec![],
        }
    }

    /// Render help overlay
    pub fn render_help_overlay(state: &AppState) -> String {
        let shortcuts = Self::shortcuts_for_state(state);
        let mut output = "\n  Keyboard Shortcuts:\n".to_string();
        
        for (key, action) in shortcuts {
            output.push_str(&format!("    {:<12} {}\n", key, action));
        }
        
        output
    }
}

// ============================================================================
// 6. Theme Preview
// ============================================================================

use crate::ui::theme::{theme_colors, ThemeId};

/// Theme preview generator
pub struct ThemePreview;

impl ThemePreview {
    /// Generate a preview of a theme
    pub fn generate(theme_id: ThemeId, width: usize) -> String {
        let theme = theme_colors(theme_id);
        let mut output = format!("\n  {:?} Theme Preview:\n\n", theme_id);

        // Color swatches
        let swatches = vec![
            ("Primary", theme.primary),
            ("Success", theme.success),
            ("Warning", theme.warning),
            ("Error", theme.error),
            ("Muted", theme.muted),
            ("Accent", theme.accent),
            ("Tool", theme.tool),
            ("Path", theme.path),
        ];

        for (name, color) in swatches {
            let swatch = "████".to_string();
            output.push_str(&format!(
                "  {} {:<10} RGB({}, {}, {})\n",
                swatch, name, color.r, color.g, color.b
            ));
        }

        // Sample text
        output.push_str("\n  Sample Text:\n");
        output.push_str("  This is how your workshop will look.\n");
        output.push_str("  Tasks, tools, and garden status will appear here.\n");

        output
    }

    /// Generate comparison of all themes
    pub fn generate_comparison(width: usize) -> String {
        let themes = vec![
            ThemeId::Amber,
            ThemeId::Ocean,
            ThemeId::Minimal,
            ThemeId::Dracula,
            ThemeId::Nord,
            ThemeId::Gruvbox,
        ];

        let mut output = "\n  Theme Comparison:\n\n".to_string();

        for theme_id in themes {
            let theme = theme_colors(theme_id);
            output.push_str(&format!(
                "  {:?}: ████ ████ ████\n",
                theme_id,
            ));
        }

        output.push_str("\n  Use /theme <name> to switch themes.\n");
        output
    }
}

// ============================================================================
// 7. Responsive Layout
// ============================================================================

/// Responsive layout helper
pub struct ResponsiveLayout;

impl ResponsiveLayout {
    /// Get appropriate layout for terminal size
    pub fn layout_for_size(width: u16, height: u16) -> LayoutType {
        if width < 60 || height < 20 {
            LayoutType::Compact
        } else if width < 100 {
            LayoutType::Standard
        } else {
            LayoutType::Wide
        }
    }

    /// Get message width for terminal size
    pub fn message_width(term_width: u16) -> usize {
        match term_width {
            0..=60 => (term_width as usize).saturating_sub(4),
            61..=100 => 60,
            _ => 80,
        }
    }

    /// Get appropriate header style
    pub fn header_style(width: u16) -> HeaderStyle {
        match width {
            0..=50 => HeaderStyle::Minimal,
            51..=80 => HeaderStyle::Standard,
            _ => HeaderStyle::Full,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LayoutType {
    Compact,   // Small terminals
    Standard,  // Normal terminals
    Wide,      // Large terminals
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HeaderStyle {
    Minimal,   // Just "Selfware"
    Standard,  // "Selfware Workshop"
    Full,      // Full ASCII art banner
}

// ============================================================================
// Usage Examples
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_typewriter_animation() {
        let anim = TypewriterAnimation::new("Hello, world!");
        
        // At start, should show nothing or just cursor
        let frame = anim.frame_at(Duration::from_millis(0));
        assert!(frame.is_empty() || frame.contains('▋'));
        
        // After 1 second at 50 chars/sec, should show ~50 chars
        let frame = anim.frame_at(Duration::from_secs(1));
        assert!(!frame.is_empty());
    }

    #[test]
    fn test_achievement_unlock() {
        let output = AchievementTracker::render_achievement_unlock(Achievement::FirstSprout);
        assert!(output.contains("First Sprout"));
        assert!(output.contains("🌱"));
    }

    #[test]
    fn test_key_handler_mode_switching() {
        let mut handler = KeyHandler::new();
        assert_eq!(handler.current_mode(), NavigationMode::Normal);

        // Press 'i' to enter insert mode
        handler.handle_key(KeyEvent::from(KeyCode::Char('i')));
        assert_eq!(handler.current_mode(), NavigationMode::Insert);

        // Press Esc to return to normal mode
        handler.handle_key(KeyEvent::from(KeyCode::Esc));
        assert_eq!(handler.current_mode(), NavigationMode::Normal);
    }

    #[test]
    fn test_smart_suggestions() {
        let suggestions = SmartSuggestions::new();
        
        let results = suggestions.suggest("fi");
        assert!(!results.is_empty());
        
        // Should match "fix"
        assert!(results.iter().any(|s| s.trigger == "fix"));
    }

    #[test]
    fn test_responsive_layout() {
        assert_eq!(ResponsiveLayout::layout_for_size(40, 20), LayoutType::Compact);
        assert_eq!(ResponsiveLayout::layout_for_size(80, 30), LayoutType::Standard);
        assert_eq!(ResponsiveLayout::layout_for_size(120, 40), LayoutType::Wide);
    }
}
