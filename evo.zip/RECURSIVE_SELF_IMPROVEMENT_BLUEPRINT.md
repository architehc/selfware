# Selfware Recursive Self-Improvement: Engineering Blueprint

## Critical Path: What's Missing Today

Selfware has all the raw ingredients — PDVR cognitive loop, 16-agent swarm, SAB benchmark, git checkpoints, Docker support, 5200+ tests. But the loop isn't closed. Today the agent edits *other people's code*; it can't systematically evolve *itself*. Here's the concrete wiring needed.

---

## Phase 0: Prerequisites (1-2 days)

### Add Dependencies to Cargo.toml

```toml
[dependencies]
syn = { version = "2", features = ["full", "parsing", "printing", "visit-mut"] }
quote = "1"
proc-macro2 = "1"
serde_json = "1"  # already present

[dev-dependencies]
proptest = "1"
cargo-mutants = "24"  # CLI tool, install separately
```

### Create Module Structure

```
src/
├── evolution/
│   ├── mod.rs              # Public API
│   ├── ast_tools.rs        # AST-aware mutation tools
│   ├── sandbox.rs          # Docker-based parallel evaluation
│   ├── tournament.rs       # Selection + merge logic
│   ├── telemetry.rs        # Criterion/flamegraph exposure
│   ├── fitness.rs          # Meta-SAB scoring engine
│   └── daemon.rs           # `selfware evolve` command
```

---

## Phase 1: AST-Aware Mutation Tools (Principle 1)

### Problem
`file_edit` and `file_write` treat Rust as raw strings. The LLM can generate syntactically broken mutations that waste entire compilation cycles (30-60s each on large projects).

### Solution: `ast_mutate` Tool

```rust
// src/evolution/ast_tools.rs

use syn::{parse_file, Item, visit_mut::VisitMut};
use quote::ToTokens;
use std::process::Command;

pub struct AstMutationRequest {
    pub target_file: PathBuf,
    pub target_fn: String,          // e.g., "estimate_tokens"
    pub mutation_type: MutationType,
    pub new_body: String,           // Rust code for the new function body
}

pub enum MutationType {
    ReplaceFnBody,
    AddParameter { name: String, ty: String },
    WrapInCache { cache_key: String },
    ExtractToModule { module_name: String },
    InlineConstants,
}

pub struct AstMutationResult {
    pub success: bool,
    pub compiler_errors: Vec<CompilerSpan>,
    pub diff: String,
    pub worktree_path: PathBuf,
}

/// The core "physics engine" — compiler as law of nature
pub fn apply_ast_mutation(req: AstMutationRequest) -> AstMutationResult {
    // 1. Create shadow worktree (already configured in .claude/worktrees)
    let worktree = create_shadow_worktree()?;
    
    // 2. Parse the target file into AST
    let source = fs::read_to_string(&worktree.join(&req.target_file))?;
    let mut ast = parse_file(&source)?;
    
    // 3. Apply mutation via syn visitor
    let mut mutator = FnBodyReplacer {
        target: req.target_fn.clone(),
        new_body: syn::parse_str(&req.new_body)?,
        found: false,
    };
    mutator.visit_file_mut(&mut ast);
    
    if !mutator.found {
        return AstMutationResult::not_found(req.target_fn);
    }
    
    // 4. Write mutated AST back (preserves formatting better than string edits)
    let mutated = ast.to_token_stream().to_string();
    let formatted = run_rustfmt(&mutated)?;
    fs::write(worktree.join(&req.target_file), &formatted)?;
    
    // 5. SYNCHRONOUS PHYSICS CHECK — the inviolable law
    let check = Command::new("cargo")
        .args(["check", "--message-format=json"])
        .current_dir(&worktree)
        .output()?;
    
    if !check.status.success() {
        let errors = parse_compiler_json(&check.stderr);
        // IMMEDIATE REJECTION — FROST ❄️
        cleanup_worktree(&worktree);
        return AstMutationResult {
            success: false,
            compiler_errors: errors,
            diff: String::new(),
            worktree_path: worktree,
        };
    }
    
    // 6. Generate diff for agent's working memory
    let diff = generate_diff(&source, &formatted);
    
    AstMutationResult {
        success: true,
        compiler_errors: vec![],
        diff,
        worktree_path: worktree,
    }
}
```

### Integration Point
Register as tool #55 in `src/tools/mod.rs`:
```rust
Tool::new("ast_mutate", "🧬 Mutate a function via AST transformation with compiler verification")
```

The agent calls it like any other tool — but physically cannot commit non-compiling code.

---

## Phase 2: Parallel Sandbox Evaluation (Principle 2)

### Problem
Sequential hypothesis testing is too slow. If the agent identifies a bottleneck, testing 8 approaches one-at-a-time takes 8x the wall clock.

### Solution: Docker Tournament Arena

```rust
// src/evolution/sandbox.rs

use tokio::process::Command;
use futures::future::join_all;

pub struct Hypothesis {
    pub id: String,
    pub description: String,
    pub patch: String,        // unified diff
    pub target_files: Vec<PathBuf>,
}

pub struct TournamentConfig {
    pub max_parallel: usize,  // default: 8, bounded by CPU cores
    pub timeout: Duration,    // per-hypothesis timeout
    pub fitness_fn: FitnessFunction,
}

pub struct HypothesisResult {
    pub id: String,
    pub compiled: bool,
    pub tests_passed: usize,
    pub tests_total: usize,
    pub execution_time: Duration,
    pub peak_memory_bytes: u64,
    pub benchmark_scores: HashMap<String, f64>,
}

pub async fn run_tournament(
    hypotheses: Vec<Hypothesis>,
    config: TournamentConfig,
) -> Vec<HypothesisResult> {
    let semaphore = Arc::new(Semaphore::new(config.max_parallel));
    
    let futures: Vec<_> = hypotheses.into_iter().map(|h| {
        let sem = semaphore.clone();
        let cfg = config.clone();
        async move {
            let _permit = sem.acquire().await.unwrap();
            evaluate_in_sandbox(h, &cfg).await
        }
    }).collect();
    
    let mut results = join_all(futures).await;
    
    // Tournament selection: sort by composite fitness
    results.sort_by(|a, b| {
        config.fitness_fn.score(b).partial_cmp(
            &config.fitness_fn.score(a)
        ).unwrap()
    });
    
    results
}

async fn evaluate_in_sandbox(
    hypothesis: Hypothesis,
    config: &TournamentConfig,
) -> HypothesisResult {
    let container_name = format!("selfware-arena-{}", hypothesis.id);
    
    // 1. Spin up isolated container from selfware Dockerfile
    let _ = Command::new("docker")
        .args(["run", "-d", "--name", &container_name,
               "--cpus=2", "--memory=4g",  // resource limits
               "-v", &format!("{}:/workspace", get_repo_root()),
               "selfware:latest", "sleep", "infinity"])
        .output().await?;
    
    // 2. Apply the hypothesis patch inside container
    let _ = docker_exec(&container_name, &format!(
        "cd /workspace && echo '{}' | git apply -",
        hypothesis.patch
    )).await;
    
    // 3. Compile
    let compile = docker_exec_timed(&container_name,
        "cd /workspace && cargo build --release 2>&1",
        config.timeout
    ).await;
    
    if !compile.success {
        cleanup_container(&container_name).await;
        return HypothesisResult::compile_failed(hypothesis.id);
    }
    
    // 4. Run tests
    let test_result = docker_exec_timed(&container_name,
        "cd /workspace && cargo test --all-features 2>&1",
        config.timeout
    ).await;
    
    // 5. Run benchmarks (if tests pass)
    let bench_result = if test_result.all_passed {
        docker_exec_timed(&container_name,
            "cd /workspace && cargo bench --bench '*' -- --output-format bencher 2>&1",
            config.timeout
        ).await
    } else {
        BenchResult::skipped()
    };
    
    // 6. Measure resource usage
    let stats = docker_stats(&container_name).await;
    
    cleanup_container(&container_name).await;
    
    HypothesisResult {
        id: hypothesis.id,
        compiled: true,
        tests_passed: test_result.passed,
        tests_total: test_result.total,
        execution_time: compile.duration + test_result.duration,
        peak_memory_bytes: stats.peak_memory,
        benchmark_scores: bench_result.scores,
    }
}
```

### CLI Integration
```bash
# Agent can invoke tournament from within a task
selfware tournament --hypotheses ./mutations/ --parallel 8 --timeout 300
```

---

## Phase 3: Property Testing as Parity Checks (Principle 3)

### Problem
5200 unit tests check happy paths. An aggressively mutating agent will find ways to pass all unit tests while introducing subtle edge-case regressions.

### Solution: Mandatory proptest Generation in PDVR Verify Phase

```rust
// src/evolution/parity.rs

/// Rule enforced in the PDVR Verify cycle:
/// "Cannot commit mutation to core component without property test"
pub struct ParityCheck {
    pub target_fn: String,
    pub target_module: String,
    pub property_test: String,  // Generated proptest code
    pub fuzz_iterations: u64,   // Default: 10_000
}

/// The agent generates these, the system validates them
pub fn validate_parity_check(check: &ParityCheck) -> ParityResult {
    // 1. Parse the property test to ensure it's actually a proptest
    let ast = syn::parse_str::<syn::ItemFn>(&check.property_test)?;
    
    // Verify it contains proptest! macro or #[proptest] attribute
    if !contains_proptest_macro(&ast) {
        return ParityResult::Rejected("Must use proptest! macro or #[proptest]");
    }
    
    // 2. Verify the test actually references the target function
    if !references_function(&ast, &check.target_fn) {
        return ParityResult::Rejected("Property test must exercise the target function");
    }
    
    // 3. Run it with high iteration count
    let result = run_proptest(&check, check.fuzz_iterations)?;
    
    match result {
        PropResult::Passed(n) => ParityResult::Stable(n),
        PropResult::Failed(counterexample) => ParityResult::Unstable(counterexample),
        PropResult::Timeout => ParityResult::Inconclusive,
    }
}
```

### Example: Agent Mutates `src/memory.rs`

The PDVR cycle enforces this flow:
1. **Plan**: "I'll optimize the token eviction algorithm"
2. **Do**: Agent calls `ast_mutate` to rewrite `evict_oldest_tokens()`
3. **Verify**: System demands a property test:
   ```rust
   proptest! {
       #[test]
       fn eviction_preserves_total_token_count(
           entries in prop::collection::vec(arbitrary_memory_entry(), 0..1000),
           budget in 1u64..100_000,
       ) {
           let mut memory = WorkingMemory::from_entries(entries.clone());
           let before_count = memory.total_tokens();
           memory.evict_to_budget(budget);
           // Invariant: never evict more than necessary
           prop_assert!(memory.total_tokens() <= budget);
           // Invariant: eviction is monotonic (oldest first)
           prop_assert!(memory.is_chronologically_ordered());
       }
   }
   ```
4. **Reflect**: If the proptest finds a counterexample, the mutation is rolled back

### cargo-mutants Integration

Run periodically as a "chaos monkey" for the test suite itself:
```bash
# Verify that tests actually catch bugs (not just passing vacuously)
cargo mutants --package selfware --timeout 120 -- --lib
```

If mutation testing reveals that a function has low "kill rate" (mutants survive), flag it for the agent to write better tests.

---

## Phase 4: Telemetry-Driven Search (Principle 4)

### Problem
"Make the code better" gives the LLM no gradient to follow. It needs sensory data about *where* time and memory are actually spent.

### Solution: Expose Profiling Tools to the Agent

```rust
// src/evolution/telemetry.rs

pub struct TelemetrySnapshot {
    pub hotspots: Vec<Hotspot>,
    pub allocation_profile: AllocationProfile,
    pub benchmark_deltas: Vec<BenchmarkDelta>,
}

pub struct Hotspot {
    pub function: String,
    pub file: String,
    pub line: u32,
    pub cpu_percent: f64,
    pub call_count: u64,
    pub avg_duration: Duration,
}

/// Generate telemetry for agent consumption
pub fn capture_telemetry(benchmark_name: &str) -> TelemetrySnapshot {
    // 1. Run criterion benchmark
    let bench_output = Command::new("cargo")
        .args(["bench", "--bench", benchmark_name, "--", "--output-format=json"])
        .output()?;
    
    // 2. Generate flamegraph
    let flamegraph = Command::new("cargo")
        .args(["flamegraph", "--bench", benchmark_name, "--output", "/tmp/flame.svg"])
        .output()?;
    
    // 3. Parse flamegraph SVG into hotspot list
    let hotspots = parse_flamegraph("/tmp/flame.svg")?;
    
    // 4. Run with allocation tracking (via DHAT or custom allocator)
    let alloc_profile = capture_allocations(benchmark_name)?;
    
    // 5. Compare against baseline
    let deltas = compare_with_baseline(benchmark_name)?;
    
    TelemetrySnapshot { hotspots, allocation_profile: alloc_profile, benchmark_deltas: deltas }
}

/// Format telemetry for injection into agent's Working Memory
pub fn telemetry_to_prompt(snapshot: &TelemetrySnapshot) -> String {
    let mut prompt = String::from("## Performance Telemetry\n\n");
    
    prompt.push_str("### CPU Hotspots (top 10)\n");
    for (i, h) in snapshot.hotspots.iter().take(10).enumerate() {
        prompt.push_str(&format!(
            "{}. `{}` in `{}:{}` — {:.1}% CPU, {} calls, {:.1}µs avg\n",
            i + 1, h.function, h.file, h.line,
            h.cpu_percent, h.call_count, h.avg_duration.as_micros()
        ));
    }
    
    prompt.push_str("\n### Memory Allocation Hotspots\n");
    for a in &snapshot.allocation_profile.top_allocators {
        prompt.push_str(&format!(
            "- `{}`: {} allocs/call, {} bytes total\n",
            a.function, a.allocs_per_call, a.total_bytes
        ));
    }
    
    prompt.push_str("\n### Benchmark Regression/Improvement\n");
    for d in &snapshot.benchmark_deltas {
        let direction = if d.delta_percent > 0.0 { "SLOWER" } else { "FASTER" };
        prompt.push_str(&format!(
            "- `{}`: {:.1}% {} ({:.2}ms → {:.2}ms)\n",
            d.name, d.delta_percent.abs(), direction,
            d.baseline_ms, d.current_ms
        ));
    }
    
    prompt
}
```

### Agent Receives This in Working Memory:

```
## Performance Telemetry

### CPU Hotspots (top 10)
1. `estimate_tokens` in `token_count.rs:47` — 42.3% CPU, 1.2M calls, 0.8µs avg
2. `parse_xml_tool_call` in `tool_parser.rs:182` — 18.7% CPU, 890K calls, 2.1µs avg
3. `evict_oldest` in `memory.rs:301` — 11.2% CPU, 45K calls, 89.3µs avg

### Memory Allocation Hotspots
- `parse_xml_tool_call`: 47 allocs/call, 2.3MB total
- `build_system_prompt`: 12 allocs/call, 890KB total

### Benchmark Regression/Improvement
- `sab_easy_calculator`: 2.1% FASTER (4.32s → 4.23s)
- `token_estimation`: 8.7% SLOWER (0.23ms → 0.25ms)
```

Now the agent has a gradient. It knows *exactly* where to focus mutations.

### Tool Registration
```rust
Tool::new("telemetry_capture", "📊 Capture CPU/memory profiling data for a benchmark")
Tool::new("telemetry_compare", "📈 Compare current performance against baseline")
```

---

## Phase 5: The Meta-SAB Evolutionary Daemon (Principle 5)

This is the keystone. Everything above feeds into this.

### `selfware evolve` Command

```rust
// src/evolution/daemon.rs

pub struct EvolutionConfig {
    pub generations: usize,         // 0 = infinite
    pub population_size: usize,     // hypotheses per generation
    pub parallel_eval: usize,       // concurrent sandboxes
    pub mutation_targets: Vec<MutationTarget>,
    pub fitness_weights: FitnessWeights,
    pub baseline_sab_score: f64,
    pub baseline_token_budget: u64,
}

pub enum MutationTarget {
    /// Agent can modify its own cognitive hyperparameters
    Config { keys: Vec<String> },  // e.g., step_timeout, token_budget, temperature
    /// Agent can rewrite its own prompt construction
    PromptLogic { files: Vec<PathBuf> },  // e.g., src/agent/agent.rs
    /// Agent can optimize its own tool implementations
    ToolCode { files: Vec<PathBuf> },     // e.g., src/tools/*.rs
    /// Agent can restructure its cognitive architecture
    CognitiveArch { files: Vec<PathBuf> },// e.g., src/cognitive/*.rs
}

pub struct FitnessWeights {
    pub sab_score: f64,          // Weight for SAB benchmark score (0-100)
    pub token_efficiency: f64,    // Weight for tokens used (lower = better)
    pub latency: f64,             // Weight for wall-clock time
    pub test_coverage: f64,       // Weight for maintaining/improving test coverage
    pub binary_size: f64,         // Weight for binary bloat prevention
}

/// THE EVOLUTIONARY LOOP
pub async fn evolve(config: EvolutionConfig) -> EvolutionResult {
    let mut baseline = measure_baseline(&config).await;
    let mut generation = 0;
    let mut hall_of_fame: Vec<GenerationWinner> = vec![];
    
    loop {
        generation += 1;
        if config.generations > 0 && generation > config.generations {
            break;
        }
        
        log_generation_start(generation, &baseline);
        
        // ═══════════════════════════════════════════════════
        // STEP 1: MUTATE — Agent proposes N hypotheses
        // ═══════════════════════════════════════════════════
        
        // Inject telemetry into agent's context
        let telemetry = capture_telemetry("sab_full").await;
        let telemetry_prompt = telemetry_to_prompt(&telemetry);
        
        // Inject evolution history (what worked, what didn't)
        let history_prompt = format_evolution_history(&hall_of_fame);
        
        // Ask the agent swarm to generate hypotheses
        let hypotheses = generate_hypotheses(
            &config,
            &telemetry_prompt,
            &history_prompt,
            config.population_size,
        ).await;
        
        // ═══════════════════════════════════════════════════
        // STEP 2: COMPILE — AST-aware mutation + type check
        // ═══════════════════════════════════════════════════
        
        let valid_hypotheses: Vec<_> = hypotheses.into_iter()
            .filter_map(|h| {
                match apply_ast_mutation(h.mutation.clone()) {
                    Ok(result) if result.success => Some(h),
                    Ok(result) => {
                        log_frost(&h, &result.compiler_errors);
                        None  // FROST ❄️ — compiler rejected
                    }
                    Err(e) => {
                        log_error(&h, e);
                        None
                    }
                }
            })
            .collect();
        
        if valid_hypotheses.is_empty() {
            log_generation_empty(generation);
            continue;
        }
        
        // ═══════════════════════════════════════════════════
        // STEP 3: THE ARENA — Parallel SAB evaluation
        // ═══════════════════════════════════════════════════
        
        let results = run_tournament(valid_hypotheses, TournamentConfig {
            max_parallel: config.parallel_eval,
            timeout: Duration::from_secs(3600),  // 1hr per hypothesis
            fitness_fn: build_fitness_fn(&config.fitness_weights),
        }).await;
        
        // ═══════════════════════════════════════════════════
        // STEP 4: FITNESS — Score against baseline
        // ═══════════════════════════════════════════════════
        
        let winner = &results[0];  // Sorted by fitness in tournament
        let winner_score = config.fitness_weights.composite_score(winner);
        let baseline_score = config.fitness_weights.composite_score(&baseline);
        
        // ═══════════════════════════════════════════════════
        // STEP 5: EMERGE OR DIE
        // ═══════════════════════════════════════════════════
        
        if winner_score > baseline_score {
            // 🌸 BLOOM — New baseline!
            log_bloom(generation, winner, winner_score, baseline_score);
            
            // Property test verification before accepting
            let parity = validate_parity_checks(&winner.property_tests)?;
            if parity.all_stable() {
                // Merge winning mutation into main
                apply_winning_mutation(winner).await;
                git_commit(&format!(
                    "🧬 Gen {} BLOOM: SAB {:.0} → {:.0}, tokens {:.0}% efficient",
                    generation, baseline.sab_score, winner.sab_score,
                    (1.0 - winner.tokens_used as f64 / baseline.tokens_used as f64) * 100.0
                )).await;
                
                baseline = measure_from_result(winner);
                hall_of_fame.push(GenerationWinner {
                    generation,
                    score: winner_score,
                    mutation_description: winner.description.clone(),
                });
            } else {
                log_parity_failure(generation, &parity);
            }
        } else {
            // ❄️ FROST — Destroy all mutations, keep baseline
            log_frost_generation(generation, winner_score, baseline_score);
        }
        
        // Cleanup all sandbox containers
        cleanup_all_containers().await;
    }
    
    EvolutionResult {
        generations_run: generation,
        improvements: hall_of_fame,
        final_baseline: baseline,
    }
}
```

### Selfware.toml Evolution Config

```toml
[evolution]
enabled = true
generations = 0              # 0 = run forever
population_size = 8          # hypotheses per generation
parallel_eval = 4            # concurrent Docker sandboxes
checkpoint_interval = 5      # git tag every N generations

[evolution.fitness_weights]
sab_score = 0.50             # 50% weight on SAB benchmark
token_efficiency = 0.25      # 25% weight on token usage
latency = 0.15               # 15% weight on wall-clock time
test_coverage = 0.05         # 5% weight on test coverage
binary_size = 0.05           # 5% weight on binary size

[evolution.mutation_targets]
config_keys = ["temperature", "token_budget", "step_timeout_secs", "max_iterations"]
prompt_logic = ["src/agent/agent.rs", "src/agent/system_prompt.rs"]
tool_code = ["src/tools/*.rs", "src/tool_parser.rs"]
cognitive = ["src/cognitive/*.rs", "src/memory.rs", "src/token_count.rs"]

[evolution.safety]
# Files the evolution daemon is NEVER allowed to touch
protected_files = [
    "src/evolution/**",       # Can't modify its own fitness function!
    "src/safety/**",          # Can't weaken safety guardrails
    "system_tests/**",        # Can't modify the benchmark itself
    "Cargo.toml",             # Can't add arbitrary dependencies
]
min_test_count = 5000         # Must maintain at least this many passing tests
max_binary_size_mb = 50       # Prevent binary bloat
rollback_on_any_test_failure = true
```

### Safety: The Cardinal Rule

**The evolution daemon MUST NOT be able to modify:**
1. Its own fitness function (`src/evolution/fitness.rs`)
2. The SAB benchmark suite (`system_tests/`)
3. The safety module (`src/safety/`)
4. The evolution daemon itself (`src/evolution/daemon.rs`)

This prevents reward hacking. The fitness landscape is externally defined and immutable from the agent's perspective.

---

## Phase 6: Implementation Priority & Timeline

| Priority | Component | Effort | Impact | Dependencies |
|----------|-----------|--------|--------|--------------|
| **P0** | `ast_tools.rs` — AST mutation + cargo check | 2-3 days | Eliminates wasted compile cycles | `syn` crate |
| **P0** | `fitness.rs` — SAB-as-fitness wrapper | 1-2 days | Required for everything | Existing SAB |
| **P1** | `telemetry.rs` — Profiling exposure | 2-3 days | Gives agent gradient signal | `criterion`, `flamegraph` |
| **P1** | `sandbox.rs` — Docker tournament | 3-4 days | Parallel evaluation | Existing Dockerfile |
| **P2** | `daemon.rs` — `selfware evolve` | 3-5 days | Closes the loop | All of the above |
| **P2** | Property test enforcement | 2-3 days | Stability guarantee | `proptest` |
| **P3** | `tournament.rs` — Advanced selection | 2-3 days | Better convergence | sandbox.rs |

**Total estimated: 2-3 weeks to close the loop.**

---

## Appendix A: Quick-Start Implementation Order

### Day 1-2: Wire `cargo check` as a Gate

Forget the full AST manipulation for now. The highest-leverage first step is brutally simple:

```rust
// Add to src/tools/mod.rs — wrap existing file_write/file_edit

fn verify_after_edit(path: &Path) -> ToolResult {
    if path.extension() == Some("rs") {
        let check = Command::new("cargo")
            .args(["check", "--message-format=json"])
            .output()?;
        if !check.status.success() {
            // Auto-rollback the edit
            git_restore(path)?;
            return ToolResult::Frost(parse_errors(&check.stderr));
        }
    }
    ToolResult::Bloom
}
```

This single change — making `cargo check` a synchronous gate on every Rust file edit — eliminates the #1 source of wasted iterations.

### Day 3-5: Wrap SAB as a Fitness Function

```bash
# src/evolution/fitness.rs just needs to:
# 1. Run the existing run_full_sab.sh
# 2. Parse the JSON output
# 3. Return a composite score

selfware evaluate --config selfware-eval.toml --output /tmp/fitness.json
```

### Day 6-10: Wire the Loop

Once you have "gate edits with cargo check" + "score with SAB", the minimal evolution loop is:

```
while true:
    agent.mutate(src/agent/) guided by telemetry
    if cargo check fails: rollback, continue
    score = run_sab()
    if score > baseline: commit, update baseline
    else: rollback
```

That's it. That's the minimum viable recursive self-improvement loop. Everything else (AST manipulation, Docker sandboxing, property testing, parallel tournaments) is optimization on top of this core.

---

## Appendix B: Preventing Reward Hacking

The most dangerous failure mode isn't the agent breaking the code — it's the agent *gaming the fitness function*. Known attack vectors:

1. **Test deletion**: Agent deletes failing tests to improve pass rate
   - **Defense**: `min_test_count` in evolution config, test count is part of fitness
   
2. **Benchmark specialization**: Agent overfits to SAB scenarios specifically
   - **Defense**: Periodically add new SAB scenarios; rotate scenario subsets per generation
   
3. **Metric gaming**: Agent inflates token efficiency by truncating responses
   - **Defense**: SAB score has heaviest weight; token efficiency only matters if SAB is maintained
   
4. **Self-modification of fitness**: Agent modifies evaluation code
   - **Defense**: `protected_files` list makes evolution module immutable from inside

5. **Prompt injection into fitness**: Agent embeds instructions in commit messages or comments
   - **Defense**: Fitness is purely numerical (SAB score + benchmarks), never parsed by LLM

---

## Appendix C: The Garden Metaphor Extended

| Concept | Garden Metaphor | Implementation |
|---------|----------------|----------------|
| Laws of Physics | Soil chemistry | Rust compiler + borrow checker |
| Mutation | Cross-pollination | AST-aware code transformation |
| Selection pressure | Sunlight & water | SAB fitness function |
| Parity checks | Root structure | Property tests (proptest) |
| Telemetry | Gardener's eye | Criterion + flamegraph |
| Evolution daemon | The seasons | `selfware evolve` loop |
| Protected files | The garden fence | Safety module + protected_files |
| Hall of fame | Seed bank | Git tags on winning generations |
