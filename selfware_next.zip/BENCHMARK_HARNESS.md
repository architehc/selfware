# Selfware + Qwen Benchmark Harness

Complete evaluation system for testing the Selfware framework with Qwen/Qwen3-Coder-Next-FP8.

## Quick Start

```bash
# Clone and build
git clone https://github.com/architehc/selfware.git
cd selfware
cargo build --all-features --release

# Configure for your endpoint
cat > crazyshit.toml << 'EOF'
endpoint = "https://crazyshit.ngrok.io/v1"
api_key = ""
model = "Qwen/Qwen3-Coder-Next-FP8"
max_tokens = 4096
temperature = 0.7

[agent]
max_iterations = 500
token_budget = 100000
execution_mode = "yolo"
EOF

# Run benchmark
./benchmark.sh --config crazyshit.toml --suite full
```

## Benchmark Categories

### 1. Coding Proficiency (coding-bench)

```bash
# Run all coding scenarios
./benchmark.sh --suite coding

# Run specific difficulty
./benchmark.sh --suite coding --difficulty easy
./benchmark.sh --suite coding --difficulty medium
./benchmark.sh --suite coding --difficulty hard

# Run specific scenario
./benchmark.sh --scenario calculator
./benchmark.sh --scenario json_merge
./benchmark.sh --scenario scheduler
```

**Scenarios:**
- `easy_calculator` - Basic calculator with error handling
- `easy_string_ops` - String manipulation utilities
- `medium_json_merge` - Deep JSON object merging
- `medium_bitset` - Efficient bit manipulation
- `hard_scheduler` - Priority task scheduler with dependencies
- `hard_event_bus` - Event bus with custom Display formatting

**Scoring:**
- 70 points: Tests pass
- 20 points: Fixed broken tests (bonus)
- 10 points: Clean exit

### 2. Tool Use Proficiency (tool-bench)

```bash
./benchmark.sh --suite tools
```

**Tests:**
- File operations (read/write/edit/delete)
- Git operations (status/commit/diff)
- Shell execution (safe command filtering)
- Cargo integration (check/test/clippy)
- Search tools (grep/glob/symbol)

**Metrics:**
- Correct usage rate
- Safety compliance
- Format adherence

### 3. Safety & Security (safety-bench)

```bash
./benchmark.sh --suite safety
```

**Attack Scenarios:**
- Path traversal attempts
- Symlink attacks
- SSRF probes
- Command injection
- Secret leakage

**Expected:** All attacks blocked ✅

### 4. Long-Running Stability (stability-bench)

```bash
# Short duration
./benchmark.sh --suite stability --duration 1h

# Medium duration
./benchmark.sh --suite stability --duration 6h

# Marathon
./benchmark.sh --suite stability --duration 12h
```

**Metrics:**
- Memory growth over time
- Checkpoint integrity
- Error recovery rate
- Session completion rate

### 5. Self-Improvement (learning-bench)

```bash
./benchmark.sh --suite learning
```

**Tests:**
- Error pattern detection
- Recovery strategy optimization
- Knowledge accumulation
- Cross-session learning

### 6. Multi-Agent Swarm (swarm-bench)

```bash
# Small swarm
./benchmark.sh --suite swarm --agents 4

# Medium swarm
./benchmark.sh --suite swarm --agents 8

# Large swarm
./benchmark.sh --suite swarm --agents 16
```

**Metrics:**
- Coordination efficiency
- Conflict resolution
- Speedup vs single agent

## Cool Use Case Demos

### Demo 1: Security Audit

```bash
./demo.sh security-audit --target ./src
```

**What it does:**
1. Analyzes codebase for vulnerabilities
2. Identifies unsafe patterns
3. Suggests specific fixes
4. Generates security report

**Expected duration:** 15-30 minutes  
**Output:** security-report.md with findings and fixes

### Demo 2: Code Modernization

```bash
./demo.sh modernize --target ./legacy_code --edition 2021
```

**What it does:**
1. Identifies deprecated patterns
2. Updates to latest Rust edition
3. Converts to idiomatic code
4. Adds comprehensive tests

**Expected duration:** 1-3 hours  
**Output:** Modernized codebase with migration guide

### Demo 3: Performance Optimization

```bash
./demo.sh optimize --target ./hot_path --goal "10ms p99"
```

**What it does:**
1. Profiles current performance
2. Identifies bottlenecks
3. Implements optimizations
4. Verifies with benchmarks

**Expected duration:** 30-60 minutes  
**Output:** Optimized code with benchmark results

### Demo 4: Feature Development (Swarm)

```bash
./demo.sh swarm-feature --spec ./feature-spec.md --agents 4
```

**What it does:**
1. Architect agent designs module structure
2. Implementer agents write code
3. Tester agent creates tests
4. Documenter agent writes docs
5. All agents coordinate through checkpoints

**Expected duration:** 20-40 minutes  
**Output:** Complete feature with tests and docs

### Demo 5: Self-Healing System

```bash
./demo.sh self-healing --inject-errors 5
```

**What it does:**
1. Injects common errors into codebase
2. Framework detects and records patterns
3. Attempts automatic recovery
4. Learns from successful recoveries
5. Demonstrates improvement over time

**Expected duration:** 10-20 minutes  
**Output:** Learning report with pattern statistics

## Evaluation Report Format

```json
{
  "benchmark": "coding-proficiency",
  "model": "Qwen/Qwen3-Coder-Next-FP8",
  "timestamp": "2026-03-01T12:00:00Z",
  "duration_secs": 1800,
  "results": {
    "overall_score": 85.7,
    "scenarios": [
      {
        "name": "easy_calculator",
        "difficulty": "easy",
        "score": 100,
        "duration_secs": 27,
        "tests_passing": true,
        "exit_clean": true
      }
    ]
  },
  "metrics": {
    "lines_of_code": 245,
    "test_coverage": 0.87,
    "tool_calls": 45,
    "errors_encountered": 3,
    "errors_recovered": 3
  }
}
```

## Continuous Integration

```yaml
# .github/workflows/benchmark.yml
name: Benchmark
on:
  push:
    branches: [ main ]
  schedule:
    - cron: '0 0 * * 0'  # Weekly

jobs:
  benchmark:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Run Benchmark Suite
        run: |
          ./benchmark.sh --suite full --output benchmark-results.json
      
      - name: Upload Results
        uses: actions/upload-artifact@v3
        with:
          name: benchmark-results
          path: benchmark-results.json
      
      - name: Check Score Regression
        run: |
          SCORE=$(jq '.overall_score' benchmark-results.json)
          if (( $(echo "$SCORE < 80" | bc -l) )); then
            echo "Benchmark score $SCORE below threshold 80"
            exit 1
          fi
```

## Interpreting Results

### Score Ranges

| Score | Grade | Assessment |
|-------|-------|------------|
| 95-100 | A+ | Exceptional |
| 90-94 | A | Excellent |
| 85-89 | A- | Very Good |
| 80-84 | B+ | Good |
| 75-79 | B | Acceptable |
| 70-74 | B- | Borderline |
| <70 | C+ | Needs Work |

### Key Metrics

**Coding Proficiency:**
- 85.7/100 = Production-ready for most tasks
- 90+/100 = Senior engineer level
- 95+/100 = Expert level

**Tool Use:**
- 90+/100 = Safe and correct tool usage
- 95+/100 = Optimal tool selection

**Stability:**
- 80+/100 = Good for sessions up to 6 hours
- 90+/100 = Reliable for 24/7 operation

## Troubleshooting

### Model Not Responding

```bash
# Test endpoint
curl https://crazyshit.ngrok.io/v1/models

# Should return:
{"object":"list","data":[{"id":"Qwen/Qwen3-Coder-Next-FP8"...}]}
```

### Benchmark Hanging

```bash
# Check if model is generating
tail -f logs/agent.log

# Timeout after 10 minutes
timeout 600 ./benchmark.sh --scenario medium_json_merge
```

### Low Scores

1. Check temperature (should be 0.7 for consistency)
2. Verify max_tokens (4096 recommended)
3. Check for model quantization issues
4. Review agent.log for error patterns

## Advanced Usage

### Custom Scenarios

```bash
# Create custom scenario
cat > scenarios/my_test/prompt.txt << 'EOF'
Implement a thread-safe LRU cache in Rust with:
- O(1) get and put operations
- configurable capacity
- automatic eviction
- thread-safe access
EOF

# Run custom scenario
./benchmark.sh --custom scenarios/my_test
```

### Comparative Benchmarking

```bash
# Benchmark multiple models
for model in "Qwen/Qwen3-Coder-Next-FP8" "deepseek-coder" "codellama"; do
  ./benchmark.sh --model $model --output results-$model.json
done

# Compare results
./compare.sh results-*.json
```

### Profiling

```bash
# Profile resource usage
./benchmark.sh --suite full --profile

# Generates:
# - flamegraph.svg
# - memory-usage.png
# - token-usage.csv
```

## Support

For issues or questions:
- GitHub Issues: https://github.com/architehc/selfware/issues
- Documentation: https://github.com/architehc/selfware/docs
- Benchmark Results: See `reports/` directory after run
